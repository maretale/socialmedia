// This file contains API operations for news topic interests of users, as well as reading of data for articles and article feeds.
const db = require('../models/news.js');
const sparkIntegration = require('../news/sparkIntegration.js');
const feedService = require('../news/newsFeedService.js');

// Helper function to extract value from DynamoDB attribute or plain value
const extractValue = function(field) {
    if (!field) return '';
    return field.S || field.N || field.BOOL || field;
};


// Get user's news feed with full article details (with pagination)
const getUserFeed = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);
    const page = parseInt(req.query.page) || 0;
    const limit = parseInt(req.query.limit) || 10;

    db.getUserFeed(userId, function(err, feedItems) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (!feedItems || feedItems.length === 0) {
            return res.json({ articles: [], totalCount: 0, page: page, hasMore: false });
        }

        const totalCount = feedItems.length;
        const startIndex = page * limit;
        const endIndex = startIndex + limit;
        const paginatedItems = feedItems.slice(startIndex, endIndex);
        const hasMore = endIndex < totalCount;

        if (paginatedItems.length === 0) {
            return res.json({ articles: [], totalCount: totalCount, page: page, hasMore: false });
        }

        const articleIds = paginatedItems.map(item => item.articleId);
        const promises = articleIds.map(id => {
            return new Promise((resolve, reject) => {
                db.getArticle(id, function(err, article) {
                    if (err) {
                        resolve(null);
                    } else {
                        resolve(article);
                    }
                });
            });
        });

        Promise.all(promises).then(articles => {
            const validArticles = articles.filter(a => a !== null);
            res.json({
                articles: validArticles,
                totalCount: totalCount,
                page: page,
                hasMore: hasMore,
                totalPages: Math.ceil(totalCount / limit)
            });
        }).catch(err => {
            res.status(500).json({ error: "Failed to load feed: " + err.message });
        });
    });
};

// Search for articles (with pagination)
const searchArticles = async function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);
    const query = req.query.q || req.body.query;
    const page = parseInt(req.query.page) || 0;
    const limit = parseInt(req.query.limit) || 10;

    if (!query) {
        return res.status(400).json({ error: "Query parameter required" });
    }

    try {
        const allResults = await db.searchArticles(query, userId);
        const totalCount = allResults.length;
        const startIndex = page * limit;
        const endIndex = startIndex + limit;
        const paginatedResults = allResults.slice(startIndex, endIndex);
        const hasMore = endIndex < totalCount;

        res.json({
            results: paginatedResults,
            totalCount: totalCount,
            page: page,
            hasMore: hasMore,
            totalPages: Math.ceil(totalCount / limit)
        });
    } catch (err) {
        console.error('Search error:', err);
        res.status(500).json({ error: "Search failed: " + err.message });
    }
};

// Get search suggestions
const getSearchSuggestions = async function(req, res) {
    const query = req.query.q || req.body.query;

    if (!query) {
        return res.json({ suggestions: [] });
    }

    try {
        const suggestions = await db.getSearchSuggestions(query);
        res.json({ suggestions });
    } catch (err) {
        console.error('Suggestion error:', err);
        res.status(500).json({ error: "Failed to get suggestions: " + err.message });
    }
};

// Add interest (and trigger feed update)
const addInterest = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);
    let newsType = req.body.newsType;

    if (!newsType) {
        return res.status(400).json({ error: "News type required" });
    }

    // Normalize to uppercase for consistency
    newsType = newsType.toUpperCase().trim();
    
    // Add the interest with normalized name
    db.addInterest(userId, newsType, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        // Trigger feed update (which also triggers Spark)
        db.updateFeedOnInterestChange(userId);

        res.json({ success: true, message: "Interest added", category: newsType });
    });
};

// Delete interest (and trigger feed update)
const deleteInterest = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);
    const newsType = req.params.newsType || (req.body && req.body.newsType);

    if (!newsType) {
        return res.status(400).json({ error: "News type required" });
    }

    db.deleteInterest(userId, newsType, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        // Trigger feed update (which also triggers Spark)
        db.updateFeedOnInterestChange(userId);

        res.json({ success: true, message: "Interest removed and feed will update shortly" });
    });
};

// Get user interests
const getUserInterests = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);

    db.getUserInterests(userId, function(err, interests) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json({ interests: interests });
    });
};

// Like an article
const likeArticle = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);
    const articleId = req.params.articleId || (req.body && req.body.articleId);

    if (!articleId) {
        return res.status(400).json({ error: "Article ID required" });
    }

    db.addArticleLike(userId, articleId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ success: true, message: "Article liked" });
    });
};

// Unlike an article
const unlikeArticle = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);
    const articleId = req.params.articleId || (req.body && req.body.articleId);

    if (!articleId) {
        return res.status(400).json({ error: "Article ID required" });
    }

    db.deleteArticleLike(userId, articleId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ success: true, message: "Article unliked" });
    });
};

// Get user's liked articles
const getLikedArticles = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.status(401).json({ error: "Not logged in" });
    }

    const userId = extractValue(req.session.login.user_id);

    db.getUserArticleLikes(userId, function(err, likes) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json({ liked_articles: likes });
    });
};

// get valid categories
const getCategories = function(req, res) {
    db.getAllCategories(function(err, categories) {
        if (err) {
            console.error('Error fetching categories:', err);
            return res.status(500).json({ error: "Failed to fetch categories" });
        }
        res.json({ categories: categories || [] });
    });
};

module.exports = {
    getUserFeed,
    searchArticles,
    getSearchSuggestions,
    addInterest,
    deleteInterest,
    getUserInterests,
    likeArticle,
    unlikeArticle,
    getLikedArticles,
    getCategories
};