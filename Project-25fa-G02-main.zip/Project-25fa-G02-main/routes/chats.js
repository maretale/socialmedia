// This file contains API operations for chats, chat invites, chat messages, and chat membership.
const db = require('../models/chats.js');
const userDb = require('../models/users.js');

const createChat = function(req, res) {
    if (!req.session.login) { // must be logged in
        return res.status(401).json({ error: "Not logged in." });
    }
    const { name } = req.body;
    const creatorId = req.session.login.user_id.S; // chat created under own id (vestigial; this no longer matters for chat management)
    db.createChat(creatorId, name, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data })
        }
    });
};

const getChat = function(req, res) {
    // no authentication required
    const { id } = req.params;
    db.getChat(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const getChatMembers = function(req, res) {
    // no authentication required
    console.log("soemrgjriog");
    const { members } = req.query;
    console.log(members);
    db.getChatMembers(members, function(err, data) {
        console.log({err,data});
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const getChatsByUser = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const userId = req.session.login.user_id.S;
    db.getChatsByUser(userId, function(err, data) { // return al chats a user is in
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            // Enrich chat data with chat names
            const chatIds = data.map(item => item.chat_id.S);
            let enrichedChats = [];
            let completed = 0;

            if (chatIds.length === 0) {
                return res.status(200).json({ success: true, data: [] });
            }

            chatIds.forEach(chatId => { // get chat data
                db.getChat(chatId, function(err2, chatData) {
                    completed++;
                    if (!err2 && chatData) {
                        enrichedChats.push({
                            chat_id: { S: chatId },
                            chat_name: chatData.chat_name
                        });
                    }
                    if (completed === chatIds.length) {
                        return res.status(200).json({ success: true, data: enrichedChats });
                    }
                });
            });
        }
    });
};

const deleteChat = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { chatId } = req.body;
    const creatorId = req.session.login.user_id.S;
    // Verify user is the creator
    db.getChat(chatId, function(err1, data1) {
        if (err1) {
            return res.status(500).json({ error: err1.message });
        }
        if (data1.creator_id.S !== userId) {
            return res.status(403).json({ error: "Only chat creator can delete chat." });
        }

        db.deleteChat(chatId, userId, function(err2, data2) {
            if (err2) {
                return res.status(500).json({ error: err2.message });
            } else {
                return res.status(200).json({ success: true, data: data2 });
            }
        });
    });
};

const createChatInvite = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { invitedId, chatId } = req.body;
    const inviterId = req.session.login.user_id.S;

    // check inviterId is a member of chatId
    db.checkChatMember(inviterId, chatId, function(err1, data1) {
        if (err1) {
            return res.status(500).json({ error: err1.message });
        } else if (!data1) {
            return res.status(404).json({ error: "Not found." })
        }

        // Check if they are friends (check both directions)
        userDb.getFriendship(inviterId, invitedId, function(err2, friendship1) {
            if (friendship1) {
                // They are friends, allow invite
                db.createChatInvite(inviterId, invitedId, chatId, function(err3, data3) {
                    if (err3) {
                        return res.status(500).json({ error: err3.message });
                    } else {
                        return res.status(200).json({ success: true, data: data3 });
                    }
                });
            } else {
                // Check other direction
                userDb.getFriendship(invitedId, inviterId, function(err3, friendship2) {
                    if (friendship2) {
                        // They are friends, allow invite
                        db.createChatInvite(inviterId, invitedId, chatId, function(err4, data4) {
                            if (err4) {
                                return res.status(500).json({ error: err4.message });
                            } else {
                                return res.status(200).json({ success: true, data: data4 });
                            }
                        });
                    } else {
                        // Not friends, cannot invite
                        return res.status(403).json({
                            error: "You can only invite friends to chat.",
                            notFriends: true
                        });
                    }
                });
            }
        });
    });
};

const getUserChatInvites = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const invitedId = req.session.login.user_id.S; // get current user's chat invites
    db.getUserChatInvites(invitedId, function(err, data) {
        if (err) {
            console.log(err);
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

// Chat creator deletes an invite they sent
const deleteChatInvite = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { invitedId, chatId } = req.body;
    const inviterId = req.session.login.user_id.S;

    db.deleteChatInvite(invitedId, chatId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const rejectChatInvite = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { inviterId, chatId } = req.body;
    const invitedId = req.session.login.user_id.S;
    db.deleteChatInvite(invitedId, inviterId, chatId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const createChatMessage = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { chatId, content } = req.body;
    const senderId = req.session.login.user_id.S;
    const clock = Date();
    // check senderId is a member for chatId
    db.checkChatMember(senderId, chatId, function(err1, data1) {
        if (err1) {
            return res.status(500).json({ error: err1.message });
        }
        db.createChatMessage(senderId, chatId, content, clock, function(err2, data2) {
            if (err2) {
                return res.status(500).json({ error: err2.message });
            } else {
                return res.status(200).json({ success: true, data: data2 });
            }
        });
    });
};

const getChatMessage = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { id } = req.params;
    const userId = req.session.login.user_id.S;
    // check userId is a member for chatId
    db.getChatMessage(id, function(err1, data1) {
        if (err1) {
            return res.status(500).json({ error: err1.message });
        }
        const chatId = data1.chat_id.S;
        db.checkChatMember(userId, chatId, function(err2, data2) {
            if (err2) {
                return res.status(403).json({ error: err2.message });
            } else {
                return res.status(200).json({ success: true, data: data1 });
            }
        });
    });
};

const getChatMessagesByChat = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { id } = req.params;
    const userId = req.session.login.user_id.S;
    // check userId is a member for chatId
    db.checkChatMember(userId, id, function(err1, data1) {
        if (err1) {
            return res.status(500).json({ error: err1.message });
        }
        db.getChatMessagesByChat(id, function(err2, data2) {
            if (err2) {
                return res.status(500).json({ error: err2.message });
            } else {
                return res.status(200).json({ success: true, data: data2 });
            }
        });
    });
};

const addChatMember = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { chatId, inviterId } = req.body;
    const invitedId = req.session.login.user_id.S;

    // First add the member to the chat
    db.addChatMember(invitedId, inviterId, chatId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        // After member is added, fetch and copy previous chat history
        // Exclude the current chat from the search to avoid duplicates
        db.getMessagesBetweenUsers(invitedId, inviterId, chatId, function(err2, previousMessages) {
            // Copy previous messages to the new chat (if any exist)
            // Don't block on errors - history is a nice-to-have
            if (!err2 && previousMessages && previousMessages.length > 0) {
                // Deduplicate messages based on sender, content, and timestamp
                // This prevents copying the same message multiple times when it exists in multiple chats
                const seen = new Set();
                const uniqueMessages = previousMessages.filter(msg => {
                    const key = `${msg.sender_id.S}|${msg.clock.S}|${msg.content.S}`;
                    if (seen.has(key)) {
                        return false;
                    }
                    seen.add(key);
                    return true;
                });

                uniqueMessages.forEach(msg => {
                    db.createChatMessage(
                        msg.sender_id.S,
                        chatId,
                        msg.content.S,
                        msg.clock.S,
                        function(err3) {
                            if (err3) {
                                console.error("Error copying message:", err3);
                            }
                        }
                    );
                });
            }
        });

        // Return success immediately - don't wait for history copy
        return res.status(200).json({ success: true, data: data });
    });
};

const checkChatMember = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { id } = req.params;
    const invitedId = req.session.login.user_id.S;
    db.checkChatMember(invitedId, id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const removeChatMember = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { chatId } = req.body;
    const memberId = req.session.login.user_id.S; // user can only remove themselves
    db.removeChatMember(memberId, chatId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const getUsersByChat = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { id } = req.params;
    const userId = req.session.login.user_id.S;
    // check userId is a member for chatId
    db.checkChatMember(userId, id, function(err1, data1) {
        if (err1) {
            return res.status(403).json({ error: "Not a member of this chat." });
        }
        db.getUsersByChat(id, function(err2, data2) {
            if (err2) {
                return res.status(500).json({ error: err2.message });
            } else {
                return res.status(200).json({ success: true, data: data2 });
            }
        });
    });
};

module.exports = {
    createChat,
    getChat,
    getChatMembers,
    getChatsByUser,
    deleteChat,
    createChatInvite,
    getUserChatInvites,
    deleteChatInvite,
    rejectChatInvite,
    createChatMessage,
    getChatMessage,
    getChatMessagesByChat,
    addChatMember,
    checkChatMember,
    removeChatMember,
    getUsersByChat
}