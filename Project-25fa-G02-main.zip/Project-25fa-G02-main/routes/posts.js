// This file contains API operations for posts and comments.
const db = require('../models/posts.js');
const userDb = require('../models/users.js');
const { uploadPostImage } = require('../utils/fileUpload.js');

// Helper function to extract value from DynamoDB attribute or plain value
const extractValue = function(field) {
    if (!field) return '';
    return field.S || field.N || field.BOOL || field;
};

// Helper function to check if a user can view another user's content
const canViewUserContent = function(viewerId, targetUserId, callback) {
    // If viewing own content, always allowed
    if (viewerId === targetUserId) {
        return callback(null, true);
    }

    // Get target user's privacy settings
    userDb.getUser(targetUserId, function(err, userData) {
        if (err) {
            return callback(err, false);
        }

        const isPrivate = extractValue(userData.isPrivate);

        // If account is public, anyone can view
        if (!isPrivate) {
            return callback(null, true);
        }

        // Account is private - check if viewer is following
        if (!viewerId) {
            return callback(null, false); // Not logged in, can't view private content
        }

        userDb.getFriendship(viewerId, targetUserId, function(err2, friendship) {
            if (err2) {
                return callback(err2, false); // report the error
            }
            if (!friendship) {
                userDb.getFriendship(targetUserId, viewerId, function(err3, friendship2) { // check other direction
                    if (err3) {
                        return callback(err3, false);
                    } else {
                        return callback(null, friendship2);
                    }
                });
            } else {
                // Following, can view
                return callback(null, true);
            }
        });
    });
};

const getWallByUserId = function(req, res) {
    // no authentication required
    const userId = req.params.id;
    if (!userId) {
        return res.status(400).json({ error: "User ID parameter required." });
    }

    const viewerId = req.session.login ? extractValue(req.session.login.user_id) : null;

    // Check if viewer can see this user's wall
    canViewUserContent(viewerId, userId, function(err, canView) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (!canView) {
            return res.status(403).json({
                error: "This account is private. Follow this user to see their posts.",
                isPrivate: true
            });
        }

        // User can view wall, fetch posts
        db.getWallByUserId(userId, function (err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            } else if (!data) {
                return res.status(200).json({ success: true, data: [] });
            } else {
                return res.status(200).json({ success: true, data: data });
            }
        });
    });
}

// post CRUD
const createPost = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const wallUserId = req.body.wallUserId;
    const creatorId = extractValue(req.session.login.user_id);
    const statusUpdate = req.body.statusUpdate;
    const content = req.body.content;
    const clock = (new Date()).toString();

    const addPost = function() {
        db.addPost(wallUserId, creatorId, statusUpdate, content, clock, function (err, data) {
            if (data === null || err) {
                return res.status(500).json({ error: err.message });
            } else {
                db.addWallPost(wallUserId, creatorId, data.postId, function(err2, data2) {
                    if (err2) {
                        return res.status(500).json({ error: err2.message });
                    } else {
                        return res.status(200).json({ success: true, message: "Successfully created post", postId: data.postId });
                    }
                });
            }
        });
    };

    if (wallUserId === creatorId) {
        return addPost();
    } else {
        userDb.getFriendship(wallUserId, creatorId, function(err, data) {
            if (err) {
                userDb.getFriendship(creatorId, wallUserId, function(err2, data2) {
                    if (err2) {
                        return res.status(403).json({ error: "Forbidden" });
                    } else {
                        return addPost();
                    }
                });
            } else {
                return addPost();
            }
        });
    }
}

// Create post with optional image
const createPostWithImage = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    uploadPostImage(req, res, function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }

        const wallUserId = req.body.wallUserId;
        const creatorId = extractValue(req.session.login.user_id);
        const statusUpdate = req.body.statusUpdate === 'true' || req.body.statusUpdate === true;
        const content = req.body.content || '';
        const clock = (new Date()).toString();

        // Get image URL if file was uploaded
        const imageUrl = req.file ? `/uploads/post-images/${req.file.filename}` : null;

        // Validate that either content or image is provided
        if (!content && !imageUrl) {
            return res.status(400).json({ error: "Post must have either content or an image." });
        }

        const addPost = function() {
            db.addPost(wallUserId, creatorId, statusUpdate, content, clock, imageUrl, function(err, data) {
                if (data === null || err) {
                    return res.status(500).json({ error: err.message });
                } else {
                    db.addWallPost(wallUserId, creatorId, data.postId, function(err2, data2) {
                        if (err2) {
                            return res.status(500).json({ error: err2.message });
                        } else {
                            return res.status(200).json({ success: true, message: "Successfully created post with image", postId: data.postId });
                        }
                    });
                }
            });
        };

        if (wallUserId === creatorId) {
            return addPost();
        } else {
            userDb.getFriendship(wallUserId, creatorId, function(err, data) {
                if (err) {
                    userDb.getFriendship(creatorId, wallUserId, function(err2, data2) {
                        if (err2) {
                            return res.status(403).json({ error: "Forbidden" });
                        } else {
                            return addPost();
                        }
                    });
                } else {
                    return addPost();
                }
            });
        }
    });
}

const getPost = function(req, res) {
    // does not require authentication
    const id = req.params.id; // get id from parameters
    if (!id) {
        return res.status(400).json({ error: "Post ID parameter required." });
    }
    db.getPost(id, function(err, postData) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            const wallUserId = extractValue(postData.wall_user_id);
            const viewerId = req.session.login ? extractValue(req.session.login.user_id) : null;

            // Check if viewer can see this post (based on wall owner's privacy)
            canViewUserContent(viewerId, wallUserId, function(err2, canView) {
                if (err2) {
                    return res.status(500).json({ error: err2.message });
                }

                if (!canView) {
                    return res.status(403).json({
                        error: "This account is private. Follow this user to see their posts.",
                        isPrivate: true
                    });
                }

                return res.status(200).json({ success: true, data: postData });
            });
        }
    });
}

const updatePost = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    const userId = extractValue(req.session.login.user_id);
    const { postId, content } = req.body; // can only update post content

    db.updatePost(userId, postId, content, function(err, data) {
        if (err) {
            if (err.status === 403) {
                return res.status(403).json({ error: "Unauthorized." });
            } else {
                return res.status(500).json({ error: err.message });
            }
        } else {
            return res.status(200).json({ success: true, message: "Successfully updated post." })
        }
    });
}

const deletePost = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    const userId = extractValue(req.session.login.user_id);
    const id = req.params.id; // get id from parameters

    db.deletePost(userId, id, function(err, data) {
        if (err) {
            if (err.status === 403) { // can only delete own posts
                return res.status(403).json({ error: "Unauthorized." });
            } else {
                return res.status(500).json({ error: err.message });
            }
        } else {
            return res.status(200).json({ success: true, message: "Successfully deleted post." });
        }
    });
}

// add a post to all of a user's friends' walls
const addPostToFriendWalls = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const creatorId = extractValue(req.session.login.user_id);
    const postId = req.body.postId;
    db.getPost(postId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            if (data.creator_id.S !== creatorId) { // ensure user is creator of post
                return res.status(403).json({ error: "Unauthorized." });
            } else {
                userDb.getFriends(creatorId, function(err2, data2) {
                    if (err2) {
                        return res.status(500).json({ error: err2.message });
                    }
                    const addWallPostPromise = (wallUserId) => {
                        return new Promise((resolve, reject) => {
                            db.addWallPost(wallUserId, creatorId, postId, function(err3) {
                                if (err3) {
                                    reject(err3);
                                } else {
                                    resolve();
                                }
                            });
                        });
                    };
        
                    const promises = data2.map(friend => // call proper user ids
                        addWallPostPromise(friend.friend_id.S)
                    );
                    Promise.all(promises).then(() => {
                        return res.status(200).json({ success: true, 
                               message: "Post added to all friend walls", data: {} });
                    }).catch(err => {
                        return res.status(500).json({ error: err.message });
                    });
                });
            }
        }
    });
};

// comment CRUD parentId, postId, creatorId, content, clock, callback
const createComment = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { parentId, postId, content } = req.body;
    const creatorId = extractValue(req.session.login.user_id);
    const clock = (new Date()).toString();

    // First, get the post to check wall owner
    db.getPost(postId, function(err, postData) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const wallUserId = extractValue(postData.wall_user_id);

        // Check if user can view/interact with this post
        canViewUserContent(creatorId, wallUserId, function(err2, canView) {
            if (err2) {
                return res.status(500).json({ error: err2.message });
            }

            if (!canView) {
                return res.status(403).json({
                    error: "You must follow this user to comment on their posts."
                });
            }

            // User can comment
            db.addComment(parentId, postId, creatorId, content, clock, function (err3, data) {
                if (err3) {
                    return res.status(500).json({ error: err3.message });
                } else {
                    return res.status(200).json({ success: true, message: "Successfully created comment." });
                }
            });
        });
    });
};

const getComment = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    
    const id = req.params.id; // get id from parameters
    if (!id) {
        return res.status(400).json({ error: "Comment ID parameter required." });
    }
    db.getComment(id, function(err, commentData) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            const postId = extractValue(commentData.post_id);

            // Get the post to check wall owner
            db.getPost(postId, function(err2, postData) {
                if (err2) {
                    return res.status(500).json({ error: err2.message });
                }

                const wallUserId = extractValue(postData.wall_user_id);
                const viewerId = req.session.login ? extractValue(req.session.login.user_id) : null;

                // Check if viewer can see this comment (based on post owner's privacy)
                canViewUserContent(viewerId, wallUserId, function(err3, canView) {
                    if (err3) {
                        return res.status(500).json({ error: err3.message });
                    }

                    if (!canView) {
                        return res.status(403).json({
                            error: "This account is private. Follow this user to see their content.",
                            isPrivate: true
                        });
                    }

                    return res.status(200).json({ success: true, data: commentData });
                });
            });
        }
    });
};

const getCommentsByPost = function(req, res) {
    // does not require authentication
    const id = req.params.id;
    if (!id) {
        return res.status(400).json({ error: "Post ID parameter required." });
    }
    db.getCommentsByPostId(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const updateComment = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    const userId = extractValue(req.session.login.user_id);
    const { commentId, content } = req.body; // can only update comment content

    db.updateComment(userId, commentId, content, function(err, data) {
        if (err) {
            if (err.status === 403) {
                return res.status(403).json({ error: "Unauthorized." });
            } else {
                return res.status(500).json({ error: err.message });
            }
        } else {
            return res.status(200).json({ success: true, message: "Successfully updated comment." })
        }
    });
}

const deleteComment = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    const userId = extractValue(req.session.login.user_id);
    const id = req.params.id; // get id from parameters

    db.deleteComment(userId, id, function(err, data) {
        if (err) {
            if (err.status === 403) {
                return res.status(403).json({ error: "Unauthorized." });
            } else {
                return res.status(500).json({ error: err.message });
            }
        } else {
            return res.status(200).json({ success: true, message: "Successfully deleted comment." });
        }
    });
}

const tagUser = function(req, res) {
    // check if user logged in:
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    // extract current user:
    const userId = extractValue(req.session.login.user_id);
    // get user that you want to tag:
    const taggedUser = req.body.taggedUserId
    // attach tags onto post:
    db.tagUser(userId, taggedUser, function(err, data) {
        // error handling:
        if (err) {
            if (err.status === 403) {
                return res.status(403).json({ error: "Unauthorized." });
            } else {
                return res.status(500).json({ error: err.message });
            }
        } else {
            return res.status(200).json({ success: true, message: "Successfully tagged user." });
        }
    });
}

// this will be triggered when current user clicks on a tag:
const goToTaggedAccount = function(req, res) {
    // check if user logged in:
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    // extract current user:
    const userId = extractValue(req.session.login.user_id)
    // extract tagged id:
    const taggedUser = req.body.taggedUserId
    // check if current user is authorized to see tagged account:
    canViewUserContent(userId, taggedUser, function(err, canView) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (!canView) {
            return res.status(403).json({
                error: "This account is private. Follow this user to see their posts.",
                isPrivate: true
            });
        }

        // redirect to tagged user's wall:
        db.getWallByUserId(userId, function (err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            } else if (!data) {
                return res.status(200).json({ success: true, data: [] });
            } else {
                return res.status(200).json({ success: true, data: data });
            }
        });
    });
}

const createGroup = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const creatorId = req.session.login.user_id.S;
    const groupName = req.body.groupName;
    const isPrivate = req.body.isPrivate;
    console.log({ groupName, creatorId, isPrivate });
    db.createGroup(groupName, creatorId, isPrivate, function(err, data) {
        if (err) {
            console.log(err);
            return res.status(500).json({ error: err.message });
        } else {
            db.addGroupMember(data.groupId, creatorId, function(err2, data2) { // add creator as member (cannot remove)
                if (err2) {
                    return res.status(500).json({ error: err2.message });
                } else {
                    return res.status(200).json({ success: true, data: data }); // NOT data2
                }
            });
        }
    });
};

const getGroup = function(req, res) {
    // does not require authentication
    const groupId = req.params.id;
    db.getGroup(groupId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ sucess: true, data: data });
        }
    });
};

const getAllGroups = function(req, res) {
    // does not require authentication
    db.getAllGroups(function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ sucess: true, data: data });
        }
    });
};

const createGroupRequest = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const groupId = req.body.group_id;
    const requesterId = req.session.login.user_id.S;
    db.createGroupRequest(groupId, requesterId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ sucess: true, data: data });
        }
    });
};

const getGroupRequest = function(req, res) {
    if (!req.session.login) {
        return res.status(400).json({ error: "Not logged in." });
    }
    const groupId = req.query.group_id;
    const requesterId = req.query.user_id;
    const userId = req.session.login.user_id.S;
    
    db.getGroup(groupId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            if (userId === data.creator_id.S || userId === requesterId) { // ensure user is group creator or requester
                db.getGroupRequest(groupId, requesterId, function(err, data) {
                    if (err) {
                        return res.status(500).json({ error: err.message });
                    } else {
                        return res.status(200).json({ sucess: true, data: data });
                    }
                });
            } else {
                return res.status(403).json({ error: "Must be group creator" });
            }
        }
    });
};

const getAllGroupRequests = function(req, res) {
    if (!req.session.login) {
        return res.status(400).json({ error: "Not logged in." });
    }
    const groupId = req.query.group_id;
    const userId = req.session.login.user_id.S;
    
    db.getGroup(groupId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            if (userId === data.creator_id.S) { // ensure user is group creator
                db.getAllGroupRequests(groupId, function(err, data) {
                    if (err) {
                        return res.status(500).json({ error: err.message });
                    } else {
                        return res.status(200).json({ sucess: true, data: data });
                    }
                });
            } else {
                return res.status(403).json({ error: "Must be group creator." });
            }
        }
    });
};

const deleteGroupRequest = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const groupId = req.body.group_id;
    const requesterId = req.body.user_id;
    if (requesterId !== req.session.login.user_id.S) { // if user isn't trying to leave, make sure current user is group owner
        db.getGroup(groupId, function(err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            } else {
                if (data.creator_id.S === req.session.login.user_id.S) { // make sure user is creator
                    db.deleteGroupRequest(groupId, requesterId, function(err2, data2) {
                        if (err2) {
                            return res.status(500).json({ error: err2.message });
                        } else {
                            return res.status(200).json({ sucess: true, data: data2 });
                        }
                    });
                } else {
                    return res.status(403).json({ error: "Must be user trying to reject or group owner." });
                }
            }
        });
    } else {
        db.getGroup(groupId, function(err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            } else {
                if (data.creator_id.S !== req.session.login.user_id.S) { // make sure user is not creator
                    db.deleteGroupRequest(groupId, requesterId, function(err2, data2) {
                        if (err2) {
                            return res.status(500).json({ error: err2.message });
                        } else {
                            return res.status(200).json({ sucess: true, data: data2 });
                        }
                    });
                } else {
                    return res.status(400).json({ error: "Owner cannot delete group request. Try deleting group instead." });
                }
            }
        });
    }
};

const addGroupMember = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const groupId = req.body.group_id;
    const memberId = req.body.user_id;
    const creatorId = req.session.login.user_id.S;
    db.getGroup(groupId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            if (data.creator_id.S === req.session.login.user_id.S || !data.isPrivate.BOOL) {
                db.addGroupMember(groupId, memberId, function(err2, data2) { // automatically deletes request
                    if (err2) {
                        res.status(500).json({ error: err2.message });
                    } else {
                        res.status(200).json({ success: true, data: data2 });
                    }
                });
            } else {
                return res.status(403).json({ error: "Cannot add user to private group if not group creator." });
            }
        }
    });
};

const getGroupMember = function(req, res) {
    // does not require authentication
    const groupId = req.query.group_id;
    const memberId = req.query.user_id;
    db.getGroupMember(groupId, memberId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ sucess: true, data: data });
        }
    });
};

const getAllMemberGroups = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const memberId = req.session.login.user_id.S;
    db.getAllMemberGroups(memberId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const deleteGroupMember = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const groupId = req.body.group_id;
    const memberId = req.body.user_id;
    if (memberId !== req.session.login.user_id.S) { // if user isn't trying to leave, make sure current user is group owner
        db.getGroup(groupId, function(err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            } else {
                if (data.creator_id.S === req.session.login.user_id.S) { // make sure user is creator
                    db.deleteGroupMember(groupId, memberId, function(err2, data2) {
                        if (err2) {
                            return res.status(500).json({ error: err2.message });
                        } else {
                            return res.status(200).json({ sucess: true, data: data2 });
                        }
                    });
                } else {
                    return res.status(403).json({ error: "Must be user trying to leave or group owner." });
                }
            }
        });
    } else {
        db.getGroup(groupId, function(err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            } else {
                if (data.creator_id.S !== req.session.login.user_id.S) { // make sure user is not creator
                    db.deleteGroupMember(groupId, memberId, function(err2, data2) {
                        if (err2) {
                            return res.status(500).json({ error: err2.message });
                        } else {
                            return res.status(200).json({ sucess: true, data: data2 });
                        }
                    });
                } else {
                    return res.status(400).json({ error: "Owner cannot leave group. Try deleting group instead." });
                }
            }
        });
    }
};

const addGroupComment = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { parentId, postId, content, groupId } = req.body;
    const creatorId = extractValue(req.session.login.user_id);
    const clock = (new Date()).toString();

    db.getGroupMember(groupId, creatorId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        db.getGroupPost(groupId, postId, function(err2, data2) {
            if (err2) {
                return res.status(500).json({ error: err2.message });
            }
            db.addComment(parentId, postId, creatorId, content, clock, function (err3, data3) {
                if (err3) {
                    return res.status(500).json({ error: err3.message });
                } else {
                    return res.status(200).json({ success: true, data: data3 });
                }
            });
        });
    });
};

const addGroupPost = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const wallUserId = req.session.login.user_id.S;
    const creatorId = req.session.login.user_id.S;
    const statusUpdate = false;
    const content = req.body.content;
    const clock = (new Date()).toString();
    const groupId = req.body.groupId;

    const addPost = function() {
        db.addPost(wallUserId, creatorId, statusUpdate, content, clock, function (err, data) {
            if (data === null || err) {
                return res.status(500).json({ error: err.message });
            } else {
                db.addGroupPost(groupId, data.postId, function(err2, data2) {
                    if (err2) {
                        return res.status(500).json({ error: err2.message });
                    } else {
                        return res.status(200).json({ success: true, message: "Successfully created post" });
                    }
                });
            }
        });
    };

    db.getGroupMember(groupId, creatorId, function(err, data) {
        if (err) {
            return res.status(403).json({ error: "Must be in group." });
        } else {
            return addPost();
        }
    });
};

// Add group post with optional image
const addGroupPostWithImage = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    uploadPostImage(req, res, function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }

        const wallUserId = req.session.login.user_id.S;
        const creatorId = req.session.login.user_id.S;
        const statusUpdate = false;
        const content = req.body.content || '';
        const clock = (new Date()).toString();
        const groupId = req.body.groupId;

        // Get image URL if file was uploaded
        const imageUrl = req.file ? `/uploads/post-images/${req.file.filename}` : null;

        // Validate that either content or image is provided
        if (!content && !imageUrl) {
            return res.status(400).json({ error: "Post must have either content or an image." });
        }

        const addPost = function() {
            db.addPost(wallUserId, creatorId, statusUpdate, content, clock, imageUrl, function(err, data) {
                if (data === null || err) {
                    return res.status(500).json({ error: err.message });
                } else {
                    db.addGroupPost(groupId, data.postId, function(err2, data2) {
                        if (err2) {
                            return res.status(500).json({ error: err2.message });
                        } else {
                            return res.status(200).json({ success: true, message: "Successfully created group post with image" });
                        }
                    });
                }
            });
        };

        db.getGroupMember(groupId, creatorId, function(err, data) {
            if (err) {
                return res.status(403).json({ error: "Must be in group." });
            } else {
                return addPost();
            }
        });
    });
};

const getGroupPost = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const groupId = req.query.group_id;
    const postId = req.query.post_id;
    const userId = req.session.login.user_id.S;
    
    db.getGroupMember(groupId, userId, function(err, data) { // make sure user is member of group
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            db.getGroupPost(groupId, postId, function(err2, data2) { // make sure post was posted to group
                if (err2) {
                    return res.status(500).json({ error: err2.message });
                } else {
                    db.getPost(postId, function(err3, data3) { // get post
                        if (err3) {
                            return res.status(500).json({ error: err3.message });
                        } else {
                            console.log(data3);
                            return res.status(200).json({ success: true, data: data3 });
                        }
                    });
                }
            });
        }
    });
};

const getGroupPosts = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const groupId = req.query.group_id;
    const userId = req.session.login.user_id.S;

    db.getGroupMember(groupId, userId, function(err, data) {
        if (err) {
            return res.status(403).json({ error: "Must be in group." });
        } else {
            db.getGroupPosts(groupId, function(err2, data2) {
                if (err2) {
                    return res.status(500).json({ error: err2.message });
                } else {
                    return res.status(200).json({ success: true, data: data2 });
                }
            });
        }
    });
}

const deleteGroupPost = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const groupId = req.query.group_id;
    const postId = req.query.post_id;
    db.getPost(postId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            if (data.creator_id.S === req.session.login.user_id.S) { // check if user is post creator
                db.deleteGroupPost(groupId, postId, function(err2, data2) {
                    if (err2) {
                        return res.status(500).json({ error: err2.message });
                    } else {
                        return res.status(200).json({ success: true, data: data2 });
                    }
                });
            } else {
                db.getGroup(groupId, function(err2, data2) { // make sure user is group creator
                    if (err2) {
                        return res.status(500).json({ error: err2.message });
                    } else {
                        if (data2.creator_id.S === req.session.login.user_id.S) {
                            db.deleteGroupPost(groupId, postId, function(err3, data3) {
                                if (err3) {
                                    return res.status(500).json({ error: err3.message });
                                } else {
                                    return res.status(200).json({ success: true, data: data3 });
                                }
                            });
                        } else { // if user is not group creator or post creator, forbidden
                            return res.status(403).json({ error: "Cannot delete group post unless post creator or group owner." });
                        }
                    }
                });
            }
        }
    });
};

// groups frontend pages
const groups = function (req, res) {
    res.render('groups.ejs');
};

const group = function (req, res) {
    res.render('group.ejs');
};

const createGroupFrontend = function (req, res) {
    res.render('creategroup.ejs');
};

const createGroupComment = function (req, res) {
    res.render('creategroupcomment.ejs');
};

const createGroupPost = function (req, res) {
    res.render('creategrouppost.ejs');
};

const groupRequests = function (req, res) {
    res.render('grouprequests.ejs');
};

module.exports = {
    getWallByUserId,
    createPost,
    createPostWithImage,
    getPost,
    updatePost,
    deletePost,
    addPostToFriendWalls,
    createComment,
    getComment,
    getCommentsByPost,
    updateComment,
    deleteComment,
    tagUser,
    goToTaggedAccount,
    createGroup,
    getGroup,
    getAllGroups,
    getAllMemberGroups,
    createGroupRequest,
    getGroupRequest,
    deleteGroupRequest,
    addGroupMember,
    getGroupMember,
    deleteGroupMember,
    addGroupPost,
    addGroupPostWithImage,
    getGroupPost,
    getGroupPosts,
    deleteGroupPost,
    getAllGroupRequests,
    addGroupComment,
    group,
    groups,
    createGroupFrontend,
    createGroupComment,
    createGroupPost,
    groupRequests
};