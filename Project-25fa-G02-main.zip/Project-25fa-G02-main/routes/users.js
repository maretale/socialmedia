// This file contains API operations for users, as well as authentication and API operations for friend relations.
const db = require('../models/users.js');
const postsDb = require('../models/posts.js');

const extractValue = function(field) {
    if (!field) return '';
    return field.S || field.N || field.BOOL || field;
};

// AUTHENTICATION
const checkLogin = function(req, res) {
    const username = req.body.username;
    const pass = req.body.pass;

    db.checkAccount(username, pass, function(err, data) {
        if (err) {
            console.log(err);
            return res.status(400).json({ error: err.message });
        } else {
            req.session.login = data; // set login information
            return res.status(200).json({ data });
        }
    });
};

const logout = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const id = extractValue(req.session.login.user_id);
    db.logout(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            req.session.login = null;
            return res.status(200).json({ success: true, message: "Successfully logged out." });
        }
    });
}

// FRONTEND
//This function renders the / page and sends a message if user tried to login but failed
const logIn = function (req, res) {
    var message = req.query.message;
    if (message === 'redirect') {
        res.render('main.ejs', { message: 'Incorrect field' });
    }
    else {
        res.render('main.ejs', { message: null });
    }
};

const logoutFrontend = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const id = extractValue(req.session.login.user_id);
    db.logout(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            req.session.login = null;
            return res.redirect('/');
        }
    });
}

//This function renders the /signup page and sends a message if user tried to create an account but failed
const signup = function (req, res) {
    var message = req.query.message;
    if (message === 'redirect') {
        res.render('signup.ejs', { message: 'Username taken' });
    }
    else {
        res.render('signup.ejs', { message: null });
    }
};

//This function renders the /home page
const home = function (req, res) {
    /* TODO: Add session info to authenticate user
    if (req.session.username == null) {
        res.redirect('/');
    }
    else { */
    res.render('home.ejs');
    /* } */
};

//This function renders the /user?user_id=... page
const user = function(req, res) {
    res.render('user.ejs', {});
}

const createPost = function(req, res) {
    res.render('createpost.ejs');
};

const createComment = function(req, res) {
    res.render('createcomment.ejs');
};

//This function renders the /account page
const account = function (req, res) {
    /* TODO: Add session info to authenticate user
    if (req.session.username == null) {
        res.redirect('/');
    }
    else { */
    res.render('account.ejs');
    /* } */
};

const friendVisualizer = function(req, res) {
    if (!req.session.login) {
        return res.redirect('/');
    }
    return res.render('friendvisualizer.ejs');
}

const friends = function(req, res) {
    if (!req.session.login) {
        return res.redirect('/');
    }
    return res.render('friends.ejs');
}

// USER ENDPOINTS
const createAccount = function(req, res) {
    // does not require authentication
    const username = req.body.username;
    const firstName = req.body.firstName;
    const lastName = req.body.lastName;
    const affiliation = req.body.affiliation;
    const email = req.body.email;
    const birthday = req.body.birthday;
    const pass = req.body.pass;
    const isPrivate = req.body.isPrivate || false; // default to public account
    
    if (!/.+?@.+?\..+/.test(email)) { // check that email is valid
        return res.status(400).json({ error: "Please enter a valid email." });
    } else if (isNaN(new Date(birthday)) && new Date(birthday) < new Date()) { // check that date is valid
        return res.status(400).json({ error: "Please enter a valid date." });
    }

    const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
    const formattedBirthday = (new Date(birthday)).toLocaleDateString("en-US", options);
    db.addUser(username, firstName, lastName, affiliation, email, formattedBirthday, pass, function (err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            req.session.login = data; // set login information
            return res.status(200).json({ success: true, message: "Successfully created account.", data: data });
        }
    });
};

const getCurrentUser = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const id = req.session.login.user_id.S;
    db.getUser(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ sucess: true, data: data });
        }
    });
}

const getAccount = function(req, res) {
    // does not require authentication
    const id = req.params.id; // get id from parameters
    if (!id) {
        return res.status(400).json({ error: "User ID parameter required." });
    }
    db.getUser(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            // Check if account is private
            const isPrivate = (data.isPrivate && data.isPrivate.BOOL) || false;
            const viewerId = req.session.login ? extractValue(req.session.login.user_id) : null;

            // If private and not the owner, check if viewer is following
            if (isPrivate && viewerId !== id) {
                if (!viewerId) {
                    // Not logged in, can only see limited info
                    return res.status(200).json({
                        sucess: true,
                        data: {
                            user_id: data.user_id,
                            username: data.username,
                            first_name: data.first_name,
                            last_name: data.last_name,
                            isPrivate: true
                        },
                        isPrivate: true,
                        canView: false
                    });
                }

                // Check if viewer is following this user
                db.getFriendship(viewerId, id, function(err2, friendship) {
                    if (err2) {
                        return res.status(500).json({ error: err2.message });
                    } else if (!friendship) {
                        db.getFriendship(id, viewerId, function(err3, friendship2) {
                            if (err3) {
                                return res.status(500).json({ error: err3.message });
                            } else {
                                if (friendship2) { // return full info
                                    return res.status(200).json({ sucess: true, data: data, canView: true });
                                } else {
                                    return res.status(200).json({
                                        sucess: true, // return limited info
                                        data: {
                                            user_id: data.user_id,
                                            username: data.username,
                                            first_name: data.first_name,
                                            last_name: data.last_name,
                                            isPrivate: true
                                        },
                                        isPrivate: true,
                                        canView: false
                                    });
                                }
                            }
                        });
                    } else {
                        // Following, return full info
                        return res.status(200).json({ sucess: true, data: data, canView: true });
                    }
                });
            } else {
                // Public account or owner viewing own account
                return res.status(200).json({ sucess: true, data: data, canView: true });
            }
        }
    });
};

const getAccountByUsername = function(req, res) {
    // does not require authentication
    const username = req.params.username;
    db.getUserByUsername(username, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else if (!data || data.length === 0) {
            return res.status(404).json({ error: "Not found." });
        } else {
            return res.status(200).json({ sucess: true, data: data });
        }
    });
};

const searchForUsers = function(req, res) {
    // does not require authentication
    const search = req.query.prefix;
    db.getUsersByUsername(search, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ sucess: true, data: data });
        }
    });
};

const updateAccount = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { username, firstName, lastName, affiliation, email, birthday, isPrivate } = req.body;
    db.updateUser(extractValue(req.session.login.user_id), username, firstName, lastName, affiliation,
        email, birthday, isPrivate, function(err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            } else {
                // Update session with new privacy setting if changed
                if (isPrivate !== undefined) {
                    req.session.login.isPrivate = { BOOL: isPrivate };
                }
                return res.status(200).json({ success: true, message: "Successfully updated user." })
            }
        });
}

const updateEmail = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { email } = req.body;
    const userId = req.session.login.user_id.S;
    db.updateEmail(userId, email, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            req.session.login.email = { S: email }; // update user session
            return res.status(200).json({ success: true, message: "Successfully updated user email." })
        }
    });
}

const updateAffiliation = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { affiliation } = req.body;
    const userId = req.session.login.user_id.S;
    db.updateAffiliation(userId, affiliation, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            req.session.login.affiliation = { S: affiliation }; // update user session
            return res.status(200).json({ success: true, message: "Successfully updated user affiliation." })
        }
    });
}

const updatePassword = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const { password } = req.body;
    const userId = req.session.login.user_id.S;
    db.updatePassword(userId, password, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, message: "Successfully updated user password." })
        }
    });
}

const deleteAccount = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    const id = extractValue(req.session.login.user_id); // only allow user to delete themselves

    db.deleteUser(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            req.session.login = null;
            return res.status(200).json({ success: true, message: "Successfully deleted account." });
        }
    });
}

// PRIVACY SETTINGS
const togglePrivacy = function(req, res) { // toggle a user's privacy setting
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }

    const userId = extractValue(req.session.login.user_id);
    const { isPrivate } = req.body;

    // validate the input:
    if (typeof isPrivate !== 'boolean') {
        return res.status(400).json({error: "isPrivate must be a boolean value"});
    }

    db.updateUserPrivacy(userId, isPrivate, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            req.session.login.isPrivate = { BOOL: isPrivate };
            return res.status(200).json({ success: true, message: "Privacy settings updated.", isPrivate: isPrivate });
        }
    });
};

// FRIEND ENDPOINTS
const createFriendship = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const id = req.session.login.user_id.S;
    const { friendId } = req.body;
    db.deleteFriendRequest(friendId, id, function(err1, data1) { // check that friendId invited id to be a friend
        if (err1) {
            return res.status(500).json({ error: err.message });
        } else if (!data1) {
            return res.status(400).json({ error: "Must request friendship." });
        }
        const clock = (new Date()).toString();
        db.createFriendship(friendId, id, clock, function(err2, data2) {
            if (err2) {
                return res.status(500).json({ error: err2.message });
            } else {
                return res.status(200).json({ success: true, data: data2 });
            }
        });
    });
}

const getFriendship = function(req, res) {
    // no authentication required
    const friend1 = req.query.friend1;
    const friend2 = req.query.friend2;
    db.getFriendship(friend1, friend2, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else if (!data) {
            return res.status(404).json({ error: "Friendship does not exist." });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
}

const getFriendsByUserId = function(req, res) {
    // no authentication required
    const id = req.params.id;
    const viewerId = req.session.login ? extractValue(req.session.login.user_id) : null;

    // First check if the user's account is private
    db.getUser(id, function(err, userData) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const isPrivate = (userData.isPrivate && userData.isPrivate.BOOL) || false;

        // If account is private and viewer is not the owner
        if (isPrivate && viewerId !== id) {
            if (!viewerId) {
                return res.status(403).json({ error: "This account is private." });
            }

            // Check if viewer follows this user
            db.getFriendship(viewerId, id, function(err2, friendship) {
                if (err2 || !friendship) {
                    return res.status(403).json({ error: "This account is private. Follow to see their connections." });
                }

                // Viewer follows, show friends list
                returnFriendsList(id, res);
            });
        } else {
            // Public account or owner viewing
            returnFriendsList(id, res);
        }
    });
};

// Helper function to return friends list
const returnFriendsList = function(id, res) {
    db.getFriends(id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else if (!data || data.length === 0) {
            return res.status(200).json({ success: true, data: [] });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const deleteFriendship = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const id = extractValue(req.session.login.user_id);
    // Support both query params (DELETE) and body params (for backwards compatibility)
    const friend1 = req.query.friend1 || req.body.friend1;
    const friend2 = req.query.friend2 || req.body.friend2;
    console.log({ friend1, friend2 });
    if (!friend1 || !friend2) {
        return res.status(400).json({ error: "Missing friend1 or friend2 parameter." });
    }
    if (friend1 !== id && friend2 !== id) { // make sure user is one of the two friends
        return res.status(403).json({ error: "Cannot delete other users' friendships." });
    }
    db.deleteFriendship(friend1, friend2, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else if (!data || (Array.isArray(data) && data.length === 0) || (typeof data === 'object' && Object.keys(data).length === 0)) {
            return res.status(404).json({ error: "Friendship does not exist." });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

// FRIEND REQUEST API
const createFriendRequest = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const userId = req.session.login.user_id.S;
    const { invitedId } = req.body;

    // Check if target user's account is private
    db.getUser(invitedId, function(err, userData) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const isPrivate = (userData.isPrivate && userData.isPrivate.BOOL) || false;

        if (isPrivate) {
            // Create follow request for private account
            db.createFriendRequest(userId, invitedId, function(err2, data2) {
                if (err2) {
                    return res.status(500).json({ error: err2.message });
                } else {
                    return res.status(200).json({ success: true, data: data2 });
                }
            });
        } else {
            // Public account - create friendship directly
            const clock = (new Date()).toString();
            db.createFriendship(userId, invitedId, clock, function(err2, data2) {
                if (err2) {
                    return res.status(500).json({ error: err2.message });
                } else {
                    return res.status(200).json({ success: true, data: data2 });
                }
            });
        }
    });
};

const getFriendRequest = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const friend1Id = req.query.friend1_id;
    const friend2Id = req.query.friend2_id;
    const userId = req.session.login.user_id.S;
    if (friend1Id !== userId && friend2Id !== userId) { // can only get friend requests if user is one of the usres involved
        return res.status(403).json({ error: "Unauthorized." });
    }
    db.getFriendRequest(friend1Id, friend2Id, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else if (!data || data.length === 0) {
            return res.status(404).json({ error: "Not found." });
        } else {
            return res.status(200).json({ success: true, message: "Found.", data: data });
        }
    });
}

const getUserFriendRequests = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const userId = req.session.login.user_id.S; // can only get your friend requests
    db.getUserFriendRequests(userId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const deleteFriendRequest = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const userId = req.session.login.user_id.S; // can only be done by requester
    const { invitedId } = req.body;
    db.deleteFriendRequest(userId, invitedId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

const rejectFriendRequest = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const userId = req.session.login.user_id.S; // can only be done by requested
    const { inviterId } = req.body;
    db.deleteFriendRequest(inviterId, userId, function(err, data) {
        if (err) {
            return res.status(500).json({ error: err.message });
        } else {
            return res.status(200).json({ success: true, data: data });
        }
    });
};

// friend visualization
const visualizeFriends = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: "Not logged in." });
    }
    const userId = req.params.userId ? req.params.userId : req.session.login.user_id.S;
    const browsingUserId = req.session.login.user_id.S;
    const affiliation = req.session.login.affiliation.S;

    db.getUser(userId, function(err1, data1) {
        if (err1) {
            return res.status(500).json({ error: err1.message });
        } else if (!data1) {
            return res.status(404).json({ error: "User not found." });
        }

        const isPrivate = (data1.isPrivate && data1.isPrivate.BOOL) || false;

        // Check if viewer can see this user's friends
        if (isPrivate && userId !== browsingUserId) {
            db.getFriendship(browsingUserId, userId, function(err, friendship) {
                if (err || !friendship) {
                    return res.status(403).json({ error: "This account is private." });
                }
                // Can view, continue with visualization
                visualizeFriendsHelper(userId, browsingUserId, affiliation, data1, res);
            });
        } else {
            visualizeFriendsHelper(userId, browsingUserId, affiliation, data1, res);
        }
    });
};

const visualizeFriendsHelper = function(userId, browsingUserId, affiliation, data1, res) {
    const username = data1.username.S;
    db.getFriends(userId, function(err2, data2) {
        if (err2) {
            return res.status(500).json({ error: err2.message });
        } else if (!data2 || data2.length === 0) {
            return res.send({ id: userId, name: username, children: [] }); // keep proper format
        } else {
            const output = { id: userId, name: username, children: [] }; // keep proper format
            let completed = 0;
            const total = data2.length;
            for (var i = 0; i < data2.length; i++) {
                const current = data2[i];
                db.getUser(current.friend_id.S, function(err3, data3) {
                    if (err3) {
                        return res.status(500).json({ error: err3.message });
                    } else if (data3) {
                        if (userId === browsingUserId || data3.affiliation.S === affiliation) { // add to children
                            output.children.push({ id: current.friend_id.S, name: data3.username.S, children: [] });
                        }
                    }
                    completed++;
                    if (completed === total) { // send only after completed
                        return res.send(output);
                    }
                });
            }
        }
    });
};

const chats = function(req, res) {
    if (!req.session.login) {
        return res.redirect('/login');
    }
    res.render('chats.ejs');
};

const chat = function(req, res) {
    if (!req.session.login) {
        return res.redirect('/login');
    }
    res.render('chat.ejs');
};

const chatInvites = function(req, res) {
    if (!req.session.login) {
        return res.redirect('/login');
    }
    res.render('chatinvites.ejs');
};

const createChat = function(req, res) {
    if (!req.session.login) {
        return res.redirect('/login');
    }
    res.render('createchat.ejs');
};

const news = function(req, res) {
    if (!req.session.login || !req.session.login.user_id) {
        return res.redirect('/login');
    }

    res.render('news.ejs', {
        user: req.session.login
    });
};

const uploadProfilePicture = function(req, res) {
    if (!req.session.login) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    const { uploadProfilePicture: upload } = require('../utils/fileUpload');

    upload(req, res, function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }

        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        const profilePictureUrl = `/uploads/profile-pictures/${req.file.filename}`;
        const userId = extractValue(req.session.login.user_id);

        db.updateProfilePicture(userId, profilePictureUrl, function(err, data) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            // Create a status update post about the profile picture change
            const clock = (new Date()).toString();
            const content = "I updated my profile picture.";

            postsDb.addPost(userId, userId, true, content, clock, profilePictureUrl, function(err2, postData) {
                if (err2) {
                    // Log error but don't fail the upload
                    console.error('Failed to create status update for profile picture:', err2);
                } else {
                    // Add the post to the wall
                    postsDb.addWallPost(userId, userId, postData.postId, function(err3, wallData) {
                        if (err3) {
                            console.error('Failed to add profile picture status to wall:', err3);
                        }
                    });
                    return res.json({ message: 'Profile picture uploaded successfully', profile_picture: profilePictureUrl, postId: postData.postId });
                }
            });
        });
    });
};

module.exports = {
    logIn,
    signup,
    home,
    user,
    account,
    friendVisualizer,
    friends,
    logoutFrontend,
    createPost,
    createComment,
    checkLogin,
    logout,
    createAccount,
    getAccount,
    getCurrentUser,
    getAccountByUsername,
    searchForUsers,
    updateAccount,
    updateEmail,
    updateAffiliation,
    updatePassword,
    deleteAccount,
    togglePrivacy,
    createFriendship,
    getFriendship,
    getFriendsByUserId,
    deleteFriendship,
    createFriendRequest,
    getFriendRequest,
    getUserFriendRequests,
    deleteFriendRequest,
    rejectFriendRequest,
    visualizeFriends,
    chats,
    chat,
    chatInvites,
    createChat,
    news,
    uploadProfilePicture
};