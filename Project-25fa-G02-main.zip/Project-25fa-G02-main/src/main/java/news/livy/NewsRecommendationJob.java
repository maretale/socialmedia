package news.livy;

import java.util.*;

import org.apache.livy.Job;
import org.apache.livy.JobContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;

import scala.Tuple2;

public class NewsRecommendationJob implements Job<String> {

    private static final long serialVersionUID = 1L;

    private String currentDate;

    public NewsRecommendationJob(String currentDate) {
        this.currentDate = currentDate;
    }

    @Override
    public String call(JobContext ctx) throws Exception {
        System.out.println("=== News Recommendation Job Starting ===");
        System.out.println("Date: " + currentDate);

        System.out.println("Connecting to Spark...");
        SparkSession spark = SparkConnector.getSparkConnection();
        JavaSparkContext context = SparkConnector.getSparkContext();
        System.out.println("Connected!");

        // Set checkpoint directory to break lineage during iterations
        context.setCheckpointDir("/tmp/spark-checkpoints");

        try {
            int maxIterations = 15;
            double convergenceThreshold = 0.01;

            System.out.println("=== Loading data and building graph ===");
            GraphBuilder graphBuilder = new GraphBuilder(spark, context);

            JavaRDD<User> users = graphBuilder.loadUsersFromDynamoDB();
            JavaRDD<Article> articles = graphBuilder.loadArticlesFromDynamoDB(currentDate);

            long userCount = users.count();
            long articleCount = articles.count();
            System.out.println("Loaded " + userCount + " users and " + articleCount + " articles");

            Tuple2<JavaRDD<Node>, JavaRDD<Edge>> graph = graphBuilder.buildGraph(users, articles);
            JavaRDD<Node> nodes = graph._1();
            JavaRDD<Edge> edges = graph._2();

            long nodeCount = nodes.count();
            long edgeCount = edges.count();
            System.out.println("Graph has " + nodeCount + " nodes and " + edgeCount + " edges");

            System.out.println("=== Initializing labels ===");
            JavaPairRDD<String, Map<String, Double>> labels = initializeLabels(nodes, users, context);

            System.out.println("=== Running adsorption ===");
            JavaPairRDD<String, Map<String, Double>> finalLabels = runAdsorption(
                    edges,
                    labels,
                    users,
                    maxIterations,
                    convergenceThreshold
            );

            JavaPairRDD<String, Map<String, Double>> articleWeights = extractArticleWeightsPerUser(finalLabels, articles);

            storeArticleWeightsInDB(articleWeights);

            System.out.println("*** Finished news recommendation job! ***");
            return "Success: Processed " + articleCount + " articles for " + userCount + " users";

        } finally {
            System.out.println("Shutting down Spark connection");
            spark.stop();
        }
    }

    private JavaPairRDD<String, Map<String, Double>> initializeLabels(
            JavaRDD<Node> nodes,
            JavaRDD<User> users,
            JavaSparkContext context
    ) {
        // Collect user IDs once and broadcast to all workers for efficient lookup
        Set<String> userIds = new HashSet<>(users.map(u -> u.userId).collect());
        Broadcast<Set<String>> userIdsBroadcast = context.broadcast(userIds);

        JavaPairRDD<String, Map<String, Double>> labels = nodes.mapToPair(node -> {
            Map<String, Double> nodeLabels = new HashMap<>();
            if (userIdsBroadcast.value().contains(node.nodeId)) {
                nodeLabels.put(node.nodeId, 1.0);
            }
            return new Tuple2<>(node.nodeId, nodeLabels);
        });

        System.out.println("Initialized labels for " + labels.count() + " nodes");
        return labels;
    }

    private JavaPairRDD<String, Map<String, Double>> runAdsorption(
            JavaRDD<Edge> edges,
            JavaPairRDD<String, Map<String, Double>> initialLabels,
            JavaRDD<User> users,
            int maxIterations,
            double convergenceThreshold
    ) {
        // Cache userInjectionLabels since it's reused every iteration
        JavaPairRDD<String, Map<String, Double>> userInjectionLabels = users.mapToPair(user -> {
            Map<String, Double> nodeLabels = new HashMap<>();
            nodeLabels.put(user.userId, 1.0);  // User always has its own label
            return new Tuple2<>(user.userId, nodeLabels);
        }).cache();

        // Force materialization of userInjectionLabels
        userInjectionLabels.count();

        // Cache and materialize initial labels
        JavaPairRDD<String, Map<String, Double>> labels = initialLabels.cache();
        labels.count();

        // Cache edge pairs since they're reused every iteration
        JavaPairRDD<String, Tuple2<String, Double>> edgePairs = edges
                .mapToPair(e -> new Tuple2<>(e.source, new Tuple2<>(e.target, e.weight)))
                .cache();

        // Force materialization of edge pairs
        edgePairs.count();

        for (int iteration = 0; iteration < maxIterations; iteration++) {
            System.out.println("Iteration " + (iteration + 1) + "...");

            JavaPairRDD<String, Map<String, Double>> newLabels = edgePairs
                    .join(labels)
                    .mapToPair(tuple -> {
                        String target = tuple._2()._1()._1();
                        double edgeWeight = tuple._2()._1()._2();
                        Map<String, Double> sourceLabels = tuple._2()._2();

                        Map<String, Double> contribution = new HashMap<>();
                        for (Map.Entry<String, Double> entry : sourceLabels.entrySet()) {
                            contribution.put(entry.getKey(), entry.getValue() * edgeWeight);
                        }

                        return new Tuple2<>(target, contribution);
                    })
                    .reduceByKey((map1, map2) -> {
                        Map<String, Double> merged = new HashMap<>(map1);
                        for (Map.Entry<String, Double> entry : map2.entrySet()) {
                            merged.merge(entry.getKey(), entry.getValue(), Double::sum);
                        }
                        return merged;
                    })
                    .union(userInjectionLabels)
                    .reduceByKey((map1, map2) -> {
                        Map<String, Double> merged = new HashMap<>(map1);
                        for (Map.Entry<String, Double> entry : map2.entrySet()) {
                            merged.merge(entry.getKey(), entry.getValue(), Double::sum);
                        }
                        return merged;
                    })
                    .cache();

            // Checkpoint every 5 iterations to break lineage and prevent memory issues
            if (iteration % 5 == 4) {
                newLabels.checkpoint();
            }

            // Force materialization before calculating difference
            long newCount = newLabels.count();

            // Calculate convergence only every 3 iterations to reduce overhead
            double maxDiff = 1.0;
            if (iteration % 3 == 2 || iteration == maxIterations - 1) {
                maxDiff = calculateMaxDifference(labels, newLabels);
                System.out.println("Max label difference: " + maxDiff);
            } else {
                System.out.println("Processed " + newCount + " nodes");
            }

            // Unpersist old labels to free memory
            labels.unpersist();
            labels = newLabels;

            if (maxDiff <= convergenceThreshold) {
                System.out.println("Converged after " + (iteration + 1) + " iterations");
                break;
            }
        }

        return labels;
    }

    private double calculateMaxDifference(
            JavaPairRDD<String, Map<String, Double>> oldLabels,
            JavaPairRDD<String, Map<String, Double>> newLabels
    ) {
        JavaPairRDD<String, Tuple2<Map<String, Double>, Map<String, Double>>> joined =
                oldLabels.fullOuterJoin(newLabels).mapValues(tuple -> {
                    Map<String, Double> old = tuple._1().orElse(new HashMap<>());
                    Map<String, Double> newL = tuple._2().orElse(new HashMap<>());
                    return new Tuple2<>(old, newL);
                });

        double maxDiff = joined
                .map(pair -> {
                    Map<String, Double> old = pair._2()._1();
                    Map<String, Double> newL = pair._2()._2();

                    Set<String> allUsers = new HashSet<>();
                    allUsers.addAll(old.keySet());
                    allUsers.addAll(newL.keySet());

                    double maxNodeDiff = 0.0;
                    for (String user : allUsers) {
                        double oldVal = old.getOrDefault(user, 0.0);
                        double newVal = newL.getOrDefault(user, 0.0);
                        maxNodeDiff = Math.max(maxNodeDiff, Math.abs(newVal - oldVal));
                    }

                    return maxNodeDiff;
                })
                .reduce(Math::max);

        return maxDiff;
    }

    private JavaPairRDD<String, Map<String, Double>> extractArticleWeightsPerUser(
            JavaPairRDD<String, Map<String, Double>> labels,
            JavaRDD<Article> articles
    ) {
        Set<String> articleIds = new HashSet<>(articles.map(a -> a.articleId).collect());

        JavaPairRDD<String, Map<String, Double>> articleWeights = labels
                .filter(pair -> articleIds.contains(pair._1()));

        System.out.println("Extracted weights for " + articleWeights.count() + " articles");
        return articleWeights;
    }

    private void storeArticleWeightsInDB(JavaPairRDD<String, Map<String, Double>> articleWeights) {
        System.out.println("Storing article weights in DynamoDB...");

        // Filter out articles with no user weights before collecting
        // Articles get 0 weights if they're not connected to any user via interests or likes
        JavaPairRDD<String, Map<String, Double>> nonEmptyWeights = articleWeights
                .filter(pair -> pair._2() != null && !pair._2().isEmpty());

        // Collect only non-empty weights - avoid separate count() which triggers another full RDD computation
        List<Tuple2<String, Map<String, Double>>> allWeights = nonEmptyWeights.collect();

        System.out.println("Filtered: " + allWeights.size() + " articles have non-empty weights");
        System.out.println("Articles with 0 weights are not connected to any user via interests/likes");

        if (allWeights.isEmpty()) {
            System.out.println("No article weights to store - users may not have set interests or liked articles yet");
            return;
        }

        // Create DynamoDB client on driver
        software.amazon.awssdk.services.dynamodb.DynamoDbClient dynamoClient =
                software.amazon.awssdk.services.dynamodb.DynamoDbClient.builder()
                        .region(software.amazon.awssdk.regions.Region.US_EAST_1)
                        .build();

        try {
            // Pre-build all write requests first
            List<software.amazon.awssdk.services.dynamodb.model.WriteRequest> allRequests = new ArrayList<>();

            for (Tuple2<String, Map<String, Double>> articleWeight : allWeights) {
                String articleId = articleWeight._1();
                Map<String, Double> userWeights = articleWeight._2();

                for (Map.Entry<String, Double> entry : userWeights.entrySet()) {
                    Map<String, software.amazon.awssdk.services.dynamodb.model.AttributeValue> item = new HashMap<>();
                    item.put("user_id", software.amazon.awssdk.services.dynamodb.model.AttributeValue.builder().s(entry.getKey()).build());
                    item.put("article_id", software.amazon.awssdk.services.dynamodb.model.AttributeValue.builder().s(articleId).build());
                    item.put("weight", software.amazon.awssdk.services.dynamodb.model.AttributeValue.builder().n(entry.getValue().toString()).build());

                    allRequests.add(software.amazon.awssdk.services.dynamodb.model.WriteRequest.builder()
                            .putRequest(software.amazon.awssdk.services.dynamodb.model.PutRequest.builder().item(item).build())
                            .build());
                }
            }

            System.out.println("Total weight entries to write: " + allRequests.size());

            // Split into batches of 25 (DynamoDB limit)
            List<List<software.amazon.awssdk.services.dynamodb.model.WriteRequest>> batches = new ArrayList<>();
            for (int i = 0; i < allRequests.size(); i += 25) {
                batches.add(allRequests.subList(i, Math.min(i + 25, allRequests.size())));
            }

            System.out.println("Writing " + batches.size() + " batches...");

            // Process batches with parallel execution using thread pool
            int numThreads = Math.min(10, batches.size()); // Up to 10 parallel writers
            java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newFixedThreadPool(numThreads);
            java.util.concurrent.atomic.AtomicInteger batchesCompleted = new java.util.concurrent.atomic.AtomicInteger(0);
            java.util.concurrent.atomic.AtomicInteger totalWritten = new java.util.concurrent.atomic.AtomicInteger(0);

            List<java.util.concurrent.Future<?>> futures = new ArrayList<>();

            for (List<software.amazon.awssdk.services.dynamodb.model.WriteRequest> batch : batches) {
                futures.add(executor.submit(() -> {
                    writeBatchWithRetry(dynamoClient, new ArrayList<>(batch));
                    int completed = batchesCompleted.incrementAndGet();
                    totalWritten.addAndGet(batch.size());

                    // Log progress every 100 batches
                    if (completed % 100 == 0) {
                        System.out.println("Progress: " + completed + "/" + batches.size() + " batches, " + totalWritten.get() + " entries written");
                    }
                }));
            }

            // Wait for all batches to complete
            for (java.util.concurrent.Future<?> future : futures) {
                future.get();
            }

            executor.shutdown();

            System.out.println("SUCCESS: Wrote " + totalWritten.get() + " weight entries for " + allWeights.size() + " articles");

        } catch (Exception e) {
            System.err.println("ERROR writing to DynamoDB: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to store article weights", e);
        } finally {
            dynamoClient.close();
        }
    }

    private static void writeBatchWithRetry(
            software.amazon.awssdk.services.dynamodb.DynamoDbClient client,
            List<software.amazon.awssdk.services.dynamodb.model.WriteRequest> batch) {
        Map<String, List<software.amazon.awssdk.services.dynamodb.model.WriteRequest>> requestItems = new HashMap<>();
        requestItems.put("article_weights", new ArrayList<>(batch));

        int retries = 0;
        int maxRetries = 3;

        while (retries < maxRetries) {
            try {
                software.amazon.awssdk.services.dynamodb.model.BatchWriteItemRequest request =
                        software.amazon.awssdk.services.dynamodb.model.BatchWriteItemRequest.builder()
                                .requestItems(requestItems)
                                .build();

                software.amazon.awssdk.services.dynamodb.model.BatchWriteItemResponse response = client.batchWriteItem(request);

                if (response.hasUnprocessedItems() && !response.unprocessedItems().isEmpty()) {
                    requestItems = response.unprocessedItems();
                    retries++;
                    Thread.sleep((long) Math.pow(2, retries) * 100);
                    continue;
                }

                return;

            } catch (Exception e) {
                retries++;
                if (retries >= maxRetries) {
                    System.err.println("Failed to write batch after " + maxRetries + " retries: " + e.getMessage());
                    throw new RuntimeException(e);
                }

                try {
                    Thread.sleep((long) Math.pow(2, retries) * 100);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}