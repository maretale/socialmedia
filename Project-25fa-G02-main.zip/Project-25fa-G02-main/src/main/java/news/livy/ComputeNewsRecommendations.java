package news.livy;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.livy.LivyClient;
import org.apache.livy.LivyClientBuilder;

public class ComputeNewsRecommendations {

    private static final String LIVY_URL = System.getenv("LIVY_URL") != null
            ? System.getenv("LIVY_URL")
            : "http://localhost:8998/";

    public static void main(String[] args) throws IOException, URISyntaxException, InterruptedException, ExecutionException, TimeoutException {
        // ADD TimeoutException to method signature ^^^

        String currentDate = args.length > 0 ? args[0] : java.time.LocalDate.now().toString();

        LivyClient client = new LivyClientBuilder()
                .setURI(new URI(LIVY_URL))
                .setConf("spark.executor.memory", "2048m")
                .setConf("spark.executor.memoryOverhead", "384m")
                .setConf("spark.driver.memory", "2048m")
                .setConf("spark.driver.memoryOverhead", "384m")
                .setConf("spark.executor.instances", "1")
                .setConf("spark.dynamicAllocation.enabled", "true")
                .setConf("spark.dynamicAllocation.minExecutors", "1")
                .setConf("spark.dynamicAllocation.maxExecutors", "2")
                .build();

        try {
            String jar = "target/news-recommendation.jar";

            System.out.printf("Uploading %s to Spark context...\n", jar);
            client.uploadJar(new File(jar)).get();

            System.out.printf("Running news recommendation job for date: %s\n", currentDate);

            // Submit job with 30 minute timeout
            String result = client.submit(new NewsRecommendationJob(currentDate))
                    .get(30, TimeUnit.MINUTES);

            System.out.println("\nNews recommendation job completed successfully!");
            System.out.println("Result: " + result);
            System.out.println("Article weights have been stored in DynamoDB.");

        } finally {
            client.stop(true);
        }
    }
}