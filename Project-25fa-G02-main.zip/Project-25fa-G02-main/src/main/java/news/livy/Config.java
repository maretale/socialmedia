package news.livy;

// Create configuration file for SparkConnector.java
public class Config {
    public static String LOCAL_SPARK = "local[*]";
    public static int PARTITIONS = 5;
}