package news.livy;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;
import software.amazon.awssdk.regions.Region;

import scala.Tuple2;

// User class (gets metadata from DDB):
class User implements Serializable {
    private static final long serialVersionUID = 1L; // so spark can send User objects

    // relevant info:
    String userId;
    Set<String> interests;
    Set<String> friends;
    Set<String> likedArticles;

    // constructor:
    public User(String userId, Set<String> interests, Set<String> friends, Set<String> likedArticles) {
        this.userId = userId;
        this.interests = interests != null ? interests : new HashSet<>();
        this.friends = friends != null ? friends : new HashSet<>();
        this.likedArticles = likedArticles != null ? likedArticles : new HashSet<>();
    }
}

// Article class:
class Article implements Serializable {
    private static final long serialVersionUID = 1L;

    String articleId;
    String category;
    String publishDate;

    public Article(String articleId, String category, String publishDate) {
        this.articleId = articleId;
        this.category = category;
        this.publishDate = publishDate;
    }
}

// Edge class:
class Edge implements Serializable {
    private static final long serialVersionUID = 1L;
    String source;
    String target;
    double weight;

    public Edge(String source, String target, double weight) {
        this.source = source;
        this.target = target;
        this.weight = weight;
    }
}

// Node class:
class Node implements Serializable {
    private static final long serialVersionUID = 1L;
    String nodeId;
    String nodeType; // used by users, articles, and categories

    public Node(String nodeId, String nodeType) {
        this.nodeId = nodeId;
        this.nodeType = nodeType;
    }
}

public class GraphBuilder {

    // Connect to apache spark:
    SparkSession spark;
    JavaSparkContext context;
    DynamoDbClient dynamoClient;
    public GraphBuilder(SparkSession spark, JavaSparkContext context) {
        this.spark = spark;
        this.context = context;
        this.dynamoClient = DynamoDbClient.builder().region(Region.US_EAST_1).build();
    }

    // Load info from DDB tables:
    // Load from users:
    public JavaRDD<User> loadUsersFromDynamoDB() {
        System.out.println("Loading users from DynamoDB...");

        // scan users table to get all user_ids:
        System.out.println("Scanning users table...");
        List<String> userIds = scanUsersTable();

        // scan interests table to get user -> news_type mappings:
        System.out.println("Scanning interests table...");
        Map<String, Set<String>> userInterests = scanInterestsTable();

        // scan friends table to get user -> friend relationships:
        System.out.println("Scanning friends table...");
        Map<String, Set<String>> userFriends = scanFriendsTable();

        // scan article_likes table to get user -> article_likes
        System.out.println("Scanning article_likes table...");
        Map<String, Set<String>> userLikes = scanArticleLikesTable();

        // build User objects:
        List<User> users = new ArrayList<>();
        for (String userId : userIds) {
            Set<String> interests = userInterests.getOrDefault(userId, new HashSet<>());
            Set<String> friends = userFriends.getOrDefault(userId, new HashSet<>());
            Set<String> likedArticles = userLikes.getOrDefault(userId, new HashSet<>());

            users.add(new User(userId, interests, friends, likedArticles));
        }
        System.out.println("Loaded " + users.size() + " users");
        return context.parallelize(users); // converts list into Spark RDD (allows Spark operations)
    }

    // Load info from articles:
    public JavaRDD<Article> loadArticlesFromDynamoDB(String currentDate) {
        System.out.println("Scanning articles table...");

        List<Article> articles = new ArrayList<>();

        // Use projection to only fetch needed columns - reduces data transfer significantly
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName("articles")
                .projectionExpression("article_id, category, published_date")
                .build();

        ScanResponse response = dynamoClient.scan(scanRequest);

        for (Map<String, AttributeValue> item : response.items()) {
            // extract required metadata:
            String articleId = item.get("article_id").s();
            String category = item.get("category").s();
            String date = item.get("published_date").s();

            // filter by date:
            if (date.compareTo(currentDate) <= 0) {
                articles.add(new Article(articleId, category, date)); // add Article object to array list
            }
        }

        // pagination if more items:
        while (response.lastEvaluatedKey() != null && !response.lastEvaluatedKey().isEmpty()) {
            scanRequest = ScanRequest.builder()
                    .tableName("articles")
                    .projectionExpression("article_id, category, published_date")
                    .exclusiveStartKey(response.lastEvaluatedKey())
                    .build();

            response = dynamoClient.scan(scanRequest);

            for (Map<String, AttributeValue> item : response.items()) {
                String articleId = item.get("article_id").s();
                String category = item.get("category").s();
                String date = item.get("published_date").s();

                if (date.compareTo(currentDate) <= 0) {
                    articles.add(new Article(articleId, category, date));
                }
            }
        }

        System.out.println("Loaded " + articles.size() + " articles");
        return context.parallelize(articles);
    }

    // method to scan users table and return user ids:
    private List<String> scanUsersTable() {
        List<String> userIds = new ArrayList<>();

        // Use projection to only fetch user_id column
        ScanRequest scanRequest = ScanRequest.builder()
                .tableName("users")
                .projectionExpression("user_id")
                .build();

        ScanResponse response = dynamoClient.scan(scanRequest);

        for (Map<String, AttributeValue> item : response.items()) {
            userIds.add(item.get("user_id").s());
        }

        // handle pagination:
        while (response.lastEvaluatedKey() != null && !response.lastEvaluatedKey().isEmpty()) {
            scanRequest = ScanRequest.builder()
                    .tableName("users")
                    .projectionExpression("user_id")
                    .exclusiveStartKey(response.lastEvaluatedKey())
                    .build();

            response = dynamoClient.scan(scanRequest);

            for (Map<String, AttributeValue> item : response.items()) {
                userIds.add(item.get("user_id").s());
            }
        }

        return userIds;
    }

    // scan interests table:
    private Map<String, Set<String>> scanInterestsTable() {
        Map<String, Set<String>> userInterests = new HashMap<>();

        ScanRequest scanRequest = ScanRequest.builder()
                .tableName("interests")
                .build();

        ScanResponse response = dynamoClient.scan(scanRequest);

        for (Map<String, AttributeValue> item : response.items()) {
            String userId = item.get("user_id").s();
            String newsType = item.get("news_type").s();

            userInterests.computeIfAbsent(userId, k -> new HashSet<>()).add(newsType);
        }

        // handle pagination:
        while (response.lastEvaluatedKey() != null && !response.lastEvaluatedKey().isEmpty()) {
            scanRequest = ScanRequest.builder()
                    .tableName("interests")
                    .exclusiveStartKey(response.lastEvaluatedKey())
                    .build();

            response = dynamoClient.scan(scanRequest);

            for (Map<String, AttributeValue> item : response.items()) {
                String userId = item.get("user_id").s();
                String newsType = item.get("news_type").s();

                userInterests.computeIfAbsent(userId, k -> new HashSet<>()).add(newsType);
            }
        }

        return userInterests;
    }

    // method that returns map from users to friends:
    private Map<String, Set<String>> scanFriendsTable() {
        Map<String, Set<String>> userFriends = new HashMap<>();

        ScanRequest scanRequest = ScanRequest.builder()
                .tableName("friends")
                .build();

        ScanResponse response = dynamoClient.scan(scanRequest);

        for (Map<String, AttributeValue> item : response.items()) {
            String friend1 = item.get("friend1_id").s();
            String friend2 = item.get("friend2_id").s();

            // add bidirectional edge between friends:
            userFriends.computeIfAbsent(friend1, k -> new HashSet<>()).add(friend2);
            userFriends.computeIfAbsent(friend2, k -> new HashSet<>()).add(friend1);
        }

        // handle pagination:
        while (response.lastEvaluatedKey() != null && !response.lastEvaluatedKey().isEmpty()) {
            scanRequest = ScanRequest.builder()
                    .tableName("friends")
                    .exclusiveStartKey(response.lastEvaluatedKey())
                    .build();

            response = dynamoClient.scan(scanRequest);

            for (Map<String, AttributeValue> item : response.items()) {
                String friend1 = item.get("friend1_id").s();
                String friend2 = item.get("friend2_id").s();

                userFriends.computeIfAbsent(friend1, k -> new HashSet<>()).add(friend2);
                userFriends.computeIfAbsent(friend2, k -> new HashSet<>()).add(friend1);
            }
        }

        return userFriends;
    }

    // reads from article_likes table
    private Map<String, Set<String>> scanArticleLikesTable() {
        Map<String, Set<String>> userLikes = new HashMap<>();

        ScanRequest scanRequest = ScanRequest.builder()
                .tableName("article_likes")
                .build();

        ScanResponse response = dynamoClient.scan(scanRequest);

        for (Map<String, AttributeValue> item : response.items()) {
            String userId = item.get("user_id").s();
            String articleId = item.get("article_id").s();
            userLikes.computeIfAbsent(userId, k -> new HashSet<>()).add(articleId);
        }

        // Pagination
        while (response.lastEvaluatedKey() != null && !response.lastEvaluatedKey().isEmpty()) {
            scanRequest = ScanRequest.builder()
                    .tableName("article_likes")
                    .exclusiveStartKey(response.lastEvaluatedKey())
                    .build();

            response = dynamoClient.scan(scanRequest);

            for (Map<String, AttributeValue> item : response.items()) {
                String userId = item.get("user_id").s();
                String articleId = item.get("article_id").s();
                userLikes.computeIfAbsent(userId, k -> new HashSet<>()).add(articleId);
            }
        }

        return userLikes;
    }

    // build graph:
    public Tuple2<JavaRDD<Node>, JavaRDD<Edge>> buildGraph(
            JavaRDD<User> users,
            JavaRDD<Article> articles
    ) {
        System.out.println("Building graph...");

        // create nodes for users:
        JavaRDD<Node> userNodes = users.map(u -> new Node(u.userId, "user"));

        // create nodes for articles:
        JavaRDD<Node> articleNodes = articles.map(a -> new Node(a.articleId, "article"));

        // extract unique categories and create category nodes:
        JavaRDD<Node> categoryNodes = articles
                .map(a -> a.category)
                .distinct()
                .map(c -> new Node(c, "category"));

        // combine all nodes:
        JavaRDD<Node> allNodes = userNodes.union(articleNodes).union(categoryNodes);

        System.out.println("Creating edges...");

        // build edges:
        // user: weights sum to 0.3
        JavaRDD<Edge> userCategoryEdges = users.flatMap(user -> {
            List<Edge> edges = new ArrayList<>();
            int numInterests = user.interests.size();
            if (numInterests > 0) {
                double weightPerInterest = 0.3 / numInterests;
                for (String category : user.interests) {
                    edges.add(new Edge(user.userId, category, weightPerInterest));
                    edges.add(new Edge(category, user.userId, weightPerInterest));
                }
            }
            return edges.iterator();
        });

        // category: weights sum to 1.0
        JavaPairRDD<String, Iterable<String>> articlesByCategory = articles
                .mapToPair(a -> new Tuple2<>(a.category, a.articleId))
                .groupByKey();

        JavaRDD<Edge> categoryArticleEdges = articlesByCategory.flatMap(pair -> {
            String category = pair._1();
            List<String> articleList = new ArrayList<>();
            pair._2().forEach(articleList::add);

            List<Edge> edges = new ArrayList<>();
            int numArticles = articleList.size();
            if (numArticles > 0) {
                double weightPerArticle = 1.0 / numArticles;
                for (String articleId : articleList) {
                    edges.add(new Edge(category, articleId, weightPerArticle));
                }
            }
            return edges.iterator();
        });

        // user - article edges:
        // weights sum to 0.4:
        JavaRDD<Edge> userArticleEdges = users.flatMap(user -> {
            List<Edge> edges = new ArrayList<>();
            int numLiked = user.likedArticles.size();
            if (numLiked > 0) {
                double weightPerArticle = 0.4 / numLiked;
                for (String articleId : user.likedArticles) {
                    edges.add(new Edge(user.userId, articleId, weightPerArticle));
                }
            }
            return edges.iterator();
        });

        // friends edges:
        // weights sum to 0.3:
        JavaRDD<Edge> userFriendEdges = users.flatMap(user -> {
            List<Edge> edges = new ArrayList<>();
            int numFriends = user.friends.size();
            if (numFriends > 0) {
                double weightPerFriend = 0.3 / numFriends;
                for (String friendId : user.friends) {
                    edges.add(new Edge(user.userId, friendId, weightPerFriend));
                }
            }
            return edges.iterator();
        });

        // weights sum to 1.0
        // Articles have edges to: their category and users who liked them
        // first, compute the out-degree for each article:
        JavaPairRDD<String, Integer> articleOutgoingDegree = articles
                .mapToPair(a -> new Tuple2<>(a.articleId, 1)) // 1 for category edge
                .union(
                        users.flatMapToPair(user -> {
                            List<Tuple2<String, Integer>> pairs = new ArrayList<>();
                            for (String articleId : user.likedArticles) {
                                pairs.add(new Tuple2<>(articleId, 1));
                            }
                            return pairs.iterator();
                        })
                )
                .reduceByKey(Integer::sum);

        // create article->category edges with proper weights:
        JavaPairRDD<String, String> articleToCategory = articles
                .mapToPair(a -> new Tuple2<>(a.articleId, a.category));

        JavaRDD<Edge> articleCategoryEdges = articleToCategory
                .join(articleOutgoingDegree)
                .map(pair -> {
                    String articleId = pair._1();
                    String category = pair._2()._1();
                    int degree = pair._2()._2();
                    double weight = 1.0 / degree;
                    return new Edge(articleId, category, weight);
                });

        // create article->user edges with proper weights:
        JavaPairRDD<String, Iterable<String>> articleToLikers = users
                .flatMapToPair(user -> {
                    List<Tuple2<String, String>> pairs = new ArrayList<>();
                    for (String articleId : user.likedArticles) {
                        pairs.add(new Tuple2<>(articleId, user.userId));
                    }
                    return pairs.iterator();
                })
                .groupByKey();

        JavaRDD<Edge> articleUserEdges = articleToLikers
                .join(articleOutgoingDegree)
                .flatMap(pair -> {
                    String articleId = pair._1();
                    List<String> likers = new ArrayList<>();
                    pair._2()._1().forEach(likers::add);
                    int degree = pair._2()._2();
                    double weight = 1.0 / degree;

                    List<Edge> edges = new ArrayList<>();
                    for (String userId : likers) {
                        edges.add(new Edge(articleId, userId, weight));
                    }
                    return edges.iterator();
                });

        // Combine all edges
        JavaRDD<Edge> allEdges = userCategoryEdges
                .union(categoryArticleEdges)
                .union(userArticleEdges)
                .union(userFriendEdges)
                .union(articleCategoryEdges)
                .union(articleUserEdges);

        System.out.println("Graph built successfully!");

        return new Tuple2<>(allNodes, allEdges);
    }
}
