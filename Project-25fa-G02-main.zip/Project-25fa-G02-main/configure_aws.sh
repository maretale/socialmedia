#!/bin/bash

# A simplified script to rewrite AWS credentials.
# Assumes the ~/.aws directory already exists.

# Define the path to the AWS credentials file
AWS_CREDS_FILE="$HOME/.aws/credentials"

# --- Prompt for New Credentials ---
echo "Please enter your new AWS credentials for the [default] profile."

read -p "AWS Access Key ID: " AWS_ACCESS_KEY_ID

# -s flag makes input silent for secrets
read -p "AWS Secret Access Key: " AWS_SECRET_ACCESS_KEY
echo # Add a newline after the silent prompt

read -p "AWS Session Token (please include, important): " AWS_SESSION_TOKEN
echo # Add a newline after the silent prompt

# --- Write New Credentials to File ---
# The '>' operator will create the file or overwrite it if it already exists.
cat > "$AWS_CREDS_FILE" << EOF
[default]
aws_access_key_id = $AWS_ACCESS_KEY_ID
aws_secret_access_key = $AWS_SECRET_ACCESS_KEY
EOF

# Append the session token only if it was provided
if [ -n "$AWS_SESSION_TOKEN" ]; then
    echo "aws_session_token = $AWS_SESSION_TOKEN" >> "$AWS_CREDS_FILE"
fi

# --- Set Secure File Permissions ---
# Sets permissions to read/write for the owner only (600)
chmod 600 "$AWS_CREDS_FILE"

echo "" # Add a blank line for readability
echo "✅ Success! Your AWS credentials have been written to $AWS_CREDS_FILE"

