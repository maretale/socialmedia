// This file contains database operations (create, read, update, delete) for posts and comments.
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();
const uuid = require('uuid').v4;

const getWallByUserId = function(userId, callback) {
    if (!userId) {
        return callback(new Error("All fields must be filled."), null);
    }
    
    const params = {
        TableName: "wall_posts",
        KeyConditionExpression: "wall_user_id = :uid",
        ExpressionAttributeValues: {
            ":uid": { S: userId }
        },
        ProjectionExpression: "wall_user_id, post_id"
    };
    
    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            const items = data.Items || [];
            const fullInformation = [];
            for (let i = 0; i < items.length; i++) {
                const params = {
                    TableName: "posts",
                    Key: { post_id: { S: items[i].post_id.S } },
                    AttributesToGet: [ 'post_id', 'wall_user_id', 'creator_id', 'status_update', 'content', 'clock', 'image_url' ]
                };
                
                db.getItem(params, function(err, data) {
                    if (err) {
                        return callback(err, null); 
                    } else {
                        fullInformation.push(data.Item);
                        if (fullInformation.length === items.length) {
                            fullInformation.sort((a, b) => {
                                const extract = s => {
                                    const match = s.match(/^[A-Za-z]{3} [A-Za-z]{3} \d{2} \d{4} \d{2}:\d{2}:\d{2} GMT[+-]\d{4}/);
                                    return match ? new Date(match[0]) : new Date(s);
                                };
                                return extract(a.clock.S) - extract(b.clock.S);
                            });
                            callback(null, fullInformation);
                        }
                    }
                });
            }
            if (items.length === 0) {
                callback(null, []);
            }
        }
    });
};

// post CRUD
const dbCreatePost = function(wallUserId, creatorId, statusUpdate, content, clock, imageUrl, callback) {
    // Allow imageUrl to be optional - if it's a function, it's the callback
    if (typeof imageUrl === 'function') {
        callback = imageUrl;
        imageUrl = null;
    }

    // Content or imageUrl must be provided (or both)
    if (!wallUserId || !creatorId || statusUpdate === null || statusUpdate === undefined || !clock) {
        return callback(new Error("All fields must be filled"), null);
    }

    if (!content && !imageUrl) {
        return callback(new Error("Post must have either content or an image"), null);
    }

    const postId = uuid();
    const item = {
        post_id: { S: postId },
        wall_user_id: { S: wallUserId },
        creator_id: { S: creatorId },
        status_update: { BOOL: statusUpdate },
        content: { S: content || '' }, // Allow empty content if image is provided
        clock: { S: clock }
        // TODO: add tagged users
    };

    // Add image_url if provided
    if (imageUrl) {
        item.image_url = { S: imageUrl };
    }

    const params = {
        TableName: "posts",
        Item: item,
        ConditionExpression: "attribute_not_exists(post_id)" // check for duplicates
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, { postId });
        }
    });
};


const dbGetPost = function(id, callback) { // get a post by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }

    const params = {
        TableName: "posts", // get post (ID is primary key)
        Key: { post_id: { S: id } },
        AttributesToGet: [ 'wall_user_id', 'creator_id', 'post_id', 'status_update', 'content', 'clock', 'image_url' ]
    };

    db.getItem(params, function(err, data) {
        if (err) return callback(err, null);

        // TODO: make this return in a better format than the default
        if (!data.Item) {
            callback(new Error("Post does not exist"), null); // if no post, return does not exist error
        } else {
            callback(null, data.Item); // if it worked, return the post
        }
    });
};

const dbGetPostsByUser = function(id, callback) { // get all posts by user ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params1 = {
        TableName: "posts",
        FilterExpression: "wall_user_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: id }
        },
        ProjectionExpression: "post_id, wall_user_id, creator_id, status_update, content, clock, image_url"
    };

    db.scan(params1, function(err, dataOriginal) {
        const params2 = {
            TableName: "posts", // get pairs where this user is friend 2
            FilterExpression: "creator_id = :u",
            ExpressionAttributeValues: {
                ":u": { S: id }
            },
            ProjectionExpression: "post_id, wall_user_id, creator_id, status_update, content, clock, image_url"
        };
        
        if (err) {
            return callback(err, null);
        }

        db.scan(params2, function(err, data) { // have to use scan instead of get b/c "friend2_id" is not primary key ("friend1_id" is)
            if ((!data.Items || data.Items.length === 0) && (!dataOriginal.Items || dataOriginal.Items.length === 0)) {
                return callback(new Error("No items."), null);
            }
            const merged = [...dataOriginal.Items, ...data.Items];
            const posts = Array.from(new Map(
                merged.map(p => [p.post_id.S, p])
            ).values());
            
            if (err) {
                return callback(err, null);
            } else {
                return callback(null, posts);
            }
        });
    });
};

const dbUpdatePost = function(userId, postId, content, callback) {
    if (!userId || !postId || !content) {
        return callback(new Error("All fields must be filled"), null);
    }

    const params = {
        TableName: "posts",
        Key: {
            post_id: { S: postId }
        },
        UpdateExpression: "SET content = :c", // update post content
        ExpressionAttributeValues: {
            ":c": { S: content },
            ":uid": { S: userId }
        },
        ConditionExpression: "attribute_exists(post_id) AND creator_id = :uid",  // ensure post actually exists, updated by correct user
        ReturnValues: "ALL_OLD"
    };

    db.updateItem(params, function(err, data) {
        if (err) {
            if (err.code === "ConditionalCheckFailedException") {
                const authErr = new Error("Unauthorized."); // must be correct user
                authErr.statusCode = 403;
                return callback(authErr, null);
            } else {
                return callback(err, null);
            }
        } else {
            callback(null, data);
        }
    });
};

const dbDeletePost = function(userId, id, callback) {
    if (!userId || !id) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }

    const params = {
        TableName: "posts",
        Key: {
            post_id: { S: id },
        },
        ConditionExpression: "creator_id = :uid", // must be correct user
        ExpressionAttributeValues: {
            ":uid": { S: userId }
        },
        ReturnValues: "ALL_OLD"
    };

    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            if (err.code === "ConditionalCheckFailedException") {
                const authErr = new Error("Unauthorized.");
                authErr.statusCode = 403;
                return callback(authErr, null);
            } else {
                return callback(err, null);
            }
        } else {
            callback(null, data.Item);
        }
    });
};

// comment CRUD
const dbCreateComment = function(parentId, postId, creatorId, content, clock, callback) {
    if (!postId || !creatorId || !content || !clock) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }
    
    const commentId = uuid();
    const params = {
        TableName: "comments",
        Item: {
            comment_id: { S: commentId },
            parent_id: { S: parentId },
            post_id: { S: postId },
            creator_id: { S: creatorId },
            content: { S: content },
            clock: { S: clock },
            COMMENTTYPE: { S: "COMMENT" }
        },
        ConditionExpression: "attribute_not_exists(comment_id)" // check for duplicates
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, {});
        }
    });
};


const dbGetComment = function(id, callback) { // get a post by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "comments", // get post (ID is primary key)
        Key: { comment_id: { S: id } },
        AttributesToGet: [ 'comment_id', 'parent_id', 'post_id', 'creator_id', 'content', 'clock' ]
    };

    db.getItem(params, function(err, data) {
        if (err) return callback(err, null);
        if (!data.Item) {
            callback(new Error("Comment does not exist"), null); // if no post, return does not exist error
        } else {
            callback(null, data.Item); // if it worked, return the post
        }
    });
};

const dbGetCommentsByPostId = function(id, callback) {
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "comments",
        IndexName: "post_id-index",
        KeyConditionExpression:
            "COMMENTTYPE = :t AND post_id = :id", // use post_id GSI
        ExpressionAttributeValues: {
            ":t": { S: "COMMENT" },
            ":id": { S: id }
        },
        ProjectionExpression: "comment_id, parent_id, post_id, creator_id, content, clock",
        Limit: 20
    };
    
    db.query(params, function(err, data) { // efficient query from GSI
        if (err) {
            return callback(err, null);
        } if (!data.Items || data.Items.length === 0) {
            return callback(null, []);
        } else {
            return callback(null, data.Items);
        }
    });
};


const dbUpdateComment = function(userId, commentId, content, callback) {
    if (!userId || !commentId || !content) {
        return callback(new Error("All fields must be filled"), null);
    }

    const params = {
        TableName: "comments",
        Key: {
            comment_id: { S: commentId }
        },
        UpdateExpression: "SET content = :c",
        ExpressionAttributeValues: {
            ":c": { S: content },
            ":uid": { S: userId }
        },
        ConditionExpression: "attribute_exists(comment_id) AND creator_id = :uid",  // ensure comment actually exists, updated by correct user
        ReturnValues: "ALL_OLD"
    };

    db.updateItem(params, function(err, data) {
        if (err) {
            if (err.code === "ConditionalCheckFailedException") {
                const authErr = new Error("Unauthorized.");
                authErr.statusCode = 403;
                return callback(authErr, null);
            } else {
                return callback(err, null);
            }
        } else {
            callback(null, data);
        }
    });
};

const dbGetCommentsByParent = function(postId, parentId, callback) { // get all comments by parent comment (vestigial, comments no longer have parents)
    if (!postId || !parentId) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "comments",
        FilterExpression: "post_id = :o AND parent_id = :a",
        ExpressionAttributeValues: {
            ":o": { S: postId },
            ":a": { S: parentId }
        },
        ProjectionExpression: "comment_id, parent_id, post_id, creator_id, content, clock"
    };

    db.scan(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (!data.Items || data.Items.length === 0) {
            return callback(null, []);
        } else {
            return callback(null, data.Items);
        }
    });
};

const dbDeleteComment = function(userId, id, callback) {
    if (!id) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }
    
    const params = {
        TableName: "comments",
        Key: {
            comment_id: { S: id },
        },
        ConditionExpression: "creator_id = :uid", // must be correct user
        ExpressionAttributeValues: {
            ":uid": { S: userId }
        },
        ReturnValues: "ALL_OLD"
    };

    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            if (err.code === "ConditionalCheckFailedException") {
                const authErr = new Error("Unauthorized.");
                authErr.statusCode = 403;
                return callback(authErr, null);
            } else {
                return callback(err, null);
            }
        } else {
            callback(null, data.Item);
        }
    });
};

const dbAddWallPost = function(wallUserId, creatorId, postId, callback) {
    if (!wallUserId || !creatorId || !postId) {
        return callback(new Error("All fields must be specified"), null);
    }
    
    const params = {
        TableName: "wall_posts", // put post on first user's wall
        Item: {
            wall_user_id: { S: wallUserId },
            post_id: { S: postId }
        },
        ConditionExpression: "attribute_not_exists(wall_user_id) AND attribute_not_exists(post_id)"
    };
    
    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (wallUserId === creatorId) {
            callback(null, {});
        } else {
            const params2 = { // put post on second user's wall
                TableName: "wall_posts",
                Item: {
                    wall_user_id: { S: creatorId },
                    post_id: { S: postId }
                },
                ConditionExpression: "attribute_not_exists(wall_user_id) AND attribute_not_exists(post_id)"
            };
            db.putItem(params2, function(err2, data2) {
                if (err2) {
                    return callback(err2, null);
                } else {
                    return callback(null, {});
                }
            });
        }
    });
};

const dbDeleteWallPost = function(wallUserId, postId, callback) {
    if (!wallUserId || !postId) {
        return callback(new Error("All fields must be specified"), null);
    }
    
    const params = {
        TableName: "wall_posts",
        Key: {
            wall_user_id: { S: wallUserId },
            post_id: { S: postId }
        },
        ReturnValues: "ALL_OLD"
    };
    
    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            return callback(err, null);
        } else {
            callback(null, data.Item);
        }
    });
}

const dbTagUser = function(postId, userId, taggedUserId, callback) {
    if (!postId || !userId || !taggedUserId) {
        return callback(new Error("All fields must be specified"), null);
    }
    // get existing tags from current post:
    dbGetPost(postId, function(err, postData) {
        if (err) {
            return callback(err, null)
        }
        // current user must be creator of post to be able to add a tag:
        const creatorId = postData.creator_id.S;
        if (creatorId !== userId) {
            const authErr = new Error("Unauthorized error. Only post creator can tag users.");
            authErr.status = 403;
            return callback(authErr, null);
        }
        // get existing tagged users:
        const currTags = postData.tagged_users && postData.tagged_users.S
            ? postData.tagged_users.S.split(',').filter(id => id.length > 0)
            : [];
        // check if user is already tagged:
        if (currTags.includes(taggedUserId)) {
            return callback(new Error("User is already tagged in this post"), null);
        }
        // tag the user:
        currTags.push(taggedUserId); // modify the list of tagged users
        const updatedTags = currTags.join(','); // transform list back into , delimited string to update table
        const params = {
            TableName: "posts",
            Key: {
                post_id: {S: postId}
            },
            UpdateExpression: "SET tagged_users  = :tags",
            ExpressionAttributeValues: {
                ":tags": {S: updatedTags}
            },
            ReturnValues: "ALL_NEW"
        }
        db.updateItem(params, function(err, data) {
            if (err) {
                return callback(err, null);
            } else {
                callback(null, data);
            }
        });
    });
}

const dbCreateGroup = function(groupName, creatorId, isPrivate, callback) { // create a new group
    if (!groupName || !creatorId) {
        return callback(new Error("All fields required"), null);
    }
    
    const groupId = uuid();
    const params = {
        TableName: "groups",
        Item: {
            group_id: { S: groupId },
            group_name: { S: groupName },
            creator_id: { S: creatorId },
            isPrivate: { BOOL: isPrivate }
        },
        ConditionExpression: "attribute_not_exists(group_id)"
    };
    
    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, { groupId });
        }
    });
};

const dbGetGroup = function(groupId, callback) { // get group information
    if (!groupId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "groups",
        Key: {
            group_id: { S: groupId }
        },
        AttributesToGet: [ "group_id", "group_name", "creator_id", "isPrivate" ]
    };
    
    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Item);
        }
    });
};

const dbGetAllGroups = function(callback) { // return all groups in arbitrary order
    const params = {
        TableName: "groups",
        ProjectionExpression: "group_id, group_name, creator_id, isPrivate"
    };
    
    db.scan(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Items);
        }
    });
};

const dbCreateGroupRequest = function(groupId, requesterId, callback) { // request to join a group
    if (!groupId || !requesterId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_requests",
        Item: {
            group_id: { S: groupId },
            user_id: { S: requesterId }
        },
        ConditionExpression: "attribute_not_exists(group_id) AND attribute_not_exists(user_id)"
    };
    
    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, {});
        }
    });
};

const dbGetAllGroupRequests = function(groupId, callback) {
    if (!groupId) {
        return callback(new Error("All fields required"), null);
    }

    const params = {
        TableName: "group_requests",
        KeyConditionExpression: "group_id = :g",
        ExpressionAttributeValues: {
            ":g": { S: groupId }
        },
        ProjectionExpression: "group_id, user_id"
    };
    
    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Items);
        }
    });
};

const dbGetGroupRequest = function(groupId, requesterId, callback) { // check if group request exists
    if (!groupId || !requesterId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_requests",
        Key: {
            group_id: { S: groupId },
            user_id: { S: requesterId }
        },
        AttributesToGet: [ "group_id", "user_id" ]
    };
    
    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (!data.Item) {
            return callback(new Error("Not found"), null);
        } else {
            return callback(null, data.Item);
        }
    });
};

const dbDeleteGroupRequest = function(groupId, requesterId, callback) { // delete a join request
    if (!groupId || !requesterId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_requests",
        Key: {
            group_id: { S: groupId },
            user_id: { S: requesterId }
        },
        ReturnValues: "ALL_OLD"
    };
    
    db.deleteItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Item);
        }
    });
};

const dbAddGroupMember = function(groupId, memberId, callback) { // join a group (requires request for private groups)
    if (!groupId || !memberId) {
        console.log("here1");
        return callback(new Error("All fields required"), null);
    }
    
    const params = { // parameters to add user member
        TableName: "group_members",
        Item: {
            group_id: { S: groupId },
            member_id: { S: memberId }
        },
        ConditionExpression: "attribute_not_exists(group_id) AND attribute_not_exists(member_id)"
    };
        
    dbGetGroup(groupId, function(err, data) {
        if (err) {
            return callback(err, null);
        }
        if (data.isPrivate.BOOL) {
            dbDeleteGroupRequest(groupId, memberId, function(err2, data2) {
                if (err2) { // check for existence of request, if does not exist, do nothing
                    console.log("here2");
                    return callback(err2, null);
                } else { // if exists, delete request and add user member
                    db.putItem(params, function(err3, data3) {
                        if (err3) {
                            console.log("here3");
                            return callback(err3, null);
                        } else {
                            return callback(null, {});
                        }
                    });
                }
            });
        } else {
            db.putItem(params, function(err2, data2) {
                if (err2) {
                    console.log("here4");
                    return callback(err2, null);
                } else {
                    return callback(null, {});
                }
            });
        }
    });
};

const dbGetGroupMember = function(groupId, memberId, callback) { // check if group request exists
    if (!groupId || !memberId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_members",
        Key: {
            group_id: { S: groupId },
            member_id: { S: memberId }
        },
        AttributesToGet: [ "group_id", "member_id" ]
    };
    
    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (!data.Item) {
            return callback(new Error("Not found", null));
        } else {
            return callback(null, data.Item);
        }
    });
};

const dbGetAllMemberGroups = function(memberId, callback) { // get all groups a user is a member of
    if (!memberId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_members",
        FilterExpression: "member_id = :m",
        ExpressionAttributeValues: {
            ":m": { S: memberId }
        },
        ProjectionExpression: "group_id, member_id"
    };
    
    db.scan(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Items);
        }
    });
};

const dbDeleteGroupMember = function(groupId, memberId, callback) { // leave a group
    if (!groupId || !memberId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_members",
        Key: {
            group_id: { S: groupId },
            member_id: { S: memberId }
        },
        ReturnValues: "ALL_OLD"
    };
    
    db.deleteItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Item);
        }
    });
};

const dbAddGroupPost = function(groupId, postId, callback) { // add a post to a group
    if (!groupId || !postId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_posts",
        Item: {
            group_id: { S: groupId },
            post_id: { S: postId }
        },
        ConditionExpression: "attribute_not_exists(group_id) AND attribute_not_exists(post_id)"
    };
    
    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, {});
        }
    });
};

const dbGetGroupPost = function(groupId, postId, callback) { // get a group post
    if (!groupId || !postId) {
        return callback(new Error("All fields required."), null);
    }
    
    const params = {
        TableName: "group_posts",
        Key: {
            group_id: { S: groupId },
            post_id: { S: postId }
        },
        AttributesToGet: [ "group_id", "post_id" ]
    };
    
    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (!data.Item) {
            return callback(new Error("Not found"), null);
        } else {
            return callback(null, data.Item);
        }
    });
};

const dbGetGroupPosts = function(groupId, callback) { // get all posts in a group
    if (!groupId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_posts",
        KeyConditionExpression: "group_id = :g",
        ExpressionAttributeValues: {
            ":g": { S: groupId }
        },
        ProjectionExpression: "group_id, post_id"
    };
    
    db.query(params, async function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            try {
                const posts = await Promise.all(
                    data.Items.map(item =>
                        new Promise((resolve, reject) => {
                            dbGetPost(item.post_id.S, (err2, post) => {
                                if (err2) reject(err2);
                                else resolve(post);
                            });
                        })
                    )
                );
    
                posts.sort((a, b) =>
                    Date.parse(b.clock.S) - Date.parse(a.clock.S)
                );
    
                callback(null, posts);
            } catch (e) {
                callback(e, null);
            }
        }
    });
}

const dbDeleteGroupPost = function(groupId, postId, callback) { // delete a post from a group
    if (!groupId || !postId) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "group_posts",
        Key: {
            group_id: { S: groupId },
            post_id: { S: postId }
        },
        ReturnValues: "ALL_OLD"
    };
    
    db.deleteItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Item);
        }
    });
}


const posts = { 
    getWallByUserId: getWallByUserId,
    addPost: dbCreatePost,
    getPost: dbGetPost,
    getPostsByUser: dbGetPostsByUser,
    updatePost: dbUpdatePost,
    deletePost: dbDeletePost,
    addComment: dbCreateComment,
    getComment: dbGetComment,
    getCommentsByParent: dbGetCommentsByParent,
    getCommentsByPostId: dbGetCommentsByPostId,
    updateComment: dbUpdateComment,
    deleteComment: dbDeleteComment,
    addWallPost: dbAddWallPost,
    deleteWallPost: dbDeleteWallPost,
    tagUser: dbTagUser,
    createGroup: dbCreateGroup,
    getGroup: dbGetGroup,
    getAllGroups: dbGetAllGroups,
    createGroupRequest: dbCreateGroupRequest,
    getGroupRequest: dbGetGroupRequest,
    deleteGroupRequest: dbDeleteGroupRequest,
    addGroupMember: dbAddGroupMember,
    getGroupMember: dbGetGroupMember,
    getAllMemberGroups: dbGetAllMemberGroups,
    deleteGroupMember: dbDeleteGroupMember,
    addGroupPost: dbAddGroupPost,
    getGroupPost: dbGetGroupPost,
    getGroupPosts: dbGetGroupPosts,
    getAllGroupRequests: dbGetAllGroupRequests,
    deleteGroupPost: dbDeleteGroupPost
};

module.exports = posts;