// This file contains database operations (create, read, update, delete) for users, as well as authentication and database operations for friend relations.
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();
const uuid = require('uuid').v4;
const sha256 = require('js-sha256');

// user CRUD + login
const dbCheckAccount = function(username, pass, callback) { // check if account information is accurate, return full name
    if (!username || !pass) {
        return callback(new Error("All fields must be filled"), null);
    }
    const params = {
        TableName: "users",
        IndexName: "username-index",
        KeyConditionExpression:
            "USERTYPE = :t AND username = :u",
        ExpressionAttributeValues: {
            ":t": { S: "USER" },
            ":u": { S: username }
        },
        ProjectionExpression: "user_id, salt, hashCode, last_name, first_name, affiliation, username, email, birthday, profile_picture, isPrivate",
        Limit: 1
    };

    db.query(params, function(err, data) { // have to use scan instead of get b/c "username" is not primary key ("user_id" is)
        if (err) return callback(err, null);

        if (!data.Items || data.Items.length === 0) {
            return callback(new Error("No user found."), null);
        }

        const user = data.Items[0]; // scan can return multiple, take first

        const attemptedHash = sha256(pass + user.salt.S); // get hash from salt
        if (user.hashCode.S !== attemptedHash) {
            callback(new Error("Incorrect password."), null);
        } else {
            const params2 = { // update user to set them to logged in
                Item: {
                    hashCode: { S: user.hashCode.S },
                    user_id: { S: user.user_id.S },
                    salt: { S: user.salt.S },
                    last_name: { S: user.last_name.S },
                    first_name: { S: user.first_name.S },
                    affiliation: { S: user.affiliation.S },
                    username: { S: user.username.S },
                    logged_in: { BOOL: true },
                    email: { S: user.email.S },
                    birthday: { S: user.birthday.S },
                    USERTYPE: { S: "USER" }
                },
                TableName: "users",
                ReturnValues: "ALL_OLD"
            };

            // Preserve profile_picture and isPrivate if they exist
            if (user.profile_picture && user.profile_picture.S) {
                params2.Item.profile_picture = { S: user.profile_picture.S };
            }
            if (user.isPrivate !== undefined && user.isPrivate.BOOL !== undefined) {
                params2.Item.isPrivate = { BOOL: user.isPrivate.BOOL };
            }

            db.putItem(params2, function(err, data2) { // then, write new data to table
                if (err) {
                    callback(err, null);
                } else {
                    const { user_id, last_name, first_name, affiliation, username, email, birthday } = user;
                    callback(err, { user_id, last_name, first_name, affiliation, username, email, birthday });
                }
            });
        }
    });
}

const dbCreateUser = function(username, firstName, lastName, affiliation, email, birthday, pass, callback) {
    if (!username || !firstName || !lastName || !email || !birthday || !pass) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }

    // salt creation helper
    const SALT_LENGTH = 20;
    const SALT_CHARACTERS = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890";
    const createSalt = function() {
        var newSalt = "";
        for (var i = 0; i < SALT_LENGTH; i++) {
            newSalt += SALT_CHARACTERS[Math.floor(Math.random() * SALT_CHARACTERS.length)];
        }
        return newSalt;
    };

    const newSalt = createSalt();
    const newHash = sha256(pass + newSalt);
    const id = uuid();

    const params = {
        Item: {
            hashCode: { S: newHash },
            user_id: { S: id },
            salt: { S: newSalt },
            last_name: { S: lastName },
            first_name: { S: firstName },
            affiliation: { S: affiliation },
            username: { S: username },
            logged_in: { BOOL: true },
            USERTYPE: { S: "USER" }, // this field is used for the username gsi
            email: { S: email },
            birthday: { S: birthday },
            isPrivate: { BOOL: false }
        },
        ConditionExpression: "attribute_not_exists(user_id) AND attribute_not_exists(username)", // to prevent repeats
        TableName: "users",
        ReturnValues: "ALL_OLD"
    }

    db.putItem(params, function(err, data) {
        if (err) {
            callback(err, null);
        } else {
            callback(err, params.Item);
        }
    });
};

const dbLogout = function(id, callback) {
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }

    const params = { // first, get account
        TableName: "users", // get user (ID is primary key)
        Key: { user_id: { S: id } },
        AttributesToGet: [ 'hashCode', 'salt', 'logged_in', 'last_name', 'first_name', 'affiliation', 'username', 'email', 'birthday', 'profile_picture', 'isPrivate' ]
    };


    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (!data) {
            return callback(new Error("User does not exist"), null);
        }

        const user = data.Item;
        const params2 = { // update user to set them to not logged in
            Item: {
                hashCode: { S: user.hashCode.S },
                user_id: { S: id },
                salt: { S: user.salt.S },
                last_name: { S: user.last_name.S },
                first_name: { S: user.first_name.S },
                affiliation: { S: user.affiliation.S },
                username: { S: user.username.S },
                logged_in: { BOOL: false },
                email: { S: user.email.S },
                birthday: { S: user.birthday.S },
                USERTYPE: { S: "USER" }
            },
            TableName: "users",
            ReturnValues: "ALL_OLD"
        }

        // Preserve profile_picture and isPrivate if they exist
        if (user.profile_picture && user.profile_picture.S) {
            params2.Item.profile_picture = { S: user.profile_picture.S };
        }
        if (user.isPrivate !== undefined && user.isPrivate.BOOL !== undefined) {
            params2.Item.isPrivate = { BOOL: user.isPrivate.BOOL };
        }

        db.putItem(params2, function(err, data2) { // then, write new data to table
            if (err) {
                return callback(err, null);
            } else {
                return callback(err, {});
            }
        });
    });
}

const dbGetUser = function(id, callback) { // get a user by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }

    const params = {
        TableName: "users", // get user (ID is primary key)
        Key: { user_id: { S: id } },
        AttributesToGet: [ 'user_id', 'first_name', 'last_name', 'username', 'logged_in', 'affiliation', 'email', 'birthday', 'profile_picture', 'isPrivate' ]
    };

    db.getItem(params, function(err, data) {
        if (err) return callback(err, null);

        // TODO: make this return in a better format than the default
        if (!data.Item) {
            callback(new Error("User does not exist"), null); // if no user, return does not exist error
        } else {
            callback(null, data.Item); // if it worked, return the full name of the user
        }
    });
};

const dbGetUserByUsername = function(username, callback) {
    if (!username) {
        return callback(new Error("Username required."), null);
    }

    const params = {
        TableName: "users",
        IndexName: "username-index",
        KeyConditionExpression:
            "USERTYPE = :t AND username = :u",
        ExpressionAttributeValues: {
            ":t": { S: "USER" },
            ":u": { S: username }
        },
        ProjectionExpression: "user_id, first_name, last_name, username, logged_in, affiliation, email, birthday",
        Limit: 1
    };

    db.query(params, function(err, data) {
        if (err) return callback(err, null);
        if (!data.Items || data.Items.length === 0) {
            return callback(null, null);
        }
        return callback(null, data.Items[0]);
    });
};


const dbGetUsersByUsername = function(username, callback) {
    if (!username) {
        return callback(new Error("All fields required."), null);
    }

    const params = {
        TableName: "users",
        IndexName: "username-index",
        KeyConditionExpression:
            "USERTYPE = :t AND begins_with(username, :prefix)",
        ExpressionAttributeValues: {
            ":t": { S: "USER" },
            ":prefix": { S: username }
        },
        ProjectionExpression: "user_id, first_name, last_name, username, logged_in, affiliation, email, birthday",
        Limit: 5
    };

    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(err, data.Items);
        }
    });
};

const dbUpdateUser = function(id, username, firstName, lastName, affiliation, email, birthday, callback) {
    if (!username || !firstName || !lastName || !email || !birthday) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }

    const params = { // first, get account
        TableName: "users", // get user (ID is primary key)
        Key: { user_id: { S: id } },
        AttributesToGet: [ 'hashCode', 'salt', 'logged_in', 'profile_picture', 'isPrivate' ]
    };


    db.getItem(params, function(err, data) {
        if (err) return callback(err, null);

        const params = {
            Item: {
                hashCode: { S: data.Item.hashCode.S },
                user_id: { S: id },
                salt: { S: data.Item.salt.S },
                last_name: { S: lastName },
                first_name: { S: firstName },
                affiliation: { S: affiliation },
                username: { S: username },
                logged_in: { BOOL: data.Item.logged_in.BOOL },
                email: { S: email },
                birthday: { S: birthday },
                USERTYPE: { S: "USER" }
            },
            TableName: "users"
        }

        // Preserve profile_picture and isPrivate if they exist
        if (data.Item.profile_picture && data.Item.profile_picture.S) {
            params.Item.profile_picture = { S: data.Item.profile_picture.S };
        }
        if (data.Item.isPrivate !== undefined && data.Item.isPrivate.BOOL !== undefined) {
            params.Item.isPrivate = { BOOL: data.Item.isPrivate.BOOL };
        }

        db.putItem(params, function(err, data) { // then, write new data to table
            if (err) {
                callback(err, null);
            } else {
                callback(err, {});
            }
        });
    });
};

const dbUpdateEmail = function(userId, email, callback) {
    if (!userId || !email) {
        return callback(new Error("All fields must be filled"), null);
    }
    const params = { // update only email
        TableName: "users",
        Key: { user_id: { S: userId } },
        UpdateExpression: "SET email = :e",
        ExpressionAttributeValues: {
            ":e": { S: email }
        },
        ReturnValues: "UPDATED_NEW"
    };
    db.updateItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, {});
        }
    });
};

const dbUpdateAffiliation = function(userId, affiliation, callback) {
    if (!userId || !affiliation) {
        return callback(new Error("All fields must be filled"), null);
    }
    const params = { // update only affiliation
        TableName: "users",
        Key: { user_id: { S: userId } },
        UpdateExpression: "SET affiliation = :a",
        ExpressionAttributeValues: {
            ":a": { S: affiliation }
        },
        ReturnValues: "UPDATED_NEW"
    };
    db.updateItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, {});
        }
    });
};

const dbUpdatePassword = function(userId, password, callback) {
    if (!userId || !password) {
        return callback(new Error("All fields must be filled"), null);
    }

    const params = { // first, get account
        TableName: "users", // get user (ID is primary key)
        Key: { user_id: { S: userId } },
        AttributesToGet: [ 'salt' ]
    };

    db.getItem(params, function(err, data) { // get data first
        if (err) {
            return callback(err, null);
        } else if (!data.Item) {
            callback(new Error("User does not exist"), null); // if no user, return does not exist error
        } else {
            const newHash = sha256(password + data.Item.salt.S); // otherwise, use salt to find new hash
            const params2 = {
                TableName: "users",
                Key: { user_id: { S: userId } },
                UpdateExpression: "SET hashCode = :h", // write hash to database
                ExpressionAttributeValues: {
                    ":h": { S: newHash }
                },
                ReturnValues: "UPDATED_NEW"
            };
            db.updateItem(params2, function(err2, data2) {
                if (err2) {
                    return callback(err2, null);
                } else {
                    return callback(null, {});
                }
            });
        }
    });
};

const dbDeleteUserFriendships = function(id, callback) {
    console.log(id);
    dbGetUserFriends(id, function (err, data) {
        if (err) {
            callback(err, null);
        } else {
            console.log(err);
            console.log(data);
            let remaining = data.length;
            if (remaining === 0) {
                callback(null, null);
            }
            data.forEach(function (friendship) {
                dbDeleteFriendship(id, friendship.friend_id.S, function (err, data) {
                    if (err) {
                        dbDeleteFriendship(friendship.friend_id.S, id, function (err, data) {
                            if (err) {
                                console.log("Wrong");
                                console.log(friendship.friend_id.S);
                                console.log(id);
                                return callback(err, null);
                            }
                            else {
                                remaining -= 1;
                                if (remaining === 0) {
                                    return callback(null, null);
                                }
                            }
                        });
                    }
                    else {
                        remaining -= 1;
                        if (remaining === 0) {
                            return callback(null, null);
                        }
                    }
                });
            });
        }
    });
}

const dbDeleteUser = function(id, callback) {
    if (!id) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }

    dbDeleteUserFriendships(id, function(err, data) {
        if (err) {
            callback(err, null);
        }
    });

    const paramsDeleteUser = {
        TableName: "users",
        Key: { user_id: { S: id } },
        ReturnValues: "ALL_OLD"
    };

    db.deleteItem(paramsDeleteUser, function(err, data) { // perform deletion
        if (err) {
            callback(err, null);
        } else {
            callback(null, data.Attributes);
        }
    });
};

// friend CRD (no updating)
const dbCreateFriendship = function(id1, id2, clock, callback) {
    if (!id1 || !id2) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }

    const params = {
        TableName: "friends",
        Item: {
            friend1_id: { S: id1 },
            friend2_id: { S: id2 },
            clock: { S: clock }
        },
        ConditionExpression: "attribute_not_exists(friend1_id) AND attribute_not_exists(friend2_id)", // check for duplicates
        ReturnValues: "ALL_OLD"
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            const params2 = {
                TableName: "friends",
                Item: {
                    friend1_id: { S: id2 },
                    friend2_id: { S: id1 },
                    clock: { S: clock }
                },
                ConditionExpression: "attribute_not_exists(friend1_id) AND attribute_not_exists(friend2_id)", // check for duplicates
                ReturnValues: "ALL_OLD"
            };

            db.putItem(params2, function(err2, data2) {
                if (err2) {
                    return callback(err2, null);
                } else {
                    return callback(null, {});
                }
            });
        }
    });
};

const dbGetFriendship = function(id1, id2, callback) {
    if (!id1 || !id2) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }

    const params = {
        TableName: "friends",
        Key: {
            friend1_id: { S: id1 },
            friend2_id: { S: id2 }
        },
        AttributesToGet: [ 'friend1_id', 'friend2_id', 'clock' ]
    };

    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, data.Item);
        }
    });
};

const dbGetUserFriends = function(id, callback) {
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }

    const params1 = { // find friends if user is friend 1
        TableName: "friends",
        KeyConditionExpression: "friend1_id = :f1",
        ExpressionAttributeValues: {
            ":f1": { S: id }
        },
        ProjectionExpression: "friend2_id, clock"
    };

    db.query(params1, function(err, dataOriginal) {
        if (err) {
            return callback(err, null);
        }
        const params2 = {
            TableName: "friends", // find friends if user is friend 2
            FilterExpression: "friend2_id = :f",
            ExpressionAttributeValues: {
                ":f": { S: id }
            },
            ProjectionExpression: "friend1_id, clock"
        };

        db.scan(params2, function(err, data) {
            if (err) {
                return callback(err, null);
            }

            const friends = (data.Items || [])
                .filter(x => x.friend1_id?.S && x.clock?.S)  // Only include valid items
                .map(x => ({
                    friend_id: { S: x.friend1_id.S },
                    clock: { S: x.clock.S }
                }));

            const ids = friends.map(x => x.friend_id.S);

            const friends2 = (dataOriginal.Items || [])
                .filter(f => f.friend2_id?.S && f.clock?.S);  // Only include valid items

            for (var i = 0; i < friends2.length; i++) {
                const friendId = friends2[i].friend2_id.S;
                const clockValue = friends2[i].clock.S;

                if (!ids.includes(friendId)) { // remove duplicates
                    ids.push(friendId);
                    const newFriendObject = {
                        friend_id: { S: friendId },
                        clock: { S: clockValue }
                    };
                    friends.push(newFriendObject);
                }
            }

            friends.sort(function(firstFriendship, secondFriendship) { // sort friends by date
                const firstDate = Date.parse(firstFriendship.clock.S);
                const secondDate = Date.parse(secondFriendship.clock.S);
                if (firstDate < secondDate) {
                    return -1;
                } else if (firstDate > secondDate) {
                    return 1;
                } else {
                    return 0;
                }
            });

            return callback(null, friends);
        });
    });
}


const dbDeleteFriendship = function(id1, id2, callback) {
    if (!id1 || !id2) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }

    // Delete the first direction (id1 -> id2)
    const params1 = {
        TableName: "friends",
        Key: {
            friend1_id: { S: id1 },
            friend2_id: { S: id2 }
        },
        ReturnValues: "ALL_OLD"
    };

    db.deleteItem(params1, function(err1, data1) {
        if (err1) {
            return callback(err1, null);
        }

        // Delete the reverse direction (id2 -> id1)
        const params2 = {
            TableName: "friends",
            Key: {
                friend1_id: { S: id2 },
                friend2_id: { S: id1 }
            },
            ReturnValues: "ALL_OLD"
        };

        db.deleteItem(params2, function(err2, data2) {
            if (err2) {
                return callback(err2, null);
            }
            // Return data if either direction had a record
            const result = data1.Attributes || data2.Attributes;
            callback(null, result);
        });
    });
};

// friend request CRD
const dbCreateFriendRequest = function(friend1_id, friend2_id, callback) {
    if (!friend1_id || !friend2_id) {
        return callback(new Error("All fields required"), null);
    }

    const clock = Date();
    const params = {
        TableName: "friend_requests",
        Item: {
            friend1_id: { S: friend1_id },
            friend2_id: { S: friend2_id },
            clock: { S: clock }
        },
        ConditionExpression: "attribute_not_exists(friend1_id) AND attribute_not_exists(friend2_id)", // check for duplicates
        ReturnValues: "ALL_OLD"
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, {});
        }
    });
};

const dbGetFriendRequest = function(friend1_id, friend2_id, callback) {
    if (!friend1_id || !friend2_id) {
        return callback(new Error("All fields required"), null);
    }

    const params = {
        TableName: "friend_requests",
        Key: {
            friend2_id: { S: friend2_id },
            friend1_id: { S: friend1_id }
        },
        AttributesToGet: [ 'friend1_id', 'friend2_id', 'clock' ]
    };

    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, data.Item);
        }
    });
}

const dbGetUserFriendRequests = function(id, callback) {
    if (!id) {
        return callback(new Error("All fields required"), null);
    }

    const params = { // get all requests where current user is the one being requested
        TableName: "friend_requests",
        KeyConditionExpression: "friend2_id = :f",
        ExpressionAttributeValues: {
            ":f": { S: id }
        },
        ProjectionExpression: "friend1_id, friend2_id, clock"
    };

    db.query(params, function(err, data) {
        if (err) {
            callback(err, null);
        } else {
            callback(null, data.Items);
        }
    });
};

const dbDeleteFriendRequest = function(friend1_id, friend2_id, callback) {
    if (!friend1_id || !friend2_id) {
        return callback(new Error("All fields required"), null);
    }

    const params = {
        TableName: "friend_requests",
        Key: {
            friend1_id: { S: friend1_id },
            friend2_id: { S: friend2_id }
        },
        ReturnValues: "ALL_OLD"
    };

    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            callback(err, null);
        } else {
            callback(null, data.Attributes);
        }
    });
};

const dbUpdateUserPrivacy = function(userId, isPrivate, callback) {
    const params = {
        TableName: 'users',
        Key: {
            'user_id': { S: userId }
        },
        UpdateExpression: 'SET isPrivate = :isPrivate',
        ExpressionAttributeValues: {
            ':isPrivate': { BOOL: isPrivate }
        },
        ReturnValues: 'ALL_NEW'
    };
    db.updateItem(params, function(err, data) {
        if (err) {
            callback(err, null);
        } else {
            callback(null, data.Attributes);
        }
    });
}

const dbUpdateProfilePicture = function(userId, profilePictureUrl, callback) {
    if (!userId || !profilePictureUrl) {
        return callback(new Error("User ID and profile picture URL are required"), null);
    }

    const params = {
        TableName: 'users',
        Key: {
            'user_id': { S: userId }
        },
        UpdateExpression: 'SET profile_picture = :pp',
        ExpressionAttributeValues: {
            ':pp': { S: profilePictureUrl }
        },
        ReturnValues: 'ALL_NEW'
    };

    db.updateItem(params, function(err, data) {
        if (err) {
            callback(err, null);
        } else {
            callback(null, data.Attributes);
        }
    });
}

module.exports = {
    checkAccount: dbCheckAccount,
    logout: dbLogout,
    addUser: dbCreateUser,
    getUser: dbGetUser,
    getUsersByUsername: dbGetUsersByUsername,
    getUserByUsername: dbGetUserByUsername,
    updateUser: dbUpdateUser,
    updateEmail: dbUpdateEmail,
    updateAffiliation: dbUpdateAffiliation,
    updatePassword: dbUpdatePassword,
    deleteUser: dbDeleteUser,
    createFriendship: dbCreateFriendship,
    getFriends: dbGetUserFriends,
    getFriendship: dbGetFriendship,
    deleteFriendship: dbDeleteFriendship,
    createFriendRequest: dbCreateFriendRequest,
    getFriendRequest: dbGetFriendRequest,
    getUserFriendRequests: dbGetUserFriendRequests,
    deleteFriendRequest: dbDeleteFriendRequest,
    updateUserPrivacy: dbUpdateUserPrivacy,
    updateProfilePicture: dbUpdateProfilePicture
};
