// This file contains database operations (create, read, update, delete) for chats, chat invites, chat messages, and chat membership.
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();
const uuid = require('uuid').v4;

// chat CRUD
const dbCreateChat = function(creatorId, name, callback) {
    if (!creatorId || !name) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }
    
    const chatId = uuid();
    const params = {
        TableName: "chats",
        Item: {
            chat_id: { S: chatId },
            creator_id: { S: creatorId },
            chat_name: { S: name },
            members: { S: creatorId },
            CHATTYPE: { S: "CHAT" }
        },
        ConditionExpression: "attribute_not_exists(chat_id)" // check for duplicates
    };

    db.putItem(params, function(err, data) { // create chat
        if (err) {
            return callback(err, null);
        }
        
        const params2 = {
            TableName: "chat_members",
            Item: {
                member_id: { S: creatorId },
                chat_id: { S: chatId }
            }
        };
        
        db.putItem(params2, function(err2, data2) { // add user as member
            if (err2) {
                return callback(err2, null);
            } else {
                return callback(null, { chatId });
            }
        });
    });
};


const dbGetChat = function(id, callback) { // get a chat by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "chats", // get chat (ID is primary key)
        Key: { chat_id: { S: id } },
        AttributesToGet: [ 'creator_id', 'chat_name', 'chat_id', 'members' ]
    };

    db.getItem(params, function(err, data) {
        if (err) return callback(err, null);

        if (!data.Item) {
            callback(new Error("Chat does not exist"), null); // if no chat, return does not exist error
        } else {
            callback(null, data.Item); // if it worked, return the chat
        }
    });
};

const dbGetChatMembers = function(members, callback) {
    if (!members) {
        return callback(new Error("All fields required"), null);
    }
    
    const params = {
        TableName: "chats",
        IndexName: "members-index",
        KeyConditionExpression:
            "CHATTYPE = :t AND members = :m",
        ExpressionAttributeValues: {
            ":t": { S: "CHAT" },
            ":m": { S: members }
        },
        ProjectionExpression: "chat_id, creator_id, chat_name, members",
        Limit: 1
    };

    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (!data.Items || data.Items.length === 0) {
            return callback(null, null);
        } else {
            return callback(null, data.Items[0]);
        }
    });
}

const dbDeleteChat = function(id, creatorId, callback) {
    if (!id || !creatorId) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }
    
    const params = {
        TableName: "chats",
        Key: {
            chat_id: { S: id }
        },
        ReturnValues: "ALL_OLD"
    };

    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            callback(err, null);
        } else {
            callback(null, {});
        }
    });
};

// chat invites CRD
const dbCreateChatInvite = function(inviterId, invitedId, chatId, callback) {
    if (!inviterId || !invitedId || !chatId) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }

    const params = {
        TableName: "chat_invites",
        Item: {
            inviter_id: { S: inviterId },
            invited_id: { S: invitedId },
            chat_id: { S: chatId }
        },
        ConditionExpression: "attribute_not_exists(invited_id) AND attribute_not_exists(chat_id)" // check for duplicates
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, {});
        }
    });
};


const dbGetUserChatInvites = function(id, callback) { // get a user by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "chat_invites",
        KeyConditionExpression: "invited_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: id }
        },
        ProjectionExpression: "inviter_id, chat_id"
    };

    db.query(params, function(err, data) {
        if (err) {
            console.log(err);
            return callback(err, null);
        } else {
            return callback(null, data.Items);
        }
    });
}

const dbDeleteChatInvite = function(invitedId, inviterId, chatId, callback) {
    if (!invitedId || !chatId) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }
    
    const params = {
        TableName: "chat_invites",
        Key: {
            invited_id: { S: invitedId },
            inviter_id: { S: inviterId },
            chat_id: { S: chatId }
        }
    };

    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            callback(err, null);
        } else {
            callback(null, {});
        }
    });
};

// chat messages CR "message_id", "sender_id", "chat_id", "content", "clock"
const dbCreateChatMessage = function(senderId, chatId, content, clock, callback) {
    if (!senderId || !chatId || !content || !clock) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }
    
    const chatMessageId = uuid();
    const params = {
        TableName: "chat_messages",
        Item: {
            message_id: { S: chatMessageId },
            chat_id: { S: chatId },
            sender_id: { S: senderId },
            content: { S: content },
            clock: { S: clock }
        },
        ConditionExpression: "attribute_not_exists(message_id)" // check for duplicates
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, {});
        }
    });
};


const dbGetChatMessage = function(id, callback) { // get a post by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "chat_messages", // get chat message (ID is primary key)
        Key: { message_id: { S: id } },
        AttributesToGet: [ "message_id", "sender_id", "chat_id", "content", "clock" ]
    };

    db.getItem(params, function(err, data) {
        if (err) return callback(err, null);
        if (!data.Item) {
            callback(new Error("Message does not exist"), null); // if no post, return does not exist error
        } else {
            callback(null, data.Item); // if it worked, return the post
        }
    });
};

const dbGetChatMessagesByChat = function(id, callback) {
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }

    const params1 = {
        TableName: "chat_messages",
        FilterExpression: "chat_id = :i",
        ExpressionAttributeValues: {
            ":i": { S: id }
        },
        ProjectionExpression: "message_id, sender_id, chat_id, content, clock"
    };

    db.scan(params1, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Items);
        }
    });
};

// Get all messages between two users across all their shared chats
// excludeChatId: optional chat ID to exclude from the search (e.g., the new chat being joined)
const dbGetMessagesBetweenUsers = function(userId1, userId2, excludeChatId, callback) {
    if (!userId1 || !userId2) {
        return callback(null, []); // Return empty array instead of error to not block invite acceptance
    }

    // First, find all chats where user1 is a member
    const params1 = {
        TableName: "chat_members",
        KeyConditionExpression: "member_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: userId1 }
        },
        ProjectionExpression: "chat_id"
    };

    db.query(params1, function(err1, data1) {
        if (err1) {
            console.error("Error querying user1 chats:", err1);
            return callback(null, []); // Return empty array on error
        }

        if (!data1 || !data1.Items || data1.Items.length === 0) {
            return callback(null, []);
        }

        // Filter out the excluded chat
        let user1Chats = data1.Items.map(item => item.chat_id.S);
        if (excludeChatId) {
            user1Chats = user1Chats.filter(id => id !== excludeChatId);
        }

        if (user1Chats.length === 0) {
            return callback(null, []);
        }

        // Check which of these chats user2 is also a member of
        let sharedChats = [];
        let checked = 0;

        user1Chats.forEach(chatId => {
            const params2 = {
                TableName: "chat_members",
                Key: {
                    member_id: { S: userId2 },
                    chat_id: { S: chatId }
                },
                AttributesToGet: ['member_id', 'chat_id']
            };

            db.getItem(params2, function(err2, data2) {
                checked++;
                if (!err2 && data2 && data2.Item) {
                    sharedChats.push(chatId);
                }

                if (checked === user1Chats.length) {
                    // Now get all messages from shared chats between these two users
                    if (sharedChats.length === 0) {
                        return callback(null, []);
                    }

                    // Get messages from all shared chats
                    let allMessages = [];
                    let chatsFetched = 0;

                    sharedChats.forEach(sharedChatId => {
                        const params3 = {
                            TableName: "chat_messages",
                            FilterExpression: "chat_id = :c AND (sender_id = :u1 OR sender_id = :u2)",
                            ExpressionAttributeValues: {
                                ":c": { S: sharedChatId },
                                ":u1": { S: userId1 },
                                ":u2": { S: userId2 }
                            },
                            ProjectionExpression: "message_id, sender_id, chat_id, content, clock"
                        };

                        db.scan(params3, function(err3, data3) {
                            chatsFetched++;
                            if (!err3 && data3 && data3.Items) {
                                allMessages = allMessages.concat(data3.Items);
                            }

                            if (chatsFetched === sharedChats.length) {
                                // Sort by timestamp
                                allMessages.sort((a, b) => {
                                    return new Date(a.clock.S) - new Date(b.clock.S);
                                });
                                return callback(null, allMessages);
                            }
                        });
                    });
                }
            });
        });
    });
};

// chat membership CRD
const dbAddChatMember = function(invitedId, inviterId, chatId, callback) {
    if (!invitedId || !chatId) {
        return callback(new Error("Must pass in IDs"), null);
    }

    const params1 = {
        TableName: "chat_invites",
        Key: {
            invited_id: { S: invitedId },
            chat_id: { S: chatId }
        }
    };
    
    const updateChatMembers = function() { // update the chat member string
        const params3 = {
            TableName: "chats",
            Key: {
                chat_id: { S: chatId }
            },
            AttributesToGet: [ "members" ]
        };

        db.getItem(params3, function(err3, data3) {
            if (err3) {
                return callback(err3, null);
            } else {
                const membersArray = data3.Item.members.S.split(",");
                membersArray.push(invitedId);
                membersArray.sort(); // sort so there is a common order
                const params4 = {
                    TableName: "chats",
                    Key: { chat_id: { S: chatId } },
                    UpdateExpression: "SET members = :m", // write new members to database
                    ExpressionAttributeValues: {
                        ":m": { S: membersArray.join(",") } // write members together to one string
                    },
                    ReturnValues: "UPDATED_NEW"
                };
                db.updateItem(params4, function(err4, data4) {
                    if (err4) {
                        console.error('Error updating chat members:', err4);
                    }
                });
            }
        });
    }

    db.deleteItem(params1, function(err1, data1) { // delete so the invitation is gone
        if (err1) {
            return callback(err1, null);
        }

        const params2 = {
            TableName: "chat_members",
            Item: {
                member_id: { S: invitedId },
                chat_id: { S: chatId }
            }
        };

        db.putItem(params2, function(err2, data2) {
            if (err2) {
                return callback(err2, null);
            } else {
                updateChatMembers();
                return callback(null, {});
            }
        });
    });
};

const dbCheckChatMember = function(id, chatId, callback) {
    if (!id || !chatId) {
        return callback(new Error("Must pass in IDs"), null);
    }
    
    const params = {
        TableName: "chat_members",
        Key: {
            member_id: { S: id },
            chat_id: { S: chatId }
        },
        AttributesToGet: [ 'member_id', 'chat_id' ]
    }
    
    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else if (!data.Item) {
            return callback(new Error("User is not chat member"), null);
        } else {
            return callback(null, data.Item);
        }
    });
};

const dbGetUsersByChat = function(id, callback) {
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }

    const params = {
        TableName: "chat_members",
        FilterExpression: "chat_id = :c",
        ExpressionAttributeValues: {
            ":c": { S: id }
        },
        ProjectionExpression: "member_id"
    };

    db.scan(params, function(err, data) { // not efficient - this is not used in the frontend, no way to list users (yet)
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Items);
        }
    });
}

const dbGetChatsByUser = function(id, callback) { // get all posts by user ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        KeyConditionExpression: "member_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: id }
        },
        TableName: "chat_members",
        ProjectionExpression: "chat_id, member_id"
    };

    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, data.Items);
        }
    });
};

const dbRemoveChatMember = function(id, chatId, callback) {
    if (!id || !chatId) {
        return callback(new Error("Must pass in IDs"), null);
    }
    
    const params = {
        TableName: "chat_members",
        Key: {
            member_id: { S: id },
            chat_id: { S: chatId }
        }
    }
    
    db.deleteItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            return callback(null, {});
        }
    });
};

module.exports = {
    createChat: dbCreateChat,
    getChat: dbGetChat,
    getChatMembers: dbGetChatMembers,
    getChatsByUser: dbGetChatsByUser,
    getUsersByChat: dbGetUsersByChat,
    deleteChat: dbDeleteChat,
    createChatInvite: dbCreateChatInvite,
    getUserChatInvites: dbGetUserChatInvites,
    deleteChatInvite: dbDeleteChatInvite,
    createChatMessage: dbCreateChatMessage,
    getChatMessage: dbGetChatMessage,
    getChatMessagesByChat: dbGetChatMessagesByChat,
    getMessagesBetweenUsers: dbGetMessagesBetweenUsers,
    addChatMember: dbAddChatMember,
    checkChatMember: dbCheckChatMember,
    removeChatMember: dbRemoveChatMember
};