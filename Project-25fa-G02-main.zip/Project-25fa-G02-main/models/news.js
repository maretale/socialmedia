// This file contains creation, reading, and deletion for news topic interests of users, as well as reading of data for articles and article feeds.
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();

// Import feed and search utilities
const feedService = require('../news/newsFeedService');
const searchService = require('../news/newsSearch');
const sparkIntegration = require('../news/sparkIntegration');

// interests CRD
const dbCreateInterest = function(userId, type, callback) {
    if (!userId || !type) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }

    const params = {
        TableName: "interests",
        Item: {
            user_id: { S: userId },
            news_type: { S: type }
        },
        ConditionExpression: "attribute_not_exists(user_id) AND attribute_not_exists(news_type)" // check for duplicates
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, { userId, newsType: type });
        }
    });
};


const dbGetUserInterests = function(id, callback) { // get user interests by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "interests",
        KeyConditionExpression: "user_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: id }
        },
        ProjectionExpression: "news_type"
    };

    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            const interests = (data.Items || [])
                .filter(item => item.news_type?.S)
                .map(item => item.news_type.S);
            return callback(null, interests);
        }
    });
};

const dbDeleteInterest = function(userId, type, callback) {
    if (!userId || !type) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }
    
    const params = {
        TableName: "interests",
        Key: {
            user_id: { S: userId },
            news_type: { S: type }
        }
    };

    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            callback(err, null);
        } else {
            callback(null, { userId, newsType: type });
        }
    });
};

// article reading
const dbGetArticle = function(id, callback) { // get an article by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "articles", // get post (ID is primary key)
        Key: { article_id: { S: id } },
        AttributesToGet: [ 'article_id', 'category', 'authors', 'headline', 'link', 'short_description', 'published_date' ]
    };

    db.getItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        }

        // TODO: make this return in a better format than the default
        if (!data.Item) {
            callback(new Error("Article does not exist"), null); // if no article, return does not exist error
        } else {
            const article = {
                articleId: data.Item.article_id?.S || id,
                category: data.Item.category?.S || 'Uncategorized',
                authors: data.Item.authors?.S || 'Unknown',
                headline: data.Item.headline?.S || 'Untitled',
                link: data.Item.link?.S || '#',
                shortDescription: data.Item.short_description?.S || '',
                date: data.Item.published_date?.S || data.Item.date?.S || ''
            };
            callback(null, article); // if it worked, return the article
        }
    });
};

// article feed reading
const dbGetUserFeed = function(id, callback) { // get user news feed by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "feeds",
        KeyConditionExpression: "user_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: id }
        },
        ProjectionExpression: "article_id, #ts",
        ExpressionAttributeNames: {
            "#ts": "timestamp"
        },
        ScanIndexForward: false  // Sort by timestamp in descending order (newest first)
    };

    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            const feedItems = (data.Items || [])
                .filter(item => item.article_id?.S && item.timestamp?.S)
                .map(item => ({
                    articleId: item.article_id.S,
                    timestamp: item.timestamp.S
                }))
                .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)); // Sort by timestamp descending (newest first)
            return callback(null, feedItems);
        }
    });
};

// article likes CRD
const dbCreateArticleLike = function(userId, articleId, callback) {
    if (!userId || !articleId) {
        return callback(new Error("All fields must be filled"), null); // check that all fields are filled
    }

    const params = {
        TableName: "article_likes",
        Item: {
            user_id: { S: userId },
            article_id: { S: articleId }
        },
        ConditionExpression: "attribute_not_exists(user_id) AND attribute_not_exists(article_id)" // check for duplicates
    };

    db.putItem(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            callback(null, { userId, articleId });
        }
    });
};


const dbGetUserArticleLikes = function(id, callback) { // get user likes by ID
    if (!id) {
        return callback(new Error("Must pass in ID"), null);
    }
    
    const params = {
        TableName: "article_likes",
        KeyConditionExpression: "user_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: id }
        },
        ProjectionExpression: "article_id"
    };

    db.query(params, function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
            const likedArticles = (data.Items || [])
                .filter(item => item.article_id?.S)
                .map(item => item.article_id.S);
            return callback(null, likedArticles);
        }
    });
}

const dbDeleteArticleLike = function(userId, articleId, callback) {
    if (!userId || !articleId) {
        return callback(new Error("All fields required"), null); // make sure data is passed
    }
    
    const params = {
        TableName: "article_likes",
        Key: {
            user_id: { S: userId },
            article_id: { S: articleId }
        }
    };

    db.deleteItem(params, function(err, data) { // perform deletion
        if (err) {
            callback(err, null);
        } else {
            callback(null, { userId, articleId });
        }
    });
};

// Cache for categories (refreshed every hour)
let categoriesCache = {
    categories: null,
    timestamp: 0
};
const CATEGORIES_CACHE_TTL = 60 * 60 * 1000; // 1 hour

// get all valid categories (with caching)
const dbGetAllCategories = function(callback) {
    // Return cached categories if still valid
    const now = Date.now();
    if (categoriesCache.categories && (now - categoriesCache.timestamp) < CATEGORIES_CACHE_TTL) {
        return callback(null, categoriesCache.categories);
    }

    const params = {
        TableName: 'articles',
        ProjectionExpression: 'category'
    };

    const categories = new Set();

    const scanRecursive = function(lastKey) {
        if (lastKey) {
            params.ExclusiveStartKey = lastKey;
        }

        db.scan(params, function(err, data) {
            if (err) {
                return callback(err, null);
            }

            // Add categories to set
            (data.Items || []).forEach(item => {
                if (item.category?.S) {
                    categories.add(item.category.S);
                }
            });

            // Continue scanning if more data
            if (data.LastEvaluatedKey) {
                scanRecursive(data.LastEvaluatedKey);
            } else {
                // Done scanning, cache and return sorted array
                const sortedCategories = Array.from(categories).sort();
                categoriesCache.categories = sortedCategories;
                categoriesCache.timestamp = Date.now();
                callback(null, sortedCategories);
            }
        });
    };

    scanRecursive(null);
};

// Wrapper for feed update that triggers Spark job
const updateFeedOnInterestChange = async function(userId) {
    console.log(`Interest changed for user ${userId}. Running Spark job first...`);

    try {
        // First: Trigger Spark job and wait for it to complete
        await sparkIntegration.triggerSparkJobForUser(userId);
        console.log(`Spark job completed for user ${userId}. Now updating feed...`);

        // Second: Update feed with articles using the new weights
        await feedService.updateFeedOnInterestChange(userId);
        console.log(`Feed updated for user ${userId} with new recommendations`);
    } catch (err) {
        console.error(`Error in updateFeedOnInterestChange for user ${userId}:`, err);
        // Fallback: update feed anyway with default weights
        await feedService.updateFeedOnInterestChange(userId);
    }
};

const news = { 
    addInterest: dbCreateInterest,
    getUserInterests: dbGetUserInterests,
    deleteInterest: dbDeleteInterest,
    getArticle: dbGetArticle,
    getUserFeed: dbGetUserFeed,
    addArticleLike: dbCreateArticleLike,
    getUserArticleLikes: dbGetUserArticleLikes,
    deleteArticleLike: dbDeleteArticleLike,
    getAllCategories: dbGetAllCategories,

    // Feed update functions
    updateUserFeed: feedService.updateUserFeed,
    updateFeedOnInterestChange: updateFeedOnInterestChange,

    // Search functions
    searchArticles: searchService.searchArticles,
    getSearchSuggestions: searchService.getSearchSuggestions
};

module.exports = news;