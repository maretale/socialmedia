const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();
const async = require('async');
const uuid = require('uuid').v4;

var initTable = function(tableName, columns, types, mainColumns, gsi, callback) {
    db.listTables(function(err, data) {
        if (err)  {
            console.log(err, err.stack);
            callback('Error when listing tables: '+err, null);
        } else {
            console.log("Connected to AWS DynamoDB");

            var tables = data.TableNames.toString().split(",");
            console.log("Tables in DynamoDB: " + tables);
            if (tables.indexOf(tableName) == -1) {
                console.log("Creating new table '"+tableName+"'");
                try {
                    var params = (gsi.length === 2) ? {
                        AttributeDefinitions: [
                            ...(mainColumns.concat(gsi)).map(x => ({
                                AttributeName: x,
                                AttributeType: types[columns.indexOf(x)]
                            }))
                        ],
                        KeySchema: mainColumns.map((x, i) => ({
                                AttributeName: x,
                                KeyType: (i === 0) ? 'HASH' : 'RANGE' // set it to hash or sorting key
                            })
                        ),
                        GlobalSecondaryIndexes: [
                            {
                                IndexName: `${gsi[1]}-index`,
                                KeySchema: [
                                    { AttributeName: gsi[0], KeyType: "HASH" },
                                    { AttributeName: gsi[1], KeyType: "RANGE" }
                                ],
                                Projection: { ProjectionType: "ALL" },
                                ProvisionedThroughput: {
                                    ReadCapacityUnits: 20,
                                    WriteCapacityUnits: 20
                                }
                            }
                        ],
                        ProvisionedThroughput: {
                            ReadCapacityUnits: 20,       // DANGER: Don't increase this too much; stay within the free tier!
                            WriteCapacityUnits: 20       // DANGER: Don't increase this too much; stay within the free tier!
                        },
                        TableName: tableName /* required */
                    } : {
                        AttributeDefinitions: [
                            ...mainColumns.map(x => ({
                                AttributeName: x,
                                AttributeType: types[columns.indexOf(x)]
                            }))
                        ],
                        KeySchema: mainColumns.map((x, i) => ({
                                AttributeName: x,
                                KeyType: (i === 0) ? 'HASH' : 'RANGE' // set it to hash or sorting key
                            })
                        ),
                        ProvisionedThroughput: {
                            ReadCapacityUnits: 20,       // DANGER: Don't increase this too much; stay within the free tier!
                            WriteCapacityUnits: 20       // DANGER: Don't increase this too much; stay within the free tier!
                        },
                        TableName: tableName /* required */
                    };
                } catch (e) {
                    console.log(tableName);
                    console.log(e);
                }

                db.createTable(params, function(err, data) {
                    if (err) {
                        console.log(err)
                        callback('Error while creating table '+tableName+': '+err, null);
                    }
                    else {
                        console.log("Table is being created; waiting for 20 seconds...");
                        setTimeout(function() {
                            console.log("Success");
                            callback(null, 'Success');
                        }, 20000);
                    }
                });
            } else {
                console.log("Table "+tableName+" already exists");
                callback(null, 'Success');
            }
        }
    });
}

var putIntoTable = function(tableName, columns, values, types, callback) {
    var toAdd = {};
    for (var i = 0; i < columns.length; i++) {
        toAdd[columns[i]] = { [types[i]]: values[i] };
    }
    var params = {
        Item: toAdd,
        TableName: tableName,
        ReturnValues: 'NONE'
    };

    db.putItem(params, function(err, data){
        if (err) {
            callback(err)
        } else {
            callback(null, 'Success')
        }
    });
}

const makeTable = function(items, tableName, fields, types, mainColumns, gsiColumns) {
    initTable(tableName, fields, types, mainColumns, gsiColumns, function (err, data) {
        if (err) {
            console.log("Error while initializing table " + tableName + ": " + err);
        } else {
            async.forEach(items, function(item, callback) {
                putIntoTable(tableName, fields, item, types, function(err, data) {
                    if (err) {
                        console.log("Error while adding " + item + ": " + err);
                    }
                })
            }, function() { console.log("Upload complete") });
        }
    });
}

const userDBName = "users";
const userFields = ["user_id", "username", "hashCode", "salt", "first_name", "last_name", "affiliation", "email", "birthday", "logged_in", "isPrivate", "USERTYPE"];
const users = [
    ["123456", "first", "7a37b85c8918eac19a9089c0fa5a2ab4dce3f90528dcdeec108b23ddf3607b99", "salt", "nico", "nico", "University of Pennsylvania", "nac1@seas.upenn.edu", "Wed, Oct 15, 2025", false, false, "USER"],
    ["234567", "second", "7a37b85c8918eac19a9089c0fa5a2ab4dce3f90528dcdeec108b23ddf3607b99", "salt", "nico ii", "lastname", "University of Pennsylvania", "nicocloutier1@gmail.com", "Wed, Oct 15, 2025", false, true, "USER"],
    ["345678", "third", "7a37b85c8918eac19a9089c0fa5a2ab4dce3f90528dcdeec108b23ddf3607b99", "salt", "nico iii", "lastname", "University of Pennsylvania", "nicocloutier1@gmail.com", "Wed, Oct 15, 2025", false, false, "USER"],
    ["456789", "fourth", "7a37b85c8918eac19a9089c0fa5a2ab4dce3f90528dcdeec108b23ddf3607b99", "salt", "nico iv", "lastname", "Drexel University", "nicocloutier1@gmail.com", "Wed, Oct 15, 2025", false, true, "USER"],
    ["567890", "fifth", "7a37b85c8918eac19a9089c0fa5a2ab4dce3f90528dcdeec108b23ddf3607b99", "salt", "nico v", "lastname", "University of Pennsylvania", "nicocloutier1@gmail.com", "Wed, Oct 15, 2025", false, false, "USER"],
];
const userTypes = ["S", "S", "S", "S", "S", "S", "S", "S", "S", "BOOL", "BOOL", "S" ];
makeTable(users, userDBName, userFields, userTypes, ["user_id"], ["USERTYPE", "username"]);

const interestDBName = "interests";
const interestFields = ["user_id", "news_type"];
const interests = [
    ["123456", "POLITICS"],
    ["123456", "WORLD NEWS"],
    ["123456", "BUSINESS"],
    ["234567", "ENTERTAINMENT"],
    ["234567", "SPORTS"],
    ["345678", "TECHNOLOGY"],
    ["345678", "SCIENCE"]
];
const interestTypes = ["S", "S"];
makeTable(interests, interestDBName, interestFields, interestTypes, ["user_id", "news_type"], []);

const postDBName = "posts";
const postFields = ["post_id", "wall_user_id", "creator_id", "status_update", "content", "clock", "tagged_users"];
const posts = [ ["654321", "123456", "234567", false, "Sample post", "Sat Nov 15 2025 20:16:11 GMT-0500 (Eastern Standard Time)", ""],
    ["890890", "123456", "123456", true, "Sample status update", "Sat Nov 15 2025 20:14:11 GMT-0500 (Eastern Standard Time)", ""],
    ["098098", "345678", "345678", true, "Sample status update ii", "Sat Nov 15 2025 20:16:11 GMT-0500 (Eastern Standard Time)", ""] ];
const postTypes = ["S", "S", "S", "BOOL", "S", "S", "S"];
makeTable(posts, postDBName, postFields, postTypes, ["post_id"], []);

const wallPostDBName = "wall_posts";
const wallPostFields = ["post_id", "wall_user_id"];
const wallPosts = [ ["654321", "123456"], ["654321", "234567"], ["890890", "123456"], ["098098", "345678"] ];
const wallPostTypes = ["S", "S"];
makeTable(wallPosts, wallPostDBName, wallPostFields, wallPostTypes, ["wall_user_id", "post_id"], []);

const commentDBName = "comments";
const commentFields = ["comment_id", "parent_id", "post_id", "creator_id", "content", "clock", "COMMENTTYPE"];
const comments = [ ["98876", "", "654321", "123456", "Sample comment", "Sat Nov 15 2025 20:16:11 GMT-0500 (Eastern Standard Time)", "COMMENT"] ];
const commentTypes = ["S", "S", "S", "S", "S", "S", "S"];
makeTable(comments, commentDBName, commentFields, commentTypes, ["comment_id"], ["COMMENTTYPE", "post_id"]);

const friendDBName = "friends";
const friendFields = ["friend1_id", "friend2_id", "clock"];
const friends = [ ["123456", "234567", "Fri Nov 14 2025 20:16:11 GMT-0500 (Eastern Standard Time)" ],
    ["234567", "123456", "Fri Nov 14 2025 20:16:11 GMT-0500 (Eastern Standard Time)" ],
    ["234567", "345678", "Sat Nov 15 2025 20:16:11 GMT-0500 (Eastern Standard Time)" ],
    ["345678", "234567", "Sat Nov 15 2025 20:16:11 GMT-0500 (Eastern Standard Time)" ]    ];
const friendTypes = ["S", "S", "S"];
makeTable(friends, friendDBName, friendFields, friendTypes, ["friend1_id", "friend2_id"], []);

const friendRequestDBName = "friend_requests";
const friendRequestFields = ["friend1_id", "friend2_id", "clock"];
const friendRequests = [ ["123456", "345678", "Thu Nov 13 2025 20:16:11 GMT-0500 (Eastern Standard Time)"],
    ["456789", "123456", "Tue Nov 11 2025 20:16:11 GMT-0500 (Eastern Standard Time)"] ];
const friendRequestTypes = ["S", "S", "S"];
makeTable(friendRequests, friendRequestDBName, friendRequestFields, friendRequestTypes, ["friend2_id", "friend1_id"], []);

const chatDBName = "chats";
const chatFields = ["chat_id", "creator_id", "chat_name", "members", "CHATTYPE"];
const chats = [ ["787878", "123456", "First Chat", "123456,234567", "CHAT"], ["878787", "234567", "Second Chat", "234567", "CHAT"] ];
const chatTypes = ["S", "S", "S", "S", "S"];
makeTable(chats, chatDBName, chatFields, chatTypes, ["chat_id"], ["CHATTYPE", "members"]);

const chatMemberDBName = "chat_members";
const chatMemberFields = ["member_id", "chat_id"];
const chatMembers = [ ["123456", "787878"], ["234567", "787878"], ["234567", "878787"] ];
const chatMemberTypes = ["S", "S"];
makeTable(chatMembers, chatMemberDBName, chatMemberFields, chatMemberTypes, ["member_id", "chat_id"], []);

const chatInviteDBName = "chat_invites";
const chatInviteFields = ["inviter_id", "invited_id", "chat_id"];
const chatInvites = [ ["234567", "123456", "878787"] ];
const chatInviteTypes = ["S", "S", "S"];
makeTable(chatInvites, chatInviteDBName, chatInviteFields, chatInviteTypes, ["invited_id", "chat_id"], []);

const chatMessageDBName = "chat_messages";
const chatMessageFields = ["message_id", "sender_id", "chat_id", "content", "clock"];
const chatMessages = [ ["565656", "123456", "787878", "Sample chat message", "Sat Nov 15 2025 20:16:11 GMT-0500 (Eastern Standard Time)"] ];
const chatMessageTypes = ["S", "S", "S", "S", "S"];
makeTable(chatMessages, chatMessageDBName, chatMessageFields, chatMessageTypes, ["message_id"], []);

const groupDBName = "groups";
const groupFields = ["group_id", "group_name", "creator_id", "isPrivate"];
const groups = [ ["546723", "test Group", "123456", false], ["435612", "test group 2", "234567", true] ];
const groupTypes = [ "S", "S", "S", "BOOL" ];
makeTable(groups, groupDBName, groupFields, groupTypes, ["group_id"], []);

const groupMemberDBName = "group_members";
const groupMemberFields = ["group_id", "member_id"];
const groupMembers = [ ["546723", "123456"], ["546723", "234567"], ["435612", "234567"] ];
const groupMemberTypes = ["S", "S"];
makeTable(groupMembers, groupMemberDBName, groupMemberFields, groupMemberTypes, ["group_id", "member_id"], []);

const groupRequestDBName = "group_requests";
const groupRequestFields = ["group_id", "user_id"];
const groupRequests = [ ["435612", "567890"] ];
const groupRequestTypes = ["S", "S"];
makeTable(groupRequests, groupRequestDBName, groupRequestFields, groupRequestTypes, ["group_id", "user_id"], []);

const groupPostDBName = "group_posts";
const groupPostFields = ["group_id", "post_id"];
const groupPosts = [ ["546723", "654321"] ];
const groupPostTypes = ["S", "S"];
makeTable(groupPosts, groupPostDBName, groupPostFields, groupPostTypes, ["group_id", "post_id"], []);

// TWO TABLES NOT ADDED: `articles`, `feeds`. THESE ARE COMPUTED IN JAVA.