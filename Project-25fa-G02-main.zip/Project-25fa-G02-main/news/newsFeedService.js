const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();

// Cache for today's articles (cleared daily)
let articlesCache = {
    date: null,
    articles: null
};

// Get all users who need feed updates
const getAllUsers = async function() {
    const params = {
        TableName: 'users',
        ProjectionExpression: 'user_id'
    };

    let users = [];
    let lastEvaluatedKey = null;

    do {
        if (lastEvaluatedKey) {
            params.ExclusiveStartKey = lastEvaluatedKey;
        }

        const result = await db.scan(params).promise();
        users = users.concat(
            result.Items
                .filter(item => item.user_id?.S)
                .map(item => item.user_id.S)
        );
        lastEvaluatedKey = result.LastEvaluatedKey;
    } while (lastEvaluatedKey);

    return users;
};

// Get user's interests (news categories they're interested in)
const getUserInterests = async function(userId) {
    const params = {
        TableName: "interests",
        KeyConditionExpression: "user_id = :u",
        ExpressionAttributeValues: {
            ":u": { S: userId }
        },
        ProjectionExpression: "news_type"
    };

    try {
        const result = await db.query(params).promise();
        return (result.Items || [])
            .filter(item => item.news_type?.S)
            .map(item => item.news_type.S);
    } catch (err) {
        console.error('Error fetching interests:', err);
        return [];
    }
};

// Get articles already in user's feed
const getUserFeedArticles = async function(userId) {
    const params = {
        TableName: 'feeds',
        KeyConditionExpression: 'user_id = :uid',
        ExpressionAttributeValues: {
            ':uid': { S: userId }
        },
        ProjectionExpression: 'article_id'
    };

    try {
        const result = await db.query(params).promise();
        return new Set(
            result.Items
                .filter(item => item.article_id?.S)
                .map(item => item.article_id.S)
        );
    } catch (err) {
        console.error('Error fetching feed:', err);
        return new Set();
    }
};

// Get articles published on a specific date (optimized using GSI with caching)
const getArticlesByDate = async function(date) {
    // Check cache first
    if (articlesCache.date === date && articlesCache.articles !== null) {
        console.log(`Using cached articles for ${date} (${articlesCache.articles.length} articles)`);
        return articlesCache.articles;
    }

    console.log(`Fetching articles for ${date} from DynamoDB...`);

    // Use the published_date-index GSI for efficient date-based queries
    const params = {
        TableName: 'articles',
        IndexName: 'published_date-index',
        KeyConditionExpression: 'published_date = :date',
        ExpressionAttributeValues: {
            ':date': { S: date }
        },
        ProjectionExpression: 'article_id, category, published_date'
    };

    let articles = [];
    let lastEvaluatedKey = null;

    do {
        if (lastEvaluatedKey) {
            params.ExclusiveStartKey = lastEvaluatedKey;
        }

        const result = await db.query(params).promise();
        articles = articles.concat(result.Items);
        lastEvaluatedKey = result.LastEvaluatedKey;
    } while (lastEvaluatedKey);

    const processedArticles = articles
        .filter(item => item.article_id?.S && item.category?.S && item.published_date?.S)
        .map(item => ({
            article_id: item.article_id.S,
            category: item.category.S,
            published_date: item.published_date.S
        }));

    // Update cache
    articlesCache.date = date;
    articlesCache.articles = processedArticles;

    console.log(`Cached ${processedArticles.length} articles for ${date}`);

    return processedArticles;
};

// Get adsorption weights for articles for a specific user
const getArticleWeightsForUser = async function(userId, articleIds) {
    // Try to fetch from weights table
    const weights = {};
    const articleIdSet = new Set(articleIds);

    try {
        const params = {
            TableName: 'article_weights',
            KeyConditionExpression: 'user_id = :uid',
            ExpressionAttributeValues: {
                ':uid': { S: userId }
            },
            ProjectionExpression: 'article_id, weight'
        };

        const result = await db.query(params).promise();

        for (const item of result.Items || []) {
            const articleId = item.article_id?.S;
            const weightStr = item.weight?.N;

            if (articleId && weightStr && articleIdSet.has(articleId)) {
                weights[articleId] = parseFloat(weightStr);
            }
        }
    } catch (err) {
        console.log('Weights table not available for user', userId);
    }

    // Fallback when Spark weights not yet computed
    const missingArticleIds = articleIds.filter(id => weights[id] === undefined);

    if (missingArticleIds.length > 0) {
        const interests = await getUserInterests(userId);
        const interestSet = new Set(interests);

        // Batch fetch categories for missing articles
        const categories = await getArticleCategoriesBatch(missingArticleIds);

        for (const articleId of missingArticleIds) {
            const category = categories[articleId];
            weights[articleId] = (category && interestSet.has(category)) ? 0.5 : 0.05;
        }
    }

    return weights;
};

// Get article categories in batch (optimized for multiple articles)
const getArticleCategoriesBatch = async function(articleIds) {
    if (articleIds.length === 0) return {};

    const categories = {};

    // DynamoDB BatchGetItem supports up to 100 items per request
    const batchSize = 100;
    for (let i = 0; i < articleIds.length; i += batchSize) {
        const batch = articleIds.slice(i, i + batchSize);

        const params = {
            RequestItems: {
                'articles': {
                    Keys: batch.map(id => ({ article_id: { S: id } })),
                    ProjectionExpression: 'article_id, category'
                }
            }
        };

        try {
            const result = await db.batchGetItem(params).promise();
            const items = result.Responses?.articles || [];

            for (const item of items) {
                const articleId = item.article_id?.S;
                const category = item.category?.S;
                if (articleId && category) {
                    categories[articleId] = category;
                }
            }
        } catch (err) {
            console.error('Error batch fetching categories:', err);
        }
    }

    return categories;
};

// Select article using weighted random distribution
const selectWeightedRandomArticle = function(articles, weights) {
    if (articles.length === 0) return null;

    // Normalize weights
    const totalWeight = Object.values(weights).reduce((sum, w) => sum + w, 0);
    if (totalWeight === 0) {
        // If all weights are 0, use uniform random
        return articles[Math.floor(Math.random() * articles.length)];
    }

    const normalizedWeights = {};
    for (const [articleId, weight] of Object.entries(weights)) {
        normalizedWeights[articleId] = weight / totalWeight;
    }

    // Select using weighted random
    let random = Math.random();
    for (const article of articles) {
        random -= normalizedWeights[article.article_id] || 0;
        if (random <= 0) {
            return article;
        }
    }

    // Fallback (shouldn't reach here)
    return articles[articles.length - 1];
};

// Add article to user's feed
const addArticleToFeed = async function(userId, articleId, timestamp) {
    const params = {
        TableName: 'feeds',
        Item: {
            user_id: { S: userId },
            article_id: { S: articleId },
            timestamp: { S: timestamp || new Date().toISOString() }
        },
        ConditionExpression: 'attribute_not_exists(user_id) AND attribute_not_exists(article_id)'
    };

    try {
        await db.putItem(params).promise();
        return true;
    } catch (err) {
        if (err.code === 'ConditionalCheckFailedException') {
            console.log('Article already in feed');
            return false;
        }
        console.error('Error adding to feed:', err);
        return false;
    }
};

// Update feed for a single user only
const updateUserFeed = async function(userId) {
    try {
        // Get current date
        const today = new Date().toISOString().split('T')[0];

        // Get articles already in user's feed
        const existingArticles = await getUserFeedArticles(userId);

        // Get articles published today only (not all historical articles)
        const availableArticles = await getArticlesByDate(today);

        // Filter out articles already in feed
        const newArticles = availableArticles.filter(
            article => !existingArticles.has(article.article_id)
        );

        if (newArticles.length === 0) {
            console.log(`No new articles for user ${userId}`);
            return;
        }

        // Limit the number of candidate articles to consider
        // If there are too many articles, randomly sample a subset
        const maxCandidates = 500;
        const candidateArticles = newArticles.length > maxCandidates
            ? sampleRandomArticles(newArticles, maxCandidates)
            : newArticles;

        // Get weights for these articles
        const articleIds = candidateArticles.map(a => a.article_id);
        const weights = await getArticleWeightsForUser(userId, articleIds);

        // Select one article using weighted random distribution
        const selectedArticle = selectWeightedRandomArticle(candidateArticles, weights);

        if (selectedArticle) {
            const added = await addArticleToFeed(userId, selectedArticle.article_id, new Date().toISOString());
            if (added) {
                console.log(`Added article ${selectedArticle.article_id} to feed for user ${userId}`);
            }
        }
    } catch (err) {
        console.error(`Error updating feed for user ${userId}:`, err);
    }
};

// Randomly sample articles for performance
const sampleRandomArticles = function(articles, count) {
    const shuffled = [...articles];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled.slice(0, count);
};

// Update feeds for all users (optimized with pre-caching)
const updateAllFeeds = async function() {
    console.log('Starting feed update for all users...');

    try {
        const users = await getAllUsers();
        console.log(`Updating feeds for ${users.length} users`);

        // Pre-fetch today's articles once for all users (populates cache)
        const today = new Date().toISOString().split('T')[0];
        await getArticlesByDate(today);

        // Update feeds in batches to avoid overwhelming DynamoDB
        const batchSize = 10;
        for (let i = 0; i < users.length; i += batchSize) {
            const batch = users.slice(i, i + batchSize);
            await Promise.all(batch.map(userId => updateUserFeed(userId)));

            // Log progress
            if ((i + batchSize) % 100 === 0) {
                console.log(`Progress: ${Math.min(i + batchSize, users.length)}/${users.length} users updated`);
            }
        }

        console.log('Feed update complete');
    } catch (err) {
        console.error('Error in updateAllFeeds:', err);
    }
};

// Update feed when user changes their interests
const updateFeedOnInterestChange = async function(userId) {
    console.log(`Updating feed for user ${userId} due to interest change`);
    await updateUserFeed(userId);
};

// Start periodic feed updates (runs every hour)
const startFeedUpdateService = function() {
    console.log('Starting feed update service...');

    // Run initial update after 5 minutes (give Spark time to run)
    setTimeout(() => {
        console.log('Running initial feed update...');
        updateAllFeeds();
    }, 5 * 60 * 1000);

    // Then run every hour
    const ONE_HOUR = 60 * 60 * 1000;
    setInterval(() => {
        console.log('Running scheduled feed update...');
        updateAllFeeds();
    }, ONE_HOUR);

    console.log('Feed update service started (first run in 5 minutes, then hourly)');
};

module.exports = {
    updateUserFeed,
    updateAllFeeds,
    updateFeedOnInterestChange,
    startFeedUpdateService,
    addArticleToFeed,
    getUserFeedArticles
};