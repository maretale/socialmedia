// To initialize DynamoDB tables and load articles, run: node news/newsLoader.js
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();
const fs = require('fs');
const readline = require('readline');
const uuid = require('uuid').v4;
const path = require('path');

// Load news articles from the JSON lines file and insert into DynamoDB
const loadNewsArticles = async function() {
    const filePath = path.join(__dirname, 'data', 'News_Category_Dataset_v3.json');

    // Validate file exists before proceeding
    if (!fs.existsSync(filePath)) {
        console.error(`Error: Data file not found at: ${filePath}`);
        console.error('Please ensure News_Category_Dataset_v3.json is in the data directory');
        process.exit(1);
    }

    const fileStream = fs.createReadStream(filePath);
    fileStream.on('error', (err) => {
        console.error('Error reading file:', err);
        process.exit(1);
    });

    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    rl.on('error', (err) => {
        console.error('Error processing file:', err);
        process.exit(1);
    });

    const articles = [];

    for await (const line of rl) {
        try {
            const article = JSON.parse(line);

            // Only load articles published before 2016
            const originalDate = new Date(article.date);
            if (originalDate.getFullYear() >= 2016) {
                continue; // Skip articles from 2016 and later
            }

            // Add 10 years to bring the date closer to current
            originalDate.setFullYear(originalDate.getFullYear() + 10);
            const updatedDate = originalDate.toISOString().split('T')[0]; // YYYY-MM-DD format

            const articleData = {
                article_id: uuid(),
                category: article.category,
                headline: article.headline,
                authors: article.authors,
                link: article.link,
                short_description: article.short_description,
                published_date: updatedDate
            };

            articles.push(articleData);

            // Batch insert every 25 articles to avoid overwhelming DynamoDB
            if (articles.length >= 25) {
                await insertArticleBatch(articles.splice(0, 25));
                // Add delay to avoid throttling GSIs
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        } catch (err) {
            console.error('Error parsing line:', err);
        }
    }

    // Insert any remaining articles
    if (articles.length > 0) {
        await insertArticleBatch(articles);
    }

    console.log('News articles loaded successfully!');
};

// Helper
const insertArticleBatch = async function(articles) {
    const requests = articles.map(article => ({
        PutRequest: {
            Item: {
                article_id: { S: article.article_id },
                category: { S: article.category },
                headline: { S: article.headline },
                authors: { S: article.authors },
                link: { S: article.link },
                short_description: { S: article.short_description || '' },
                published_date: { S: article.published_date }
            }
        }
    }));

    const params = {
        RequestItems: {
            'articles': requests
        }
    };

    try {
        await db.batchWriteItem(params).promise();
        console.log(`Inserted batch of ${articles.length} articles`);
    } catch (err) {
        console.error('Error inserting batch:', err);
        // Retry individual items if batch fails
        for (const article of articles) {
            await insertSingleArticle(article);
        }
    }
};

// Helper
const insertSingleArticle = async function(article) {
    const params = {
        TableName: 'articles',
        Item: {
            article_id: { S: article.article_id },
            category: { S: article.category },
            headline: { S: article.headline },
            authors: { S: article.authors },
            link: { S: article.link },
            short_description: { S: article.short_description || '' },
            published_date: { S: article.published_date }
        }
    };

    try {
        await db.putItem(params).promise();
    } catch (err) {
        console.error('Error inserting article:', err);
    }
};

// Initialize the articles table if it doesn't exist
const initArticlesTable = function(callback) {
    db.listTables(function(err, data) {
        if (err) {
            console.log(err, err.stack);
            callback('Error when listing tables: ' + err, null);
        } else {
            const tables = data.TableNames.toString().split(",");

            if (tables.indexOf("articles") === -1) {
                console.log("Creating new table 'articles'");

                const params = {
                    AttributeDefinitions: [
                        { AttributeName: 'article_id', AttributeType: 'S' },
                        { AttributeName: 'published_date', AttributeType: 'S' },
                        { AttributeName: 'category', AttributeType: 'S' }
                    ],
                    KeySchema: [
                        { AttributeName: 'article_id', KeyType: 'HASH' }
                    ],
                    GlobalSecondaryIndexes: [
                        {
                            IndexName: 'published_date-index',
                            KeySchema: [
                                { AttributeName: 'published_date', KeyType: 'HASH' }
                            ],
                            Projection: { ProjectionType: 'ALL' },
                            ProvisionedThroughput: {
                                ReadCapacityUnits: 10,
                                WriteCapacityUnits: 10
                            }
                        },
                        {
                            IndexName: 'category-index',
                            KeySchema: [
                                { AttributeName: 'category', KeyType: 'HASH' }
                            ],
                            Projection: { ProjectionType: 'ALL' },
                            ProvisionedThroughput: {
                                ReadCapacityUnits: 10,
                                WriteCapacityUnits: 10
                            }
                        }
                    ],
                    ProvisionedThroughput: {
                        ReadCapacityUnits: 20,
                        WriteCapacityUnits: 20
                    },
                    TableName: 'articles'
                };

                db.createTable(params, function(err) {
                    if (err) {
                        console.log(err);
                        callback('Error while creating table: ' + err, null);
                    } else {
                        console.log("Table is being created; waiting for it to become active...");
                        const waitParams = { TableName: 'articles' };
                        db.waitFor('tableExists', waitParams, function(err) {
                            if (err) {
                                callback('Error waiting for table to exist: ' + err, null);
                            } else {
                                console.log("Table created successfully");
                                callback(null, 'Success');
                            }
                        });
                    }
                });
            } else {
                console.log("Table 'articles' already exists");
                callback(null, 'Success');
            }
        }
    });
};

// Initialize feeds table
const initFeedsTable = function(callback) {
    db.listTables(function(err, data) {
        if (err) {
            callback('Error when listing tables: ' + err, null);
        } else {
            const tables = data.TableNames.toString().split(",");

            if (tables.indexOf("feeds") === -1) {
                console.log("Creating new table 'feeds'");

                const params = {
                    AttributeDefinitions: [
                        { AttributeName: 'user_id', AttributeType: 'S' },
                        { AttributeName: 'article_id', AttributeType: 'S' }
                    ],
                    KeySchema: [
                        { AttributeName: 'user_id', KeyType: 'HASH' },
                        { AttributeName: 'article_id', KeyType: 'RANGE' }
                    ],
                    ProvisionedThroughput: {
                        ReadCapacityUnits: 20,
                        WriteCapacityUnits: 20
                    },
                    TableName: 'feeds'
                };

                db.createTable(params, function(err) {
                    if (err) {
                        callback('Error while creating table: ' + err, null);
                    } else {
                        console.log("Table is being created; waiting for it to become active...");
                        const waitParams = { TableName: 'feeds' };
                        db.waitFor('tableExists', waitParams, function(err) {
                            if (err) {
                                callback('Error waiting for table to exist: ' + err, null);
                            } else {
                                console.log("Table created successfully");
                                callback(null, 'Success');
                            }
                        });
                    }
                });
            } else {
                console.log("Table 'feeds' already exists");
                callback(null, 'Success');
            }
        }
    });
};

// Initialize article_likes table
const initArticleLikesTable = function(callback) {
    db.listTables(function(err, data) {
        if (err) {
            callback('Error when listing tables: ' + err, null);
        } else {
            const tables = data.TableNames.toString().split(",");

            if (tables.indexOf("article_likes") === -1) {
                console.log("Creating new table 'article_likes'");

                const params = {
                    AttributeDefinitions: [
                        { AttributeName: 'user_id', AttributeType: 'S' },
                        { AttributeName: 'article_id', AttributeType: 'S' }
                    ],
                    KeySchema: [
                        { AttributeName: 'user_id', KeyType: 'HASH' },
                        { AttributeName: 'article_id', KeyType: 'RANGE' }
                    ],
                    ProvisionedThroughput: {
                        ReadCapacityUnits: 20,
                        WriteCapacityUnits: 20
                    },
                    TableName: 'article_likes'
                };

                db.createTable(params, function(err) {
                    if (err) {
                        callback('Error while creating table: ' + err, null);
                    } else {
                        console.log("Table is being created; waiting for it to become active...");
                        const waitParams = { TableName: 'article_likes' };
                        db.waitFor('tableExists', waitParams, function(err) {
                            if (err) {
                                callback('Error waiting for table to exist: ' + err, null);
                            } else {
                                console.log("Table created successfully");
                                callback(null, 'Success');
                            }
                        });
                    }
                });
            } else {
                console.log("Table 'article_likes' already exists");
                callback(null, 'Success');
            }
        }
    });
};

// Initialize news_index table for search
const initNewsIndexTable = function(callback) {
    db.listTables(function(err, data) {
        if (err) {
            callback('Error when listing tables: ' + err, null);
        } else {
            const tables = data.TableNames.toString().split(",");

            if (tables.indexOf("news_index") === -1) {
                console.log("Creating new table 'news_index'");

                const params = {
                    AttributeDefinitions: [
                        { AttributeName: 'keyword', AttributeType: 'S' }
                    ],
                    KeySchema: [
                        { AttributeName: 'keyword', KeyType: 'HASH' }
                    ],
                    ProvisionedThroughput: {
                        ReadCapacityUnits: 20,
                        WriteCapacityUnits: 20
                    },
                    TableName: 'news_index'
                };

                db.createTable(params, function(err) {
                    if (err) {
                        callback('Error while creating table: ' + err, null);
                    } else {
                        console.log("Table is being created; waiting for it to become active...");
                        const waitParams = { TableName: 'news_index' };
                        db.waitFor('tableExists', waitParams, function(err) {
                            if (err) {
                                callback('Error waiting for table to exist: ' + err, null);
                            } else {
                                console.log("Table created successfully");
                                callback(null, 'Success');
                            }
                        });
                    }
                });
            } else {
                console.log("Table 'news_index' already exists");
                callback(null, 'Success');
            }
        }
    });
};

// Initialize article_weights table for Spark job results
const initArticleWeightsTable = function(callback) {
    db.listTables(function(err, data) {
        if (err) {
            callback('Error when listing tables: ' + err, null);
        } else {
            const tables = data.TableNames.toString().split(",");

            if (tables.indexOf("article_weights") === -1) {
                console.log("Creating new table 'article_weights'");

                const params = {
                    AttributeDefinitions: [
                        { AttributeName: 'user_id', AttributeType: 'S' },
                        { AttributeName: 'article_id', AttributeType: 'S' }
                    ],
                    KeySchema: [
                        { AttributeName: 'user_id', KeyType: 'HASH' },
                        { AttributeName: 'article_id', KeyType: 'RANGE' }
                    ],
                    ProvisionedThroughput: {
                        ReadCapacityUnits: 20,
                        WriteCapacityUnits: 20
                    },
                    TableName: 'article_weights'
                };

                db.createTable(params, function(err) {
                    if (err) {
                        callback('Error while creating table: ' + err, null);
                    } else {
                        console.log("Table is being created; waiting for it to become active...");
                        const waitParams = { TableName: 'article_weights' };
                        db.waitFor('tableExists', waitParams, function(err) {
                            if (err) {
                                callback('Error waiting for table to exist: ' + err, null);
                            } else {
                                console.log("Table created successfully");
                                callback(null, 'Success');
                            }
                        });
                    }
                });
            } else {
                console.log("Table 'article_weights' already exists");
                callback(null, 'Success');
            }
        }
    });
};

// Run the initialization
if (require.main === module) {
    initArticlesTable(function(err) {
        if (err) {
            console.error(err);
        } else {
            initFeedsTable(function(err) {
                if (err) {
                    console.error(err);
                } else {
                    initArticleLikesTable(function(err) {
                        if (err) {
                            console.error(err);
                        } else {
                            initNewsIndexTable(function(err) {
                                if (err) {
                                    console.error(err);
                                } else {
                                    initArticleWeightsTable(function(err) {
                                        if (err) {
                                            console.error(err);
                                        } else {
                                            loadNewsArticles()
                                                .then(() => {
                                                    console.log('Building search index...');
                                                    const searchService = require('./newsSearch');
                                                    return searchService.buildSearchIndexToDB();
                                                })
                                                .catch(console.error);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    });
}

module.exports = {
    initArticlesTable,
    initFeedsTable,
    initArticleLikesTable,
    initNewsIndexTable,
    initArticleWeightsTable,
    loadNewsArticles
};
