const { spawn } = require('child_process');

const SPARK_JOB_INTERVAL = 60 * 60 * 1000;
let lastSparkJobTime = 0;
let sparkJobRunning = false;

// Get LIVY_URL - use environment variable or default to EMR cluster
const LIVY_URL = process.env.LIVY_URL || 'http://ec2-100-28-124-205.compute-1.amazonaws.com:8998/';

// Run Java Livy client
const runSparkJob = function(currentDate) {
    if (sparkJobRunning) {
        console.log('Spark job already running, skipping...');
        return Promise.resolve();
    }

    return new Promise((resolve, reject) => {
        sparkJobRunning = true;
        console.log('Starting Spark job for date:', currentDate);
        console.log('Using Livy URL:', LIVY_URL);

        const javaProcess = spawn('java', [
            '-cp',
            'target/news-recommendation.jar',
            'news.livy.ComputeNewsRecommendations',
            currentDate
        ], {
            // Pass environment variables to Java process
            env: {
                ...process.env,  // Include all existing environment variables
                LIVY_URL: LIVY_URL  // Ensure LIVY_URL is set
            }
        });

        let output = '';
        let errorOutput = '';

        javaProcess.stdout.on('data', (data) => {
            const message = data.toString();
            console.log(message);
            output += message;
        });

        javaProcess.stderr.on('data', (data) => {
            const message = data.toString();
            console.error(message);
            errorOutput += message;
        });

        javaProcess.on('close', (code) => {
            sparkJobRunning = false;

            if (code === 0) {
                console.log('Spark job completed successfully');
                lastSparkJobTime = Date.now();
                resolve(output);
            } else {
                console.error('Spark job failed with code:', code);

                if (errorOutput.includes("Session isn't active") ||
                    errorOutput.includes("Connection refused") ||
                    errorOutput.includes("Bad Request")) {
                    console.warn('Livy server not available. Feed will use fallback weights.');
                    console.warn('To enable Spark: Set LIVY_URL environment variable or start EMR cluster.');
                    // Don't reject - this is expected in development
                    resolve('Skipped (Livy unavailable)');
                } else {
                    reject(new Error(`Java process exited with code ${code}`));
                }
            }
        });

        javaProcess.on('error', (err) => {
            sparkJobRunning = false;
            console.error('Failed to start Java process:', err);
            reject(err);
        });
    });
};

// Trigger Spark job if enough time has passed (for scheduled runs)
const triggerSparkJobIfNeeded = async function() {
    const now = Date.now();

    if (now - lastSparkJobTime < SPARK_JOB_INTERVAL) {
        console.log('Spark job ran recently, skipping scheduled run...');
        return;
    }

    const currentDate = new Date().toISOString().split('T')[0];

    try {
        await runSparkJob(currentDate);
    } catch (err) {
        console.error('Error running scheduled Spark job:', err.message);
    }
};

const triggerSparkJobImmediate = async function() {
    console.log('Triggering immediate Spark job (interest changed)');
    const currentDate = new Date().toISOString().split('T')[0];

    try {
        await runSparkJob(currentDate);
    } catch (err) {
        console.error('Error running immediate Spark job:', err.message);
    }
};

// Trigger for specific user (immediate, not subject to hourly check)
const triggerSparkJobForUser = async function(userId) {
    console.log(`Triggering Spark job for user ${userId} interest change`);
    await triggerSparkJobImmediate();
};

// Start periodic execution (hourly)
const startSparkJobService = function() {
    console.log('Starting Spark job service...');

    // Run immediately on startup to compute initial weights
    triggerSparkJobIfNeeded();

    // Then run every hour
    setInterval(triggerSparkJobIfNeeded, SPARK_JOB_INTERVAL);

    console.log('Spark job service started (running immediately, then hourly)');
};

module.exports = {
    runSparkJob,
    triggerSparkJobForUser,
    triggerSparkJobIfNeeded,
    triggerSparkJobImmediate,
    startSparkJobService
};