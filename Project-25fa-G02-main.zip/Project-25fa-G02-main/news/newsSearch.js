const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();
const natural = require('natural');
const stemmer = natural.PorterStemmer;
const fs = require('fs');
const path = require('path');

const STOPWORDS_FILE = path.join(__dirname, '..', 'nlp_en_stop_words.txt');

let STOP_WORDS = new Set();

try {
    const stopwordsText = fs.readFileSync(STOPWORDS_FILE, 'utf-8');
    STOP_WORDS = new Set(
        stopwordsText
            .split(/\r?\n/)      // split by newline
            .map(w => w.trim().toLowerCase())
            .filter(w => w.length > 0)
    );
    console.log(`Loaded ${STOP_WORDS.size} stop words from file`);
} catch (err) {
    console.error(`Could not load stopwords file (${STOPWORDS_FILE}):`, err);
    // fallback to default set
    STOP_WORDS = new Set([
        'a', 'all', 'any', 'but', 'the'
    ]);
}

// Process text for indexing: lowercase, remove stop words, and stem
const processText = function (text) {
    if (!text) return [];

    // Convert to lowercase and split into words
    const words = text.toLowerCase()
        .replace(/[^\w\s]/g, ' ') // Remove punctuation
        .split(/\s+/)
        .filter(word => word.length > 0);

    // Remove stop words and stem
    return words
        .filter(word => /^[a-zA-Z]+$/.test(word))
        .filter(word => !STOP_WORDS.has(word))
        .map(word => stemmer.stem(word))
        .filter(stem => stem && stem.length > 0 && typeof stem === 'string');
};

// Build inverted index and store in DynamoDB (run once during data loading)
const buildSearchIndexToDB = async function() {
    console.log('Building search index in DynamoDB...');

    const params = {
        TableName: 'articles',
        ProjectionExpression: 'article_id, headline, short_description'
    };

    let items = [];
    let lastEvaluatedKey = null;

    do {
        if (lastEvaluatedKey) {
            params.ExclusiveStartKey = lastEvaluatedKey;
        }

        const result = await db.scan(params).promise();
        items = items.concat(result.Items);
        lastEvaluatedKey = result.LastEvaluatedKey;
    } while (lastEvaluatedKey);

    console.log(`Processing ${items.length} articles for indexing...`);

    // Build inverted index in memory first
    const index = Object.create(null);
    for (const item of items) {
        const articleId = item.article_id.S;
        const headline = item.headline.S;

        const headlineWords = processText(headline);
        const allWords = [...new Set([...headlineWords])];

        for (const word of allWords) {
            if (!word || typeof word !== 'string') continue;
            if (!index[word]) {
                index[word] = [];
            }
            if (!Array.isArray(index[word])) {
                console.error(`Warning: index[${word}] is not an array:`, typeof index[word]);
                index[word] = [];
            }
            index[word].push(articleId);
        }
    }

    console.log(`Index built with ${Object.keys(index).length} unique terms`);

    // Write to DynamoDB in batches
    let totalWritten = 0;
    let skipped = 0;
    const batchSize = 25;
    const entries = Object.entries(index);

    // Limit article IDs per keyword to prevent exceeding DynamoDB item size
    const MAX_ARTICLES_PER_KEYWORD = 5000;

    for (let i = 0; i < entries.length; i += batchSize) {
        const batch = entries.slice(i, i + batchSize);
        const writeRequests = batch
            .map(([keyword, articleIds]) => {
                // Truncate to first 5000 articles if too many
                if (articleIds.length > MAX_ARTICLES_PER_KEYWORD) {
                    console.log(`Truncating keyword "${keyword}" from ${articleIds.length} to ${MAX_ARTICLES_PER_KEYWORD} articles`);
                    skipped++;
                }
                return {
                    PutRequest: {
                        Item: {
                            keyword: {S: keyword},
                            article_ids: {SS: articleIds.slice(0, MAX_ARTICLES_PER_KEYWORD)}
                        }
                    }
                };
            });

        if (writeRequests.length === 0) continue;

        const batchParams = {
            RequestItems: {
                'news_index': writeRequests
            }
        };

        try {
            await db.batchWriteItem(batchParams).promise();
            totalWritten += writeRequests.length;
            if (totalWritten % 1000 === 0 || i + batchSize >= entries.length) {
                console.log(`Written ${totalWritten}/${entries.length - skipped} index entries (skipped ${skipped} overly common terms)`);
            }
            await new Promise(resolve => setTimeout(resolve, 200));
        } catch (err) {
            console.error('Error writing batch:', err);
            // Try writing items individually if batch fails
            for (const req of writeRequests) {
                try {
                    await db.putItem({
                        TableName: 'news_index',
                        Item: req.PutRequest.Item
                    }).promise();
                } catch (e) {
                    console.error(`Failed to write keyword: ${req.PutRequest.Item.keyword.S}`, e.message);
                }
            }
        }
    }

    console.log(`Search index built successfully! Written: ${totalWritten}, Truncated: ${skipped} overly common terms`);
};

const searchArticles = async function(query, userId) {
    const queryTerms = processText(query);
    if (queryTerms.length === 0) {
        return [];
    }

    // Query DynamoDB index for each term
    const articleMatches = {};

    for (const term of queryTerms) {
        try {
            const params = {
                TableName: 'news_index',
                Key: {
                    keyword: { S: term }
                }
            };

            const result = await db.getItem(params).promise();

            if (result.Item && result.Item.article_ids && result.Item.article_ids.SS) {
                const matchingArticles = result.Item.article_ids.SS;
                for (const articleId of matchingArticles) {
                    if (!articleMatches[articleId]) {
                        articleMatches[articleId] = 0;
                    }
                    articleMatches[articleId]++;
                }
            }
        } catch (err) {
            console.error(`Error querying index for term '${term}':`, err);
        }
    }

    const articleIds = Object.keys(articleMatches);
    if (articleIds.length === 0) {
        return [];
    }

    // Sort by match count first, then limit to top 200 candidates to avoid throttling
    const sortedArticleIds = articleIds
        .sort((a, b) => articleMatches[b] - articleMatches[a])
        .slice(0, 200);

    // Fetch article details in batches to avoid throttling
    const articles = [];
    const batchSize = 20;
    for (let i = 0; i < sortedArticleIds.length; i += batchSize) {
        const batch = sortedArticleIds.slice(i, i + batchSize);
        const batchResults = await Promise.all(
            batch.map(id => getArticleById(id))
        );
        articles.push(...batchResults);
        // Small delay between batches to avoid throttling
        if (i + batchSize < sortedArticleIds.length) {
            await new Promise(resolve => setTimeout(resolve, 50));
        }
    }

    // Filter out future articles (only show articles published today or earlier)
    const today = new Date().toISOString().split('T')[0];
    const validArticles = articles
        .filter(article => article !== null)
        .filter(article => article.published_date <= today);

    // Get article IDs for valid articles only
    const validArticleIds = validArticles.map(a => a.article_id);

    // Get adsorption weights
    const weights = await getArticleWeights(userId, validArticleIds);

    // Rank articles
    return validArticles
        .map(article => {
            return {
                article_id: article.article_id,
                category: article.category,
                headline: article.headline,
                authors: article.authors,
                link: article.link,
                short_description: article.short_description,
                published_date: article.published_date,
                date: article.date,
                matchCount: articleMatches[article.article_id],
                weight: weights[article.article_id] || 0
            };
        })
        .sort((a, b) => {
            // First by number of matching terms
            if (a.matchCount !== b.matchCount) {
                return b.matchCount - a.matchCount;
            }
            // Then by adsorption weight
            return b.weight - a.weight;
        });
};

// Get article by ID with retry logic for throttling
const getArticleById = async function(articleId, retries = 3) {
    const params = {
        TableName: 'articles',
        Key: {
            article_id: { S: articleId }
        }
    };

    for (let attempt = 0; attempt < retries; attempt++) {
        try {
            const result = await db.getItem(params).promise();
            if (!result.Item) return null;

            return {
                article_id: result.Item.article_id.S,
                category: result.Item.category.S,
                headline: result.Item.headline.S,
                authors: result.Item.authors.S,
                link: result.Item.link.S,
                short_description: result.Item.short_description ? result.Item.short_description.S : '',
                published_date: result.Item.published_date.S,
                date: result.Item.published_date.S
            };
        } catch (err) {
            if (err.code === 'ProvisionedThroughputExceededException' && attempt < retries - 1) {
                // Exponential backoff: wait 100ms, 200ms, 400ms...
                const delay = 100 * Math.pow(2, attempt);
                await new Promise(resolve => setTimeout(resolve, delay));
                continue;
            }
            console.error('Error fetching article:', err);
            return null;
        }
    }
    return null;
};


// Get search suggestions while user is typing
const getSearchSuggestions = async function(partialQuery, limit = 5) {
    const processed = processText(partialQuery);

    if (processed.length === 0) return [];

    const lastTerm = processed[processed.length - 1];

    // Query DynamoDB for keywords that start with the last term
    const params = {
        TableName: 'news_index',
        FilterExpression: 'begins_with(keyword, :prefix)',
        ExpressionAttributeValues: {
            ':prefix': { S: lastTerm }
        },
        ProjectionExpression: 'keyword',
        Limit: limit
    };

    try {
        const result = await db.scan(params).promise();
        return result.Items.map(item => item.keyword.S);
    } catch (err) {
        console.error('Error getting suggestions:', err);
        return [];
    }
};


// Get article weights from adsorption results
const getArticleWeights = async function(userId, articleIds) {
    const weights = {};

    try {
        // Fetch weights computed by Spark adsorption algorithm
        const params = {
            TableName: 'article_weights',
            KeyConditionExpression: 'user_id = :uid',
            ExpressionAttributeValues: {
                ':uid': { S: userId }
            }
        };

        const result = await db.query(params).promise();

        for (const item of result.Items || []) {
            const articleId = item.article_id.S;
            if (articleIds.includes(articleId)) {
                weights[articleId] = parseFloat(item.weight.N);
            }
        }
    } catch (err) {
        console.log('Weights table not available, using uniform weights');
    }

    // Fill in missing weights with small values (articles not yet processed by Spark)
    for (const articleId of articleIds) {
        if (!weights[articleId]) {
            weights[articleId] = 0.01;
        }
    }

    return weights;
};

module.exports = {
    buildSearchIndexToDB,
    searchArticles,
    getArticleById,
    getSearchSuggestions
};
