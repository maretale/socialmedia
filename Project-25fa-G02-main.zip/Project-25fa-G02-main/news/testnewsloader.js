const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const db = new AWS.DynamoDB();
const uuid = require('uuid').v4;

console.log("=== Creating Complete Test Data for News Feed ===");

const waitForTable = (tableName) => {
    return new Promise((resolve, reject) => {
        const params = { TableName: tableName };
        db.waitFor('tableExists', params, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
};

const createArticlesTable = async () => {
    console.log("\n1. Creating articles table...");

    const params = {
        TableName: 'articles',
        KeySchema: [
            { AttributeName: 'article_id', KeyType: 'HASH' }
        ],
        AttributeDefinitions: [
            { AttributeName: 'article_id', AttributeType: 'S' }
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 10,
            WriteCapacityUnits: 10
        }
    };

    try {
        await db.createTable(params).promise();
        console.log("   Waiting for table to be active...");
        await waitForTable('articles');
        console.log("   Articles table created");
    } catch (err) {
        if (err.code === 'ResourceInUseException') {
            console.log("   Articles table already exists");
        } else {
            throw err;
        }
    }
};

const insertTestArticles = async () => {
    console.log("\n2. Inserting test articles...");

    const today = new Date().toISOString().split('T')[0];

    const testArticles = [
        { category: 'POLITICS', headline: 'Senate Passes New Budget Bill', authors: 'John Smith' },
        { category: 'POLITICS', headline: 'Presidential Election Updates', authors: 'Jane Doe' },
        { category: 'POLITICS', headline: 'New Tax Reform Proposed', authors: 'Bob Johnson' },
        { category: 'POLITICS', headline: 'Congress Debates Healthcare', authors: 'Alice Brown' },
        { category: 'POLITICS', headline: 'Foreign Policy Changes Announced', authors: 'Mike Wilson' },
        { category: 'TECH', headline: 'AI Breakthrough in Machine Learning', authors: 'Sarah Lee' },
        { category: 'TECH', headline: 'New Smartphone Released', authors: 'David Chen' },
        { category: 'TECH', headline: 'Cybersecurity Threats Increase', authors: 'Emma Davis' },
        { category: 'TECH', headline: 'Tech Company IPO Success', authors: 'Ryan Park' },
        { category: 'TECH', headline: 'Cloud Computing Trends 2025', authors: 'Lisa Wang' },
        { category: 'SPORTS', headline: 'Championship Game Tonight', authors: 'Tom Anderson' },
        { category: 'SPORTS', headline: 'Star Player Breaks Record', authors: 'Maria Garcia' },
        { category: 'SPORTS', headline: 'Olympics Preview: Key Events', authors: 'Chris Taylor' },
        { category: 'SPORTS', headline: 'Team Signs Major Contract', authors: 'Alex Martinez' },
        { category: 'SPORTS', headline: 'Coach Announces Retirement', authors: 'Jessica White' },
        { category: 'ENTERTAINMENT', headline: 'New Movie Breaks Box Office Record', authors: 'Karen Miller' },
        { category: 'ENTERTAINMENT', headline: 'Music Festival Lineup Announced', authors: 'Steve Jones' },
        { category: 'ENTERTAINMENT', headline: 'Celebrity Interview Exclusive', authors: 'Nancy Clark' },
        { category: 'BUSINESS', headline: 'Stock Market Hits New High', authors: 'Paul Adams' },
        { category: 'BUSINESS', headline: 'Major Company Merger Announced', authors: 'Rachel Green' }
    ];

    let insertedCount = 0;

    for (const article of testArticles) {
        const params = {
            TableName: 'articles',
            Item: {
                article_id: { S: uuid() },
                category: { S: article.category },
                headline: { S: article.headline },
                authors: { S: article.authors },
                link: { S: `https://example.com/article/${uuid()}` },
                short_description: { S: `This is a test article about ${article.headline.toLowerCase()}` },
                published_date: { S: today }
            }
        };

        try {
            await db.putItem(params).promise();
            insertedCount++;
        } catch (err) {
            console.error(`   Error inserting article: ${article.headline}`, err.message);
        }
    }

    console.log(`   Inserted ${insertedCount} test articles`);
};

const createFeedsTable = async () => {
    console.log("\n3. Creating feeds table...");

    const params = {
        TableName: 'feeds',
        KeySchema: [
            { AttributeName: 'user_id', KeyType: 'HASH' },
            { AttributeName: 'article_id', KeyType: 'RANGE' }
        ],
        AttributeDefinitions: [
            { AttributeName: 'user_id', AttributeType: 'S' },
            { AttributeName: 'article_id', AttributeType: 'S' }
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 10,
            WriteCapacityUnits: 10
        }
    };

    try {
        await db.createTable(params).promise();
        await waitForTable('feeds');
        console.log("   Feeds table created");
    } catch (err) {
        if (err.code === 'ResourceInUseException') {
            console.log("   Feeds table already exists");
        } else {
            throw err;
        }
    }
};

const createArticleLikesTable = async () => {
    console.log("\n4. Creating article_likes table...");

    const params = {
        TableName: 'article_likes',
        KeySchema: [
            { AttributeName: 'user_id', KeyType: 'HASH' },
            { AttributeName: 'article_id', KeyType: 'RANGE' }
        ],
        AttributeDefinitions: [
            { AttributeName: 'user_id', AttributeType: 'S' },
            { AttributeName: 'article_id', AttributeType: 'S' }
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 10,
            WriteCapacityUnits: 10
        }
    };

    try {
        await db.createTable(params).promise();
        await waitForTable('article_likes');
        console.log("   Article_likes table created");
    } catch (err) {
        if (err.code === 'ResourceInUseException') {
            console.log("   Article_likes table already exists");
        } else {
            throw err;
        }
    }
};

const createArticleWeightsTable = async () => {
    console.log("\n5. Creating article_weights table...");

    const params = {
        TableName: 'article_weights',
        KeySchema: [
            { AttributeName: 'user_id', KeyType: 'HASH' },
            { AttributeName: 'article_id', KeyType: 'RANGE' }
        ],
        AttributeDefinitions: [
            { AttributeName: 'user_id', AttributeType: 'S' },
            { AttributeName: 'article_id', AttributeType: 'S' }
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 10,
            WriteCapacityUnits: 10
        }
    };

    try {
        await db.createTable(params).promise();
        await waitForTable('article_weights');
        console.log("   Article_weights table created");
    } catch (err) {
        if (err.code === 'ResourceInUseException') {
            console.log("   Article_weights table already exists");
        } else {
            throw err;
        }
    }
};

// CREATE INTERESTS TABLE
const createInterestsTable = async () => {
    console.log("\n6. Creating interests table...");

    const params = {
        TableName: 'interests',
        KeySchema: [
            { AttributeName: 'user_id', KeyType: 'HASH' },
            { AttributeName: 'news_type', KeyType: 'RANGE' }
        ],
        AttributeDefinitions: [
            { AttributeName: 'user_id', AttributeType: 'S' },
            { AttributeName: 'news_type', AttributeType: 'S' }
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 10,
            WriteCapacityUnits: 10
        }
    };

    try {
        await db.createTable(params).promise();
        await waitForTable('interests');
        console.log("   Interests table created");
    } catch (err) {
        if (err.code === 'ResourceInUseException') {
            console.log("   Interests table already exists");
        } else {
            throw err;
        }
    }
};

// CREATE FRIENDS TABLE
const createFriendsTable = async () => {
    console.log("\n7. Creating friends table...");

    const params = {
        TableName: 'friends',
        KeySchema: [
            { AttributeName: 'friend1_id', KeyType: 'HASH' },
            { AttributeName: 'friend2_id', KeyType: 'RANGE' }
        ],
        AttributeDefinitions: [
            { AttributeName: 'friend1_id', AttributeType: 'S' },
            { AttributeName: 'friend2_id', AttributeType: 'S' }
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 10,
            WriteCapacityUnits: 10
        }
    };

    try {
        await db.createTable(params).promise();
        await waitForTable('friends');
        console.log("   Friends table created");
    } catch (err) {
        if (err.code === 'ResourceInUseException') {
            console.log("   Friends table already exists");
        } else {
            throw err;
        }
    }
};

// ADD INTERESTS FOR ALL 5 USERS
const addTestInterests = async () => {
    console.log("\n8. Adding test interests for ALL 5 users...");

    const testInterests = [
        { user_id: '123456', news_type: 'POLITICS' },
        { user_id: '123456', news_type: 'TECH' },
        { user_id: '234567', news_type: 'SPORTS' },
        { user_id: '234567', news_type: 'ENTERTAINMENT' },
        { user_id: '345678', news_type: 'BUSINESS' },
        { user_id: '345678', news_type: 'TECH' },
        { user_id: '456789', news_type: 'POLITICS' },
        { user_id: '456789', news_type: 'SPORTS' },
        { user_id: '567890', news_type: 'ENTERTAINMENT' },
        { user_id: '567890', news_type: 'BUSINESS' }
    ];

    let insertedCount = 0;

    for (const interest of testInterests) {
        const params = {
            TableName: 'interests',
            Item: {
                user_id: { S: interest.user_id },
                news_type: { S: interest.news_type }
            }
        };

        try {
            await db.putItem(params).promise();
            insertedCount++;
        } catch (err) {
            console.error(`   Error adding interest: ${interest.user_id} -> ${interest.news_type}`);
        }
    }

    console.log(`   Added ${insertedCount} interests for all 5 users`);
};

// ADD FRIEND RELATIONSHIPS
const addFriendships = async () => {
    console.log("\n9. Adding friend relationships...");

    const friendships = [
        ['123456', '234567'],
        ['123456', '345678'],
        ['234567', '456789'],
        ['345678', '567890'],
        ['456789', '567890']
    ];

    let insertedCount = 0;

    for (const [friend1, friend2] of friendships) {
        const params = {
            TableName: 'friends',
            Item: {
                friend1_id: { S: friend1 },
                friend2_id: { S: friend2 }
            }
        };

        try {
            await db.putItem(params).promise();
            insertedCount++;
            console.log(`   ${friend1} ↔ ${friend2}`);
        } catch (err) {
            console.error(`   Error adding friendship: ${friend1} - ${friend2}`);
        }
    }

    console.log(`   Added ${insertedCount} friend relationships`);
};

const verifySetup = async () => {
    console.log("\n10. Verifying setup...");

    try {
        const articlesCount = await db.scan({ TableName: 'articles', Select: 'COUNT' }).promise();
        console.log(`   Articles: ${articlesCount.Count}`);

        const interestsCount = await db.scan({ TableName: 'interests', Select: 'COUNT' }).promise();
        console.log(`   Interests: ${interestsCount.Count}`);

        const friendsCount = await db.scan({ TableName: 'friends', Select: 'COUNT' }).promise();
        console.log(`   Friends: ${friendsCount.Count}`);
    } catch (err) {
        console.error("Error verifying setup:", err);
    }
};

(async () => {
    try {
        await createArticlesTable();
        await insertTestArticles();
        await createFeedsTable();
        await createArticleLikesTable();
        await createArticleWeightsTable();
        await createInterestsTable();
        await createFriendsTable();
        await addTestInterests();
        await addFriendships();
        await verifySetup();

        console.log("All done! Ready to run Spark job.\n");
        process.exit(0);
    } catch (err) {
        console.error("\nError during setup:", err);
        process.exit(1);
    }
})();