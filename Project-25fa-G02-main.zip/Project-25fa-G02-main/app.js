const express = require('express');
const chatRoutes = require('./routes/chats.js');
const newsRoutes = require('./routes/news.js');
const postRoutes = require('./routes/posts.js');
const userRoutes = require('./routes/users.js');
const feedService = require('./news/newsFeedService.js');
const sparkIntegration = require('./news/sparkIntegration.js');
const path = require('path');
const app = express();
const session = require('express-session');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(session({
    secret: '__Group_G02_Secret_Key!@*',
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        secure: false,
        sameSite: 'lax'
    }
}));

// FRONTEND ENDPOINTS (render pages on the frontend)
app.get('/', userRoutes.logIn); // login page
app.get('/login', userRoutes.logIn);
app.get('/', userRoutes.logIn);
app.get('/signup', userRoutes.signup); // sign up page
app.get('/home', userRoutes.home); //home page
app.get('/account', userRoutes.account); //account page
app.get('/friendvisualizer', userRoutes.friendVisualizer); // friend visualization page
app.get('/friends', userRoutes.friends); // temporary friend listing page
app.get('/news', userRoutes.news); // news page
app.get('/user', userRoutes.user); // page to see other users
app.get('/createpost', userRoutes.createPost); // page to create post
app.get('/createcomment', userRoutes.createComment); // page to create comment
app.get('/chats', userRoutes.chats); // chats list page
app.get('/chat', userRoutes.chat); // individual chat page
app.get('/chatinvites', userRoutes.chatInvites); // chat invites page
app.get('/createchat', userRoutes.createChat); // create chat page
app.get('/logout', userRoutes.logoutFrontend); // log out
app.get('/groups', postRoutes.groups);
app.get('/group', postRoutes.group);
app.get('/creategroup', postRoutes.createGroupFrontend);
app.get('/creategroupcomment', postRoutes.createGroupComment);
app.get('/creategrouppost', postRoutes.createGroupPost);
app.get('/grouprequests', postRoutes.groupRequests);

// API ENDPOINTS
// AUTH/USER API ENDPOINTS
app.post('/api/auth/checklogin', userRoutes.checkLogin); // code for checking login
app.post('/api/auth/logout', userRoutes.logout); // code for logging out

app.get('/api/users/friends/visualization', userRoutes.visualizeFriends); // api code for visualizer
app.get('/api/users/friends/visualization/:userId', userRoutes.visualizeFriends);

app.post('/api/users/friends/requests', userRoutes.createFriendRequest); // create friend request
app.get('/api/users/friends/requests', userRoutes.getFriendRequest); // get a friend request
app.get('/api/users/friends/requests/all', userRoutes.getUserFriendRequests); // get a user's friend requests
app.delete('/api/users/friends/requests', userRoutes.deleteFriendRequest); // delete a user's friend request (delete by the user who requested)
app.delete('/api/users/friends/requests/reject', userRoutes.rejectFriendRequest); // reject a user's friend request (delete by the user who was requested)

app.post('/api/users/friends', userRoutes.createFriendship); // create friendship
app.get('/api/users/friends', userRoutes.getFriendship); // check if a single friendship exists, return timestamp
app.get('/api/users/friends/:id', userRoutes.getFriendsByUserId); // get all user friends, in proper order
app.delete('/api/users/friends', userRoutes.deleteFriendship); // delete friendship

app.get('/api/users/search', userRoutes.searchForUsers); // get user profile information with username
app.get('/api/users/username/:username', userRoutes.getAccountByUsername); // search for users with prefix

app.get('/api/users/current', userRoutes.getCurrentUser); // get data for the currently logged in user

app.put('/api/users/affiliation', userRoutes.updateAffiliation); // update user profile information
app.put('/api/users/email', userRoutes.updateEmail); // update user profile information
app.put('/api/users/password', userRoutes.updatePassword); // update user profile information
app.post('/api/users/profile-picture', userRoutes.uploadProfilePicture); // upload profile picture
app.put('/api/users/privacy', userRoutes.togglePrivacy);

app.post('/api/users', userRoutes.createAccount); // code for creating account (also logs user in)
app.get('/api/users/:id', userRoutes.getAccount); // get user profile information
app.delete('/api/users', userRoutes.deleteAccount); // code for deleting account (also logs user out)


// NEWS API ENDPOINTS
app.get('/api/news/feed', newsRoutes.getUserFeed); // get user's news feed
app.get('/api/news/search', newsRoutes.searchArticles); // search for articles
app.get('/api/news/suggestions', newsRoutes.getSearchSuggestions); // get search suggestions

app.get('/api/news/interests', newsRoutes.getUserInterests); // get user's interests
app.post('/api/news/interests', newsRoutes.addInterest); // add interest
app.delete('/api/news/interests/:newsType', newsRoutes.deleteInterest); // remove interest

app.post('/api/news/like/:articleId', newsRoutes.likeArticle); // like an article
app.delete('/api/news/like/:articleId', newsRoutes.unlikeArticle); // unlike an article
app.get('/api/news/likes', newsRoutes.getLikedArticles); // get liked articles

app.get('/api/news/categories', newsRoutes.getCategories); // get valid categories

// POST API ENDPOINTS
app.get('/api/posts/comments/post/:id', postRoutes.getCommentsByPost); // get comments with a post id

app.post('/api/posts/comments/', postRoutes.createComment); // create comment
app.get('/api/posts/comments/:id', postRoutes.getComment); // get comment with id
app.put('/api/posts/comments', postRoutes.updateComment); // update comment content
app.delete('/api/posts/comments/:id', postRoutes.deleteComment); // delete comment

app.post('/api/posts/wall/friends', postRoutes.addPostToFriendWalls); // add a post to all friends' walls
app.get('/api/posts/wall/:id', postRoutes.getWallByUserId); // get wall of a user with id
app.post('/api/posts', postRoutes.createPost); // create post
app.post('/api/posts/with-image', postRoutes.createPostWithImage); // create post with image
app.get('/api/posts/:id', postRoutes.getPost); // get post with id
app.put('/api/posts', postRoutes.updatePost); // update post content
app.delete('/api/posts/:id', postRoutes.deletePost); // delete post
app.post('/api/posts/tag', postRoutes.tagUser);

// GROUP API ENDPOINTS
app.get('/api/groups/requests/all', postRoutes.getAllGroupRequests); // get all requests for a group
app.post('/api/groups/requests', postRoutes.createGroupRequest); // request to join group
app.get('/api/groups/requests', postRoutes.getGroupRequest); // get group request
app.delete('/api/groups/requests', postRoutes.deleteGroupRequest); // delete a group request (must be owner or requester)

app.post('/api/groups/members', postRoutes.addGroupMember); // join a group (must have requested if private)
app.get('/api/groups/members', postRoutes.getGroupMember); // check a group membership
app.delete('/api/groups/members', postRoutes.deleteGroupMember); // remove member from group (must be user in question or group creator)

app.post('/api/groups/posts', postRoutes.addGroupPost); // add group post (must be group member)
app.post('/api/groups/posts/with-image', postRoutes.addGroupPostWithImage); // add group post with image (must be group member)
app.post('/api/groups/posts/comments', postRoutes.addGroupComment); // add group comment (must be group member)
app.get('/api/groups/posts/all', postRoutes.getGroupPosts); // get group posts (must be group member)
app.get('/api/groups/posts', postRoutes.getGroupPost); // get group post (must be group member)
app.delete('/api/groups/posts', postRoutes.deleteGroupPost); // delete group post (must be post creator or group creator)

app.post('/api/groups', postRoutes.createGroup); // create a new group
app.get('/api/groups/all/member', postRoutes.getAllMemberGroups); // get all groups where user is a member
app.get('/api/groups/all', postRoutes.getAllGroups); // get all groups
app.get('/api/groups/:id', postRoutes.getGroup); // get group information

// CHAT API ENDPOINTS
app.post('/api/chats/invites', chatRoutes.createChatInvite); // invite someone to chat (must be owner)
app.get('/api/chats/invites', chatRoutes.getUserChatInvites); // get user's chat invites
app.delete('/api/chats/invites/reject', chatRoutes.rejectChatInvite); // delete a chat invite (must be owner)
app.delete('/api/chats/invites', chatRoutes.deleteChatInvite); // delete a chat invite (must be owner)

app.post('/api/chats/messages', chatRoutes.createChatMessage); // create chat message (must be chat member)
app.get('/api/chats/messages/:id', chatRoutes.getChatMessage); // get chat message (must be chat member)
app.get('/api/chats/messages/chat/:id', chatRoutes.getChatMessagesByChat); // get all messages in a chat (must be chat member)

app.get('/api/chats/member/chat/:id', chatRoutes.checkChatMember); // check if user is chat member
app.get('/api/chats/members', chatRoutes.getChatMembers); // get a chat by member string
app.get('/api/chats/users/:id', chatRoutes.getUsersByChat); // get all members of a chat
app.post('/api/chats/member', chatRoutes.addChatMember); // join a chat (must have been invited)
app.delete('/api/chats/member', chatRoutes.removeChatMember); // leave chat

app.get('/api/chats/user', chatRoutes.getChatsByUser); // get all chats a user is a member of
app.post('/api/chats', chatRoutes.createChat); // create new chat
app.get('/api/chats/:id', chatRoutes.getChat); // get chat metadata
app.delete('/api/chats', chatRoutes.deleteChat); // delete a chat (must be owner)



// Start the feed update service (hourly updates)
feedService.startFeedUpdateService();

// Start the Spark integration service
sparkIntegration.startSparkJobService();

/* Run the server */

app.listen(8080);
console.log('Server running on port 8080. Now open http://localhost:8080/ in your browser!');